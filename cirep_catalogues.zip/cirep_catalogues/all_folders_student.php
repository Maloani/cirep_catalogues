<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est administrateur
if (!isset($_SESSION['user_id']) || !$_SESSION['user_id']) {
    header("Location: login.php");
    exit;
}

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Pagination et recherche
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$records_per_page = 2;
$offset = ($page - 1) * $records_per_page;

// Requête de base avec recherche
$sql = "SELECT i.matricule, i.first_name, i.last_name, i.desired_level, d.* 
        FROM inscriptions i
        LEFT JOIN dossiers_etudiants d ON d.inscription_id = i.inscription_id
        WHERE i.matricule LIKE ? OR CONCAT(i.first_name, ' ', i.last_name) LIKE ?
        LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$search_param = '%' . $search . '%';
$stmt->bind_param("ssii", $search_param, $search_param, $records_per_page, $offset);
$stmt->execute();
$result = $stmt->get_result();

// Compter le total des enregistrements pour la pagination
$total_sql = "SELECT COUNT(*) as total 
              FROM inscriptions i
              LEFT JOIN dossiers_etudiants d ON d.inscription_id = i.inscription_id
              WHERE i.matricule LIKE ? OR CONCAT(i.first_name, ' ', i.last_name) LIKE ?";
$total_stmt = $conn->prepare($total_sql);
$total_stmt->bind_param("ss", $search_param, $search_param);
$total_stmt->execute();
$total_result = $total_stmt->get_result();
$total_records = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);

$stmt->close();
$total_stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des dossiers des étudiants</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            width: 90%;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 {
            text-align: center;
            color: #007BFF;
        }
        .btn-back {
            margin: 10px 0;
            display: inline-block;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }
        form {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        input[type="text"] {
            padding: 10px;
            font-size: 16px;
            width: 300px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            font-size: 16px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
            text-align: left;
            padding: 10px;
        }
        td {
            padding: 10px;
            text-align: left;
        }
        .no-docs {
            color: red;
            font-weight: bold;
        }
        .pagination {
            text-align: center;
            margin-top: 20px;
        }
        .pagination a {
            padding: 10px 15px;
            margin: 5px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .pagination a:hover {
            background-color: #0056b3;
        }
        .download {
            color: #4CAF50;
            text-decoration: none;
        }
        .download:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Liste des dossiers des étudiants</h1>

        <!-- Bouton retour -->
        <a href="s_inscription.php" class="btn-back"><i class="fas fa-arrow-left"></i> Retour</a>

        <!-- Formulaire de recherche -->
        <form action="all_folders_student.php" method="get">
            <input type="text" name="search" placeholder="Rechercher un étudiant..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit"><i class="fas fa-search"></i> Rechercher</button>
        </form>

        <!-- Tableau des dossiers -->
        <table>
            <thead>
                <tr>
                    <th>Matricule</th>
                    <th>Nom complet</th>
                    <th>Niveau académique</th>
                    <th>Documents envoyés</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['matricule']); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name'] . " " . $row['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['desired_level']); ?></td>
                            <td>
                                <?php
                                $files = [
                                    "baccalaureat" => "Diplôme de baccalauréat",
                                    "graduat" => "Diplôme de graduat",
                                    "releves_notes_graduat" => "Relevés de notes de graduat",
                                    "licence" => "Diplôme de licence",
                                    "releves_notes_licence" => "Relevés de notes de licence",
                                    "maitrise" => "Diplôme de maîtrise",
                                    "releves_notes_maitrise" => "Relevés de notes de maîtrise",
                                    "master" => "Diplôme de master",
                                    "releves_notes_master" => "Relevés de notes de master"
                                ];
                                $has_docs = false;

                                foreach ($files as $key => $label) {
                                    if (!empty($row[$key])) {
                                        $has_docs = true;
                                        echo '<a href="' . htmlspecialchars($row[$key]) . '" class="download" download>';
                                        echo '<i class="fas fa-download"></i> ' . $label . '</a><br>';
                                    } else {
                                        echo '<span class="no-docs">' . $label . ' non envoyé</span><br>';
                                    }
                                }

                                if (!$has_docs) {
                                    echo '<span class="no-docs"style="color:navy">Cet étudiant n\'a pas encore envoyé de dossier.</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">Aucun résultat trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>">&laquo; Précédent</a>
            <?php endif; ?>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>">Suivant &raquo;</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
