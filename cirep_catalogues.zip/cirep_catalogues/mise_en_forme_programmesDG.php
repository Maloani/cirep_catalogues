<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set UTF-8 charset
$conn->set_charset("utf8mb4");

// Handle search query
$search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : "";

// Pagination setup
$limit = 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Fetch programs with search and pagination
$sql_programmes = "SELECT pf.*, i.sigle AS institution 
                   FROM programmes_formations pf
                   JOIN institutions i ON pf.institution_id = i.institution_id
                   WHERE pf.designation_programmes LIKE ? OR i.sigle LIKE ?
                   LIMIT ?, ?";
$stmt_programmes = $conn->prepare($sql_programmes);

$search_param = "%" . $search . "%";
$stmt_programmes->bind_param("ssii", $search_param, $search_param, $offset, $limit);
$stmt_programmes->execute();
$result_programmes = $stmt_programmes->get_result();

// Fetch total program count for pagination
$sql_total = "SELECT COUNT(*) AS total 
              FROM programmes_formations pf
              JOIN institutions i ON pf.institution_id = i.institution_id
              WHERE pf.designation_programmes LIKE ? OR i.sigle LIKE ?";
$stmt_total = $conn->prepare($sql_total);
$stmt_total->bind_param("ss", $search_param, $search_param);
$stmt_total->execute();
$total_result = $stmt_total->get_result()->fetch_assoc();
$total = $total_result['total'];

$total_pages = ceil($total / $limit);

// Handle delete action
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM programmes_formations WHERE id_programmes = ?";
    $stmt_delete = $conn->prepare($delete_sql);

    if ($stmt_delete === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt_delete->bind_param("i", $delete_id);
    if ($stmt_delete->execute()) {
        echo "<script>alert('Programme supprimé avec succès.'); window.location.href = 'mise_en_forme_programmesDG.php';</script>";
    } else {
        echo "<script>alert('Erreur lors de la suppression du programme.');</script>";
    }
    $stmt_delete->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Programmes - CIREP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #3498DB;
        }

        .search-bar {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .search-bar input {
            padding: 10px;
            width: 300px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .search-bar button {
            padding: 10px 15px;
            background-color: #3498DB;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #2980b9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #3498DB;
            color: white;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination a {
            margin: 0 5px;
            padding: 10px 15px;
            background-color: #3498DB;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .pagination a:hover {
            background-color: #2980b9;
        }

        .pagination .disabled {
            background-color: #ddd;
            color: #888;
            pointer-events: none;
        }

        .btn {
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            margin: 5px;
        }

        .edit-btn {
            background-color: #3498DB;
        }

        .edit-btn:hover {
            background-color: #2980b9;
        }

        .delete-btn {
            background-color: #e74c3c;
        }

        .delete-btn:hover {
            background-color: #c0392b;
        }

        .return-btn {
            display: block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
        }

        .return-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
         <a href="g_programmesDG.php" class="return-btn">Retour</a>
        <h1>Liste des facultés</h1>

        <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Rechercher une faculté..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Rechercher</button>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Désignation de la faculté</th>
                    <th>Institution</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_programmes->num_rows > 0): ?>
                    <?php while ($programme = $result_programmes->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($programme['designation_programmes']); ?></td>
                            <td><?php echo htmlspecialchars($programme['institution']); ?></td>
                            <td>
                                <a href="modifier_programme.php?id=<?php echo $programme['id_programmes']; ?>" class="btn edit-btn">Modifier</a>
                                <a href="?delete_id=<?php echo $programme['id_programmes']; ?>" 
                                   class="btn delete-btn" 
                                   onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce programme ?');">Supprimer</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">Aucun programme trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination">
            <a href="?search=<?php echo urlencode($search); ?>&page=<?php echo max(1, $page - 1); ?>" 
               class="<?php echo $page <= 1 ? 'disabled' : ''; ?>">Précédent</a>
            <a href="?search=<?php echo urlencode($search); ?>&page=<?php echo min($total_pages, $page + 1); ?>" 
               class="<?php echo $page >= $total_pages ? 'disabled' : ''; ?>">Suivant</a>
        </div>
    </div>
</body>
</html>
