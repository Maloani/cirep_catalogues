<?php
// Démarrer la session
session_start();

// Vérifier si l'étudiant est connecté
if (!isset($_SESSION['matricule'])) {
    header("Location: student_login.php");
    exit;
}

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les informations de l'étudiant
$matricule = $_SESSION['matricule'];
$sql = "SELECT * FROM inscriptions WHERE matricule = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Erreur de préparation de la requête (inscriptions) : " . $conn->error);
}

$stmt->bind_param("s", $matricule);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    die("Aucune inscription trouvée pour le matricule : " . htmlspecialchars($matricule));
}

$stmt->close();

// Obtenir le desired_level de l'étudiant
$desired_level = $student['desired_level'];

// Définir le nombre de cours par page
$courses_per_page = 5;

// Obtenir la page actuelle à partir des paramètres GET
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

// Calculer l'offset
$offset = ($page - 1) * $courses_per_page;

// Requête SQL pour récupérer les cours
$sql_courses = "
    SELECT 
        c.code,
        c.intitule_cours,
        c.credit,
        cf.nom_fichier
    FROM 
        cours c
    JOIN 
        filieres_departements f ON c.id_filieres_departements = f.id_filieres_departements
    JOIN 
        inscriptions i ON i.filiere = f.filieres_departements_designation
    JOIN 
        attribution_cours ac ON ac.cours_id = c.cours_id
    LEFT JOIN 
        cours_fichiers cf ON cf.id_attribution = ac.id_attribution
    WHERE 
        i.matricule = ? AND c.type_pro = ?
    LIMIT ? OFFSET ?
";

$stmt_courses = $conn->prepare($sql_courses);

if ($stmt_courses === false) {
    die("Erreur de préparation de la requête (cours) : " . $conn->error);
}

$stmt_courses->bind_param("ssii", $matricule, $desired_level, $courses_per_page, $offset);
$stmt_courses->execute();
$courses_result = $stmt_courses->get_result();

if ($courses_result === false) {
    die("Erreur lors de l'exécution de la requête (cours) : " . $stmt_courses->error);
}

// Récupérer les cours sous forme de tableau
$courses = [];
while ($row = $courses_result->fetch_assoc()) {
    $courses[] = $row;
}
$stmt_courses->close();

// Requête pour le nombre total de cours
$sql_total_courses = "
    SELECT COUNT(*) AS total
    FROM cours c
    JOIN filieres_departements f ON c.id_filieres_departements = f.id_filieres_departements
    JOIN inscriptions i ON i.filiere = f.filieres_departements_designation
    WHERE i.matricule = ? AND c.type_pro = ?
";

$stmt_total_courses = $conn->prepare($sql_total_courses);

if ($stmt_total_courses === false) {
    die("Erreur de préparation de la requête (total cours) : " . $conn->error);
}

$stmt_total_courses->bind_param("ss", $matricule, $desired_level);
$stmt_total_courses->execute();
$result_total_courses = $stmt_total_courses->get_result();

if ($result_total_courses === false) {
    die("Erreur lors de l'exécution de la requête (total cours) : " . $stmt_total_courses->error);
}

$total_courses = $result_total_courses->fetch_assoc()['total'] ?? 0;
$stmt_total_courses->close();

// Calculer le nombre total de pages
$total_pages = ceil($total_courses / $courses_per_page);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord étudiant</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* Menu principal */
        nav {
            background-color: #004080;
            padding: 10px;
        }

        nav .menu {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        nav .menu a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            font-size: 16px;
        }

        nav .menu a:hover {
            background-color: #0056b3;
        }

        /* Icône pour le menu hamburger */
        .menu-toggle {
            display: none;
            background-color: #004080;
            border: none;
            color: white;
            font-size: 20px;
            padding: 10px;
            cursor: pointer;
        }

        /* Affichage du menu sur mobile */
        @media (max-width: 768px) {
            nav .menu {
                display: none;
                flex-direction: column;
                align-items: center;
            }

            nav .menu a {
                width: 100%;
                text-align: center;
            }

            nav .menu.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }

        main {
            padding: 20px;
        }

        .container {
            margin-bottom: 20px;
        }

        .container h2 {
            color: #0077b6;
            margin-bottom: 15px;
        }

        .container table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0077b6;
            color: white;
        }

        .actions a {
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 8px 15px;
            border-radius: 5px;
            margin-right: 10px;
        }

        .actions a:hover {
            background-color: #3e8e41;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        nav .menu a.active {
    background-color: #0056b3;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    color: #fff;
}

.pagination {
    margin-top: 20px;
    text-align: center;
}

.pagination .btn {
    display: inline-block;
    padding: 10px 20px;
    margin: 5px;
    background-color: #0077b6;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.pagination .btn:hover {
    background-color: #0056b3;
}

    </style>
    <script>
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }
    </script>
</head>
<body>
    <!-- En-tête -->
    <header>
        
        <h1><p>Bienvenue, <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> !</p></h1>
    </header>

    <!-- Menu principal -->
     <nav>
    <button class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i> Menu
    </button>
    <div class="menu">
        <?php
        // Détecter la page actuelle
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>
         <a href="dashboard_student.php" class="<?php echo $current_page == 'dashboard_student.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Accueil
        </a>
        <a href="mes_courses.php" class="<?php echo $current_page == 'mes_courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> Mes cours
        </a>
        <a href="all_preve.php" class="<?php echo $current_page == 'all_preve.php' ? 'active' : ''; ?>">
            <i class="fas fa-id-card"></i> Mes preuves de paiement
        </a>
        <a href="generate_bulletin.php" class="<?php echo $current_page == 'generate_bulletin.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i> Bulletin de notes
        </a>
      
        <a href="process_declaration.php" class="<?php echo $current_page == 'process_declaration.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Déclarer le paiement
        </a>
        <a href="mes_dossiers.php" class="<?php echo $current_page == 'mes_dossiers.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Envoyer votre dossier
        </a>
        <a href="student_logout.php" class="<?php echo $current_page == 'student_logout.php' ? 'active' : ''; ?>">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </a>
    </div>
</nav>
<center>
   <!-- Contenu principal -->
<main>
        <div class="container">
            <h2>Mes cours</h2>
            <?php if (count($courses) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Intitulé</th>
                            <th>Crédits</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courses as $course): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($course['code']); ?></td>
                                <td><?php echo htmlspecialchars($course['intitule_cours']); ?></td>
                                <td><?php echo htmlspecialchars($course['credit']); ?></td>
                                <td class="actions">
                                    <?php if (!empty($course['nom_fichier'])): ?>
                                        <a href="uploads/<?php echo htmlspecialchars($course['nom_fichier']); ?>" download>
                                            Télécharger ses notes<i class="fas fa-download"></i>
                                        </a>
                                    <?php else: ?>
                                        <span style="color: gray;">Non disponible</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>" class="btn prev">Précédent</a>
                    <?php endif; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>" class="btn next">Suivant</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p>Aucun cours trouvé pour votre filière.</p>
            <?php endif; ?>
        </div>
    </main>
</center>
</body>
</html>
