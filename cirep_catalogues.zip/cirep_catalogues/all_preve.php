<?php
// Démarrer la session
session_start();

// Vérifier si l'étudiant est connecté
if (!isset($_SESSION['matricule'])) {
    header("Location: student_login.php");
    exit;
}

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les informations de l'étudiant connecté
$matricule = $_SESSION['matricule'];
$sql = "SELECT * FROM inscriptions WHERE matricule = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt->bind_param("s", $matricule);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    header("Location: student_login.php");
    exit;
}
$stmt->close();

// Pagination
$declarations_per_page = 5;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $declarations_per_page;

// Récupérer les informations combinées des tables declarations_paiements et paiements
$sql_combined = "
    SELECT 
        d.somme, 
        d.mode_paiement, 
        d.motif, 
        p.nom_comptable, 
        d.classe,
        d.annee_academique,
        p.signature, 
        p.fonction,
        p.paiement_id,
        p.appreciation_paiement 
    FROM paiements p
    INNER JOIN declarations_paiements d ON p.declaration_id = d.declaration_id
    INNER JOIN inscriptions i ON d.inscription_id = i.inscription_id
    WHERE i.matricule = ?
    LIMIT ? OFFSET ?
";

$stmt_combined = $conn->prepare($sql_combined);
$stmt_combined->bind_param("sii", $matricule, $declarations_per_page, $offset);
$stmt_combined->execute();
$combined_result = $stmt_combined->get_result();

$declarations = [];
while ($row = $combined_result->fetch_assoc()) {
    $declarations[] = $row;
}
$stmt_combined->close();

// Calculer le nombre total de déclarations
$sql_total_declarations = "
    SELECT COUNT(*) AS total
    FROM paiements p
    INNER JOIN declarations_paiements d ON p.declaration_id = d.declaration_id
    INNER JOIN inscriptions i ON d.inscription_id = i.inscription_id
    WHERE i.matricule = ?
";
$stmt_total_declarations = $conn->prepare($sql_total_declarations);
$stmt_total_declarations->bind_param("s", $matricule);
$stmt_total_declarations->execute();
$result_total_declarations = $stmt_total_declarations->get_result();
$total_declarations = $result_total_declarations->fetch_assoc()['total'];
$stmt_total_declarations->close();

$total_pages = ceil($total_declarations / $declarations_per_page);

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord étudiant</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* Menu principal */
        nav {
            background-color: #004080;
            padding: 10px;
        }

        nav .menu {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        nav .menu a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            font-size: 16px;
        }

        nav .menu a:hover {
            background-color: #0056b3;
        }

        /* Icône pour le menu hamburger */
        .menu-toggle {
            display: none;
            background-color: #004080;
            border: none;
            color: white;
            font-size: 20px;
            padding: 10px;
            cursor: pointer;
        }

        /* Affichage du menu sur mobile */
        @media (max-width: 768px) {
            nav .menu {
                display: none;
                flex-direction: column;
                align-items: center;
            }

            nav .menu a {
                width: 100%;
                text-align: center;
            }

            nav .menu.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }

        main {
            padding: 20px;
        }

        .container {
            margin-bottom: 20px;
        }

        .container h2 {
            color: #0077b6;
            margin-bottom: 15px;
        }

        .container table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0077b6;
            color: white;
        }

        .actions a {
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 8px 15px;
            border-radius: 5px;
            margin-right: 10px;
        }

        .actions a:hover {
            background-color: #3e8e41;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        nav .menu a.active {
    background-color: #0056b3;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    color: #fff;
}

.pagination {
    margin-top: 20px;
    text-align: center;
}

.pagination .btn {
    display: inline-block;
    padding: 10px 20px;
    margin: 5px;
    background-color: #0077b6;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.pagination .btn:hover {
    background-color: #0056b3;
}

    </style>
    <script>
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }
    </script>
</head>
<body>
    <!-- En-tête -->
    <header>
        
        <h1><p>Bienvenue, <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> !</p></h1>
    </header>

    <!-- Menu principal -->
     <nav>
    <button class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i> Menu
    </button>
    <div class="menu">
        <?php
        // Détecter la page actuelle
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>
         <a href="dashboard_student.php" class="<?php echo $current_page == 'dashboard_student.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Accueil
        </a>
        <a href="mes_courses.php" class="<?php echo $current_page == 'mes_courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> Mes cours
        </a>
        <a href="all_preve.php" class="<?php echo $current_page == 'all_preve.php' ? 'active' : ''; ?>">
            <i class="fas fa-id-card"></i> Mes preuves de paiement
        </a>
        <a href="generate_bulletin.php" class="<?php echo $current_page == 'generate_bulletin.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i> Bulletin de notes
        </a>
        
        <a href="process_declaration.php" class="<?php echo $current_page == 'process_declaration.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Déclarer le paiement
        </a>
        <a href="mes_dossiers.php" class="<?php echo $current_page == 'mes_dossiers.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Envoyer votre dossier
        </a>
        <a href="student_logout.php" class="<?php echo $current_page == 'student_logout.php' ? 'active' : ''; ?>">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </a>
    </div>
</nav>

    <!-- Contenu principal -->
   <main>
    <h2>Mes Déclarations de Paiement</h2>
    <?php if (count($declarations) > 0): ?>
        <table>
            <thead>
                <tr>
                     <th>Clase</th>
                    <th>Année académique</th>
                    <th>Montant</th>
                    <th>Mode de Paiement</th>
                    <th>Motif</th>
                    <th>Nom du Comptable</th>
                    <th>Fonction</th>
                    <th>Appréciation</th>
                    <th>Télécharger le Reçu</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($declarations as $declaration): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($declaration['classe']); ?></td>
                        <td><?php echo htmlspecialchars($declaration['annee_academique']); ?></td>
                        <td><?php echo htmlspecialchars(number_format($declaration['somme'], 2)) . ' XOF'; ?></td>
                        <td><?php echo htmlspecialchars($declaration['mode_paiement']); ?></td>
                        <td><?php echo htmlspecialchars($declaration['motif']); ?></td>
                        <td><?php echo htmlspecialchars($declaration['nom_comptable'] ?? 'Non défini'); ?></td>
                        <td><?php echo htmlspecialchars($declaration['fonction'] ?? 'Non défini'); ?></td>
                        <td><?php echo htmlspecialchars($declaration['appreciation_paiement'] ?? 'Non encore accepté'); ?></td>
                        <td>
                            <a href="telecharger_recu.php?paiement_id=<?php echo $declaration['paiement_id']; ?>" 
                               class="btn-download">
                               Télécharger
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>">Précédent</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>" class="<?php echo $i === $page ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>">Suivant</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <p>Aucune déclaration de paiement trouvée.</p>
    <?php endif; ?>
</main>

<style>
    .btn-download {
        display: inline-block;
        padding: 8px 15px;
        background-color: #0077b6;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        transition: background-color 0.3s;
    }

    .btn-download:hover {
        background-color: #0056b3;
    }
</style>

</body>
</html>
