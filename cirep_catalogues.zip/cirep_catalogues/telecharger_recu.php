<?php
require('fpdf/fpdf.php');
require('phpqrcode/qrlib.php');

session_start();

// Vérifier si l'utilisateur est connecté et si l'ID de paiement est fourni
if (!isset($_GET['paiement_id'])) {
    die("Erreur : ID de paiement manquant.");
}

// Récupérer l'ID de paiement
$paiement_id = intval($_GET['paiement_id']);

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Erreur : Échec de la connexion à la base de données.");
}

// Récupérer les informations des tables `inscriptions`, `declarations_paiements` et `paiements`
$sql = "
    SELECT 
        i.first_name, i.last_name, i.matricule, i.filiere, d.photo_etudiant,
        d.somme, d.mode_paiement, d.motif, d.date_paiement,
        p.nom_comptable, p.date_verification, p.appreciation_paiement, p.fonction, p.signature
    FROM paiements p
    JOIN declarations_paiements d ON p.declaration_id = d.declaration_id
    JOIN inscriptions i ON d.inscription_id = i.inscription_id
    WHERE p.paiement_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $paiement_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Erreur : Aucune donnée trouvée pour cette déclaration.");
}

$data = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Générer un QR code avec les informations
$qr_data = "Nom de l'etudiant : " . $data['first_name'] . " " . $data['last_name'] . "\n" .
           "Matricule : " . $data['matricule'] . "\n" .
           "Montant : " . number_format($data['somme'], 2) . " XOF\n" .
           "Date : " . $data['date_paiement'] . "\n" .
           "Mode de paiement : " . $data['mode_paiement'];
$qr_file = 'qrcode_' . $paiement_id . '.png';
QRcode::png($qr_data, $qr_file, QR_ECLEVEL_L, 3);

// Classe pour créer le PDF
class PDF extends FPDF {
    function Header() {
        // Fond bleu pour l'en-tête
        $this->SetFillColor(0, 102, 204);
        $this->Rect(0, 0, $this->w, 50, 'F');

        // Ajouter le logo
        $this->Image('img/logo.PNG', 10, 8, 30);

        // Texte de l'en-tête
        $this->SetTextColor(255, 255, 255);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 10, strtoupper("Centre Interuniversitaire de Recherche Pluridisciplinaire"), 0, 1, 'C');
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, "CIREP", 0, 1, 'C');
        $this->Ln(5);

        // Titre (blanc sur bleu)
        $this->SetFont('Arial', 'B', 18);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(0, 15, utf8_decode("RECU DE PAIEMENT"), 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer() {
        $this->SetY(-115); // Monter le footer jusqu'au niveau du QR code
        $this->SetFillColor(0, 102, 204);
        $this->SetTextColor(255, 255, 255);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'CIREP - www.cirep.ac.cd', 0, 0, 'C', true);
    }

    function PaymentReceipt($data, $qr_file) {
        // Ajouter un cadre bleu autour des données jusqu'au QR code
        $this->SetDrawColor(0, 90, 100);
        $this->SetLineWidth(1.5);
        $this->Rect(10, 50, 190, 142, 'D'); // Ajustement de la hauteur du cadre

        // Contenu du reçu
        $this->SetXY(20, 60);
        $this->SetFont('Arial', 'B', 12); // Texte en gras
        $this->Cell(100, 8, utf8_decode("Reçu de : ") . $data['first_name'] . " " . $data['last_name'], 0, 1);
        $this->Cell(100, 8, utf8_decode("Matricule : ") . $data['matricule'], 0, 1);
        $this->Cell(100, 8, utf8_decode("Filière : ") . $data['filiere'], 0, 1);
        $this->SetFont('Arial', 'B', 12); // Revenir au texte normal
        $this->Cell(100, 8, utf8_decode("La somme de : ") . number_format($data['somme'], 2) . " XOF", 0, 1);
        $this->Cell(100, 8, utf8_decode("Versée le : ") . $data['date_paiement'], 0, 1);
        $this->Cell(100, 8, utf8_decode("Motif : ") . $data['motif'], 0, 1);
        $this->Cell(100, 8, utf8_decode("Mode de paiement : ") . $data['mode_paiement'], 0, 1);
        $this->Cell(100, 8, utf8_decode("Date de vérification : ") . $data['date_verification'], 0, 1);

        // Photo de l'étudiant au milieu à droite
        if (file_exists($data['photo_etudiant'])) {
            $this->Image($data['photo_etudiant'], 140, 60, 40, 50);
        } else {
            $this->SetXY(140, 80);
            $this->SetFont('Arial', 'I', 10);
            $this->Cell(40, 10, utf8_decode('Photo non disponible'), 0, 1, 'C');
        }

        // Signature et fonction (alignés plus haut)
        $this->SetXY(20, 140);
        $this->Cell(30, 8, utf8_decode("Signature : "), 0, 0);
        if (file_exists($data['signature'])) {
            $this->Image($data['signature'], 55, 140, 40, 20);
        }
        $this->SetXY(20, 160);
        $this->SetFont('Arial', 'B', 12); // Texte en gras
        $this->Cell(100, 8, utf8_decode($data['nom_comptable']), 0, 1);
        $this->Cell(100, 8, utf8_decode($data['fonction']), 0, 1);

        // QR code aligné avec la signature
        $this->Image($qr_file, 150, 140, 40, 40);
    }
}

// Générer le PDF
$pdf = new PDF();
$pdf->AddPage();
$pdf->PaymentReceipt($data, $qr_file);

// Définir le nom du fichier
$filename = 'Recu_de_' . $data['first_name'] . '_' . $data['last_name'] . '.pdf';
$pdf->Output('I', $filename);

// Supprimer le fichier QR temporaire
unlink($qr_file);
?>
