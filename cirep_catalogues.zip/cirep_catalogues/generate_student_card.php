<?php
// Démarrer la session
session_start();

// Vérifier si l'administrateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérifier et récupérer l'ID de l'étudiant dans l'URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID invalide ou manquant.");
}
$inscription_id = intval($_GET['id']);

// Récupérer les informations de l'étudiant
$sql_student = "SELECT matricule, first_name, last_name, institution, filiere FROM inscriptions WHERE inscription_id = ?";
$stmt_student = $conn->prepare($sql_student);
$stmt_student->bind_param("i", $inscription_id);
$stmt_student->execute();
$result_student = $stmt_student->get_result();

if ($result_student->num_rows > 0) {
    $student = $result_student->fetch_assoc();
} else {
    die("Étudiant introuvable.");
}
$stmt_student->close();

// Initialiser les messages
$error_message = "";
$success_message = "";

// Gestion des données postées
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['classe'], $_POST['annee_academique'], $_FILES['photo'])) {
    $classe = trim($_POST['classe']);
    $annee_academique = trim($_POST['annee_academique']);
    $photo = $_FILES['photo'];

    $photo_name = $student['matricule'] . "_photo_" . basename($photo['name']);
    $target_dir = "uploads/cards/";
    $photo_file = $target_dir . $photo_name;

    $allowed_types = ['jpg', 'jpeg', 'png'];
    $photo_ext = strtolower(pathinfo($photo_file, PATHINFO_EXTENSION));

    if (!in_array($photo_ext, $allowed_types)) {
        $error_message = "Seuls les fichiers JPG, JPEG et PNG sont autorisés.";
    } elseif (!move_uploaded_file($photo['tmp_name'], $photo_file)) {
        $error_message = "Erreur lors du téléchargement de la photo.";
    } else {
        // Stocker les données dans la session
        $_SESSION['photo_path'] = $photo_file;
        $_SESSION['classe'] = $classe;
        $_SESSION['annee_academique'] = $annee_academique;
        $success_message = "Les informations ont été enregistrées avec succès.";
    }
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Générer la carte d'étudiant</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 24px;
            position: relative;
        }

        header .back-button {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            background-color: #0056b3;
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 14px;
        }

        header .back-button:hover {
            background-color: #004080;
        }

        main {
            margin: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .container {
            background-color: white;
            border-radius: 10px;
            padding: 20px 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex: 1;
            min-width: 300px;
        }

        .container h2 {
            color: #0077b6;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        ul li {
            margin: 10px 0;
            font-size: 14px;
        }

        ul li strong {
            color: #333;
        }

        ul li img {
            max-width: 100px;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            display: block;
            margin-top: 5px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        form label {
            font-weight: bold;
        }

        form input[type="text"],
        form input[type="file"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 100%;
            font-size: 14px;
        }

        form button {
            padding: 12px;
            background-color: #0077b6;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-transform: uppercase;
            font-weight: bold;
        }

        form button:hover {
            background-color: #005f8c;
        }

        .download-button {
            display: block;
            text-align: center;
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
        }

        .download-button:hover {
            background-color: #45a049;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<header>
    <a href="generer_cartes.php" class="back-button"><i class="fas fa-arrow-left"></i> Retour</a>
    <h1>Carte d'Étudiant : <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></h1>
</header>
<main>
    <!-- Section 1 : Afficher les données existantes -->
    <div class="container">
        <h2>Informations de l'étudiant</h2>
        <ul>
            <li><strong>Matricule :</strong> <?php echo htmlspecialchars($student['matricule']); ?></li>
            <li><strong>Classe :</strong> <?php echo htmlspecialchars($_SESSION['classe'] ?? 'Non spécifiée'); ?></li>
            <li><strong>Année académique :</strong> <?php echo htmlspecialchars($_SESSION['annee_academique'] ?? 'Non spécifiée'); ?></li>
            <li><strong>Nom :</strong> <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></li>
            <li><strong>Institution :</strong> <?php echo htmlspecialchars($student['institution']); ?></li>
            <li><strong>Filière :</strong> <?php echo htmlspecialchars($student['filiere']); ?></li>
            <li>
                <strong>Photo passeport :</strong>
                <?php if (isset($_SESSION['photo_path'])): ?>
                    <img src="<?php echo htmlspecialchars($_SESSION['photo_path']); ?>" alt="Photo passeport">
                <?php else: ?>
                    <p>Photo non chargée</p>
                <?php endif; ?>
            </li>
        </ul>
        <a href="generate_card_pdf.php?id=<?php echo $inscription_id; ?>" class="download-button">
            Télécharger la Carte
        </a>
    </div>

    <!-- Section 2 : Entrée des autres données -->
    <div class="container">
        <h2>Charger les fichiers nécessaires</h2>
        <?php if ($success_message): ?><p class="success"><?php echo $success_message; ?></p><?php endif; ?>
        <?php if ($error_message): ?><p class="error"><?php echo $error_message; ?></p><?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <label for="classe">Classe :</label>
            <input type="text" id="classe" name="classe" placeholder="Exemple : Terminale S" required>
            <label for="annee_academique">Année académique :</label>
            <input type="text" id="annee_academique" name="annee_academique" placeholder="Exemple : 2023-2024" required>
            <label for="photo">Photo passeport :</label>
            <input type="file" id="photo" name="photo" accept="image/*" required>
            <button type="submit">Télécharger et Afficher</button>
        </form>
    </div>
</main>
</body>
</html>

