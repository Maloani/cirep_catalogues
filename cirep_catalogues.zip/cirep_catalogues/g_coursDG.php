<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Configurer l'encodage UTF-8
$conn->set_charset("utf8mb4");

// Initialiser les messages
$error = "";
$success = "";

// Récupérer l'ID de l'utilisateur connecté
$user_id = $_SESSION['user_id'];

// Récupérer les informations de l'utilisateur connecté
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql_user);

if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows > 0) {
    $logged_user = $user_result->fetch_assoc();
} else {
    $logged_user = null;
}

$stmt->close();

// Récupérer toutes les filières pour les afficher dans la liste déroulante
$sql_filieres = "SELECT id_filieres_departements, filieres_departements_designation FROM filieres_departements";
$result_filieres = $conn->query($sql_filieres);

// Traiter la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer et nettoyer les données du formulaire
    $code = htmlspecialchars(trim($_POST['code']), ENT_QUOTES, 'UTF-8');
    
    $intitule_cours = htmlspecialchars(trim($_POST['intitule_cours']), ENT_QUOTES, 'UTF-8');
    $credit = intval($_POST['credit']);
    $type_pro = htmlspecialchars(trim($_POST['type_pro']), ENT_QUOTES, 'UTF-8');
    $id_filieres_departements = intval($_POST['id_filieres_departements']);

    // Vérifier les champs obligatoires
    if (empty($code) || empty($type_pro) || empty($intitule_cours) || empty($credit) || empty($id_filieres_departements)) {
        $error = "Tous les champs sont obligatoires.";
    } else {
        // Vérifier les doublons
        $checkQuery = "SELECT * FROM cours WHERE code = ? AND id_filieres_departements=?";
        $stmt_check = $conn->prepare($checkQuery);

        if ($stmt_check === false) {
            die("Erreur de préparation de la requête : " . $conn->error);
        }

        $stmt_check->bind_param("si", $code, $id_filieres_departements);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            $error = "Un cours avec ce code existe déjà.";
        } else {
            // Insérer les données dans la base
            $insertQuery = "INSERT INTO cours (code,  intitule_cours, credit, type_pro,id_filieres_departements) 
                            VALUES (?, ?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($insertQuery);

            if ($stmt_insert === false) {
                die("Erreur de préparation de la requête d'insertion : " . $conn->error);
            }

            $stmt_insert->bind_param("ssisi", $code, $intitule_cours, $credit,$type_pro,  $id_filieres_departements);

            if ($stmt_insert->execute()) {
                $success = "Le cours a été enregistré avec succès.";
            } else {
                $error = "Erreur lors de l'enregistrement : " . $stmt_insert->error;
            }

            $stmt_insert->close();
        }

        $stmt_check->close();
    }
}

$conn->close();
?>






<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Programmes - CIREP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            background-color: #5DADE2;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #3498DB;
            color: white;
            padding: 15px 20px;
        }

        header img {
            width: 60px;
            height: auto;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            gap: 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            padding: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            padding: 20px;
        }

        .sidebar {
            width: 200px;
            background: #f4f4f4;
            border: 1px solid #ddd;
            padding: 15px;
        }

        .sidebar h3 {
            margin-bottom: 15px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            text-decoration: none;
            color: #333;
        }

        .register-container {
            flex: 1;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        label {
            width: 30%;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="email"], input[type="password"], select {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            background-color: #3498DB;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #5DADE2;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
<style>
    .error {
        color: red;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #ffe6e6;
        padding: 10px;
        border: 1px solid red;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .error-icon {
        color: red;
        font-size: 18px;
    }

    .success {
        color: green;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #e6ffe6;
        padding: 10px;
        border: 1px solid green;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .success-icon {
        color: green;
        font-size: 18px;
    }
</style>

   <header>
        
        <h1 style='color:white'>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <div class="navbar">
        <a href="dashboardDG.php">Accueil</a>
       
        <a href="logout.php">Déconnexion</a>
    </div>

    <div class="main-content">
       <div class="sidebar">
    <h3>Liens rapides</h3>
   <ul>
         <li><a href="g_programmesDG.php">Facultés </a></li>
   
        <li><a href="g_filiereDG.php">Filières ou départements </a></li>
        <li><a href="g_coursDG.php">Les cours </a></li>
        <li><a href="g_enseignantDG.php">Les Enseignants </a></li>
         <li><a href="g_attributionDG.php">Attribution des cours aux enseignants </a></li>
    </ul>
</div>
<style>
    .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.update-link {
    display: inline-block;
    text-decoration: none;
    font-size: 16px;
    color: white;
    background-color: #3498DB; /* Bleu */
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.update-link:hover {
    background-color: #2C81BA; /* Couleur légèrement plus foncée au survol */
    transform: scale(1.05); /* Agrandir légèrement au survol */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
}
</style>


        <div class="register-container">
	
<a href="mise_en_forme_coursDG.php" class="update-link">Mise à jour </a>

            <h3 style='color:red'>Enregistrez les cours dans le système CIREP catalogue</h3>
            <?php if (!empty($error)): ?>
				<p class="error">
					<span class="error-icon">&#10060;</span> <!-- Error Icon -->
					<?php echo $error; ?>
				</p>
			<?php endif; ?>

			<?php if (!empty($success)): ?>
				<p class="success">
					<span class="success-icon">&#10004;</span> <!-- Success Icon -->
					<?php echo $success; ?>
				</p>
			<?php endif; ?>

		 <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <div class="form-group">
                <label for="code">Code du cours :</label>
                <input type="text" id="code" name="code" required>
            </div>
            <div class="form-group">
    <label for="type_pro">Type de programme :</label>
    <select id="type_pro" name="type_pro" required>
        <option value="" disabled selected>-- Sélectionnez un type de programme --</option>
         <option value="Formation Continue">Formation Continue</option>
        <option value="Licence">Licence</option>
        <option value="Master">Master</option>
        <option value="Doctorat">Doctorat</option>
    </select>
</div>

<div class="form-group">
    <label for="intitule_cours">Intitulé du cours :</label>
    <input type="text" id="intitule_cours" name="intitule_cours" required>
</div>

            <div class="form-group">
                <label for="credit">Nombre de crédits :</label>
                <input type="number" id="credit" name="credit" min="1" required>
            </div>
            <div class="form-group">
                <label for="id_filieres_departements">Attribuer une Filière pour ce cours :</label>
                <select id="id_filieres_departements" name="id_filieres_departements" required>
                    <option value="" disabled selected>-- Sélectionnez une filière --</option>
                    <?php while ($filiere = $result_filieres->fetch_assoc()): ?>
                        <option value="<?php echo $filiere['id_filieres_departements']; ?>">
                            <?php echo htmlspecialchars($filiere['filieres_departements_designation']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <button type="submit">Enregistrer</button>
        </form>

           
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. Tous droits réservés.</p>
    </footer>
	

</body>
</html>
