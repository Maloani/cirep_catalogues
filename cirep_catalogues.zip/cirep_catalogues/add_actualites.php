<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "cirep_catalogue_db";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the logged-in user's information
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$logged_user = $user_result->fetch_assoc();

// Initialize variables
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = trim($_POST['titre']);
    $contenu = trim($_POST['contenu']);
    $status = trim($_POST['status']);
    $dateHeure_publ = date("Y-m-d H:i:s"); // Automatically set the current date and time

    // Validate input
    if (empty($titre) || empty($contenu) || empty($status)) {
        $error = "Tous les champs sont requis.";
    } else {
        // Handle file upload
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = "uploads/"; // Directory to store uploaded files
            $image = $upload_dir . basename($_FILES['image']['name']);
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $image)) {
                $error = "Erreur lors du téléchargement de l'image.";
            }
        }

        if (empty($error)) {
            // Insert the new actualite into the database
            $stmt = $conn->prepare("INSERT INTO actualites (titre, contenu, dateHeure_publ, user_id, image, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssiss", $titre, $contenu, $dateHeure_publ, $user_id, $image, $status);

            if ($stmt->execute()) {
                $success = "Actualité ajoutée avec succès.";
            } else {
                $error = "Erreur lors de l'ajout de l'actualité. Veuillez réessayer.";
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title><?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom']); ?> - CIREP Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #3498DB;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"], textarea, select, input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            background-color: #3498DB;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #5DADE2;
        }

        .message {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
        }

        .error {
            color: red;
            background-color: #ffe6e6;
            border: 1px solid red;
        }

        .success {
            color: green;
            background-color: #e6ffe6;
            border: 1px solid green;
        }
		header {
            background-color: #5DADE2;
            color: white;
            padding: 20px;
            text-align: center;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        header img {
            height: 50px;
            margin-right: 20px;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            padding: 5px 10px;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            border-radius: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            gap: 20px;
            padding: 20px;
            background-color: #5DADE2;
        }

        .sidebar {
            flex: 1;
            background-color: white;
            padding: 15px;
            border: 1px solid #ddd;
        }

        .content {
            flex: 2;
            background-color: white;
            padding: 20px;
            border: 1px solid #ddd;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #5DADE2;
            color: white;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        footer p {
            margin: 0;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }

            .sidebar {
                flex: none;
            }

            .content {
                flex: none;
            }
        }
    </style>
</head>
<body>
<!-- Header -->
    <header>
        
       <h1 style="color:white">Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <!-- Navbar -->
    <div class="navbar">
        <a href="dashboard.php">Accueil</a>
        <a href="register.php">Users</a>
        <a href="#">Paramères</a>
        
        <a href="logout.php">Déconnexion</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Left Sidebar -->
          <div class="sidebar">
    <h3>Liens rapides</h3>
    <ul>
        <li><a href="register.php">Ajouter un utilisateur</a></li>
        <li><a href="add_actualites.php">Ajouter une actualité</a></li>
        <li><a href="#">Voir les rapports</a></li>
    </ul>
</div>
<style>
   .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.update-link {
    display: inline-block;
    text-decoration: none;
    font-size: 16px;
    color: white;
    background-color: #3498DB; /* Bleu */
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.update-link:hover {
    background-color: #2C81BA; /* Couleur légèrement plus foncée au survol */
    transform: scale(1.05); /* Agrandir légèrement au survol */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
}
</style>
    <div class="container">
	<a href="mises_actualite.php" class="update-link">Mise à jour des actualites</a>

        <h1>Ajouter une actualité</h1>

        <?php if (!empty($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="message success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="titre">Titre :</label>
                <input type="text" name="titre" id="titre" required>
            </div>

            <div class="form-group">
                <label for="contenu">Contenu :</label>
                <textarea name="contenu" id="contenu" rows="5" required></textarea>
            </div>

            <div class="form-group">
                <label for="status">Statut :</label>
                <select name="status" id="status" required>
                    <option value="APPEL OUVERT">APPEL OUVERT</option>
                    <option value="APPEL CLOS">APPEL CLOS</option>
                    <option value="INFO">INFO</option>
                </select>
            </div>

            <div class="form-group">
                <label for="image">Image :</label>
                <input type="file" name="image" id="image" accept="image/*">
            </div>

            <button type="submit">Ajouter l'actualité</button>
        </form>
    </div>
	<style>
/* Table Styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    font-family: Arial, sans-serif;
}

thead th {
    padding: 10px;
    background-color: #5DADE2;
    text-align: left;
}

tbody tr {
    border-bottom: 1px solid #ddd;
}

tbody tr:hover {
    background-color: #f9f9f9;
}

td {
    padding: 10px;
    vertical-align: middle;
}

/* Button Styling */
.btn {
    padding: 8px 12px;
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
}

.btn-edit {
    background-color: #4CAF50; /* Green */
}

.btn-delete {
    background-color: #f44336; /* Red */
}

.btn:hover {
    opacity: 0.9;
}

/* Icon Styling */
i {
    font-size: 16px;
}

</style>

        <!-- Right Sidebar -->
        <div class="sidebar">
            <h3>Notifications</h3>
            <p>No new notifications</p>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. All rights reserved.</p>
    </footer>
</body>
</html>
