<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion à la base de données : " . $conn->connect_error);
}

// Récupérer l'ID de la déclaration
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID invalide ou manquant.");
}
$declaration_id = intval($_GET['id']);

// Récupérer les informations de la déclaration avec les données de l'étudiant
$sql = "
    SELECT d.*, i.first_name, i.last_name 
    FROM declarations_paiements d
    JOIN inscriptions i ON d.inscription_id = i.inscription_id
    WHERE d.declaration_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt->bind_param("i", $declaration_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Aucune déclaration trouvée pour cet ID.");
}

$declaration = $result->fetch_assoc();
$stmt->close();

// Initialisation du message pour le retour visuel
$message = "";

// Traitement du formulaire soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_comptable = $_POST['nom_comptable'];
    $fonction = $_POST['fonction'];
    $date_verification = $_POST['date_verification'];
    $appreciation_paiement = $_POST['appreciation'];

    // Gérer l'upload de la signature
    $signature_path = "uploads/signatures/";
    $signature_file = $signature_path . uniqid() . "_" . basename($_FILES['signature']['name']);
    if (!move_uploaded_file($_FILES['signature']['tmp_name'], $signature_file)) {
        die("Erreur lors du téléchargement de la signature.");
    }

    // Insertion des données dans la table paiements
    $insert_sql = "
        INSERT INTO paiements (declaration_id, nom_comptable, fonction,date_verification, signature, appreciation_paiement) 
        VALUES (?, ?, ?, ?, ?,?)";
    $stmt = $conn->prepare($insert_sql);

    if (!$stmt) {
        die("Erreur de préparation de la requête d'insertion : " . $conn->error);
    }

    $stmt->bind_param("isssss", $declaration_id, $nom_comptable, $fonction,$date_verification, $signature_file, $appreciation_paiement);

    if ($stmt->execute()) {
        $message = "Paiement validé et enregistré avec succès.";
    } else {
        $message = "Erreur lors de l'enregistrement : " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation de Paiement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .left-panel, .right-panel {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
        }

        h2 {
            color: #333;
        }

        .info p {
            margin: 8px 0;
            font-size: 16px;
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        form input, select, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #3498DB;
            color: white;
            font-weight: bold;
            border: none;
            cursor: pointer;
            text-transform: uppercase;
        }

        button:hover {
            background-color: #2980B9;
        }
    </style>
</head>
<body>
   
    <div class="container">
        
        <!-- Partie gauche : Informations de la déclaration -->
        <div class="left-panel">
    <h2>Informations sur la Déclaration</h2>
    <div class="info">
        <p><strong>Nom de l'étudiant :</strong> <?php echo htmlspecialchars($declaration['first_name'] . ' ' . $declaration['last_name']); ?></p>
        <p><strong>Classe :</strong> <?php echo htmlspecialchars($declaration['classe']); ?></p>
        <p><strong>Année académique :</strong> <?php echo htmlspecialchars($declaration['annee_academique']); ?></p>
        <p><strong>Montant payé :</strong> <?php echo htmlspecialchars(number_format($declaration['somme'], 2)) . ' XOF'; ?></p>
        <p><strong>Date de paiement :</strong> <?php echo htmlspecialchars($declaration['date_paiement']); ?></p>
        <p><strong>Motif :</strong> <?php echo htmlspecialchars($declaration['motif']); ?></p>
        <p><strong>Mode de paiement :</strong> <?php echo htmlspecialchars($declaration['mode_paiement']); ?></p>
        <p><strong>Photo de l'étudiant :</strong></p>
        <img src="<?php echo htmlspecialchars($declaration['photo_etudiant']); ?>" alt="Photo étudiant" class="thumbnail" onclick="enlargeImage(this)">
        <p><strong>Bordereau :</strong></p>
        <img src="<?php echo htmlspecialchars($declaration['photo_bordereau']); ?>" alt="Bordereau" class="thumbnail" onclick="enlargeImage(this)">
    </div>
</div>

<!-- Modale pour afficher les images -->
<div id="modal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <img class="modal-content" id="modal-img">
</div>


        <!-- Partie droite : Validation -->
       <div class="right-panel">
    <h2>Valider le Paiement</h2>
    
    <!-- Message de confirmation -->
    <?php if (!empty($message)): ?>
        <p style="color: green; font-weight: bold; text-align: center; background-color: #d4edda; padding: 10px; border-radius: 5px;">
            <?php echo htmlspecialchars($message); ?>
        </p>
    <?php endif; ?>

    <!-- Formulaire -->
    <form method="POST" enctype="multipart/form-data">
        <label for="nom_comptable">Nom complet :</label>
        <input type="text" id="nom_comptable" name="nom_comptable" placeholder="Ex : Jean Dupont" required>
        <label for="fonction">Fonction au CIREP :</label>
        <input type="text" id="fonction" name="fonction" placeholder="Secretaire comptable" required>


        <label for="date_verification">Date de vérification :</label>
        <input type="text" id="date_verification" name="date_verification" value="<?php echo date('Y-m-d H:i:s'); ?>" readonly>

        <label for="signature">Votre Signature :</label>
        <input type="file" id="signature" name="signature" accept="image/*" required>

        <label for="appreciation">Le bordereau de paiement est conforme ?</label>
        <select id="appreciation" name="appreciation" required>
            <option value="">-- Sélectionnez --</option>
            <option value="Oui">Oui</option>
            <option value="Non">Non</option>
        </select>

        <button type="submit">Valider et générer le reçu</button>
        <a href="generer_recus.php" class="back-button"><i class="fas fa-arrow-left"></i> Annuler</a>
    </form>
</div>

    </div>
    <style>
/* Style des images dans la liste */
.thumbnail {
    max-width: 150px;
    cursor: pointer;
    border: 2px solid #ddd;
    border-radius: 5px;
    margin: 10px 0;
}

.thumbnail:hover {
    border-color: #3498DB;
}

/* Modale */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.8);
    justify-content: center;
    align-items: center;
}

.modal-content {
    margin: auto;
    display: block;
    max-width: 90%;
    max-height: 90%;
}

.close {
    position: absolute;
    top: 20px;
    right: 35px;
    color: white;
    font-size: 30px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: #bbb;
    text-decoration: none;
}
</style>
<script>
function enlargeImage(img) {
    var modal = document.getElementById("modal");
    var modalImg = document.getElementById("modal-img");
    modal.style.display = "flex";
    modalImg.src = img.src;
}

function closeModal() {
    var modal = document.getElementById("modal");
    modal.style.display = "none";
}
</script>

</body>
</html>
