<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the logged-in user's information
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$logged_user = $user_result->fetch_assoc();

// Initialize variables
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = trim($_POST['prenom']);
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $role = trim($_POST['role']);
    $login = trim($_POST['login']);
    $pwd = trim($_POST['pwd']);
    $pwd_confirm = trim($_POST['pwd_confirm']);

    // Validate input
    if (empty($prenom) || empty($nom) || empty($email) || empty($role) || empty($login) || empty($pwd) || empty($pwd_confirm)) {
        $error = "Tous les champs sont requis.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format d'email invalide.";
    } elseif ($pwd !== $pwd_confirm) {
        $error = "Les mots de passe ne correspondent pas.";
    } else {
        // Check if the login or email already exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR login = ?");
        $stmt->bind_param("ss", $email, $login);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "L'email ou le login existe déjà.";
        } else {
            // Insert the new user into the database
            $stmt = $conn->prepare("INSERT INTO users (prenom, nom, email, role, login, pwd) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $prenom, $nom, $email, $role, $login, $pwd);

            if ($stmt->execute()) {
                $success = "Inscription réussie !</a>.";
            } else {
                $error = "Erreur lors de l'inscription. Veuillez réessayer.";
            }
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Inscription - CIREP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            background-color: #5DADE2;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #3498DB;
            color: white;
            padding: 15px 20px;
        }

        header img {
            width: 60px;
            height: auto;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            gap: 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            padding: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            padding: 20px;
        }

        .sidebar {
            width: 200px;
            background: #f4f4f4;
            border: 1px solid #ddd;
            padding: 15px;
        }

        .sidebar h3 {
            margin-bottom: 15px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            text-decoration: none;
            color: #333;
        }

        .register-container {
            flex: 1;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        label {
            width: 30%;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="email"], input[type="password"], select {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            background-color: #3498DB;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #5DADE2;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
<style>
    .error {
        color: red;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #ffe6e6;
        padding: 10px;
        border: 1px solid red;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .error-icon {
        color: red;
        font-size: 18px;
    }

    .success {
        color: green;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #e6ffe6;
        padding: 10px;
        border: 1px solid green;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .success-icon {
        color: green;
        font-size: 18px;
    }
</style>

   <header>
        
        <h1 style='color:white'>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <div class="navbar">
        <a href="dashboard.php">Accueil</a>
        <a href="register.php">Users</a>
        <a href="#">Paramètres</a>
        <a href="logout.php">Déconnexion</a>
    </div>

    <div class="main-content">
       <div class="sidebar">
    <h3>Liens rapides</h3>
    <ul>
        <li><a href="register.php">Ajouter un utilisateur</a></li>
        <li><a href="g_institution.php">Ajouter une institution</a></li>
        <li><a href="g_programmes.php">Programmes ou formations organisées / faculté </a></li>
        <li><a href="g_type_diplome.php">Type de diplôme à délivrer </a></li>
        <li><a href="g_filiere.php">Filières ou départements </a></li>
        <li><a href="s_inscription.php">Situation des inscriptions </a></li>
		  <li><a href="g_cours.php">Gestion des cours </a></li>
        <li><a href="g_Resultats.php">Gestion des résultats </a></li>
        <li><a href="#">Voir les rapports</a></li>
    </ul>
</div>
<style>
    .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.update-link {
    display: inline-block;
    text-decoration: none;
    font-size: 16px;
    color: white;
    background-color: #3498DB; /* Bleu */
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.update-link:hover {
    background-color: #2C81BA; /* Couleur légèrement plus foncée au survol */
    transform: scale(1.05); /* Agrandir légèrement au survol */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
}
</style>


        <div class="register-container">
		<a href="dashboard.php" class="update-link">Mise à jour des utilisateurs</a>


            <h1 style='color:#3498DB'>Enregistrez un utilisateur dans le système CIREP catalogue</h1>
            <?php if (!empty($error)): ?>
				<p class="error">
					<span class="error-icon">&#10060;</span> <!-- Error Icon -->
					<?php echo $error; ?>
				</p>
			<?php endif; ?>

			<?php if (!empty($success)): ?>
				<p class="success">
					<span class="success-icon">&#10004;</span> <!-- Success Icon -->
					<?php echo $success; ?>
				</p>
			<?php endif; ?>

            <form method="POST" action="register.php">
                <div class="form-group">
                    <label for="prenom">Prénom :</label>
                    <input type="text" name="prenom" id="prenom" required>
                </div>
                <div class="form-group">
                    <label for="nom">Nom :</label>
                    <input type="text" name="nom" id="nom" required>
                </div>
                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="form-group">
                    <label for="role">Rôle :</label>
                    <select name="role" id="role" required>
                        <option value="Enseignant">Enseignant</option>
                        <option value="admin">Administrateur</option>
                         <option value="DG">DG</option>
                         <option value="Finances">Comptable/Finances</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="login">Identifiant :</label>
                    <input type="text" name="login" id="login" required>
                </div>
               <div class="form-group">
				<label for="pwd">Mot de passe :</label>
				<div style="display: flex; align-items: center; position: relative;">
					<input type="password" name="pwd" id="pwd" required style="flex: 1; padding-right: 30px;">
					<span id="toggle_pwd" style="position: absolute; right: 10px; cursor: pointer;">
						<i class="fas fa-eye" id="pwd_icon"></i>
					</span>
				</div>
			</div>
			<div class="form-group">
				<label for="pwd_confirm">Confirmer le mot de passe :</label>
				<div style="display: flex; align-items: center; position: relative;">
					<input type="password" name="pwd_confirm" id="pwd_confirm" required style="flex: 1; padding-right: 30px;">
					<span id="toggle_pwd_confirm" style="position: absolute; right: 10px; cursor: pointer;">
						<i class="fas fa-eye" id="pwd_confirm_icon"></i>
					</span>
				</div>
			</div>
			<script>
				document.getElementById('toggle_pwd').addEventListener('click', function() {
					const pwdField = document.getElementById('pwd');
					const pwdIcon = document.getElementById('pwd_icon');
					if (pwdField.type === 'password') {
						pwdField.type = 'text';
						pwdIcon.className = 'fas fa-eye-slash'; // Change to "eye-slash" icon
					} else {
						pwdField.type = 'password';
						pwdIcon.className = 'fas fa-eye'; // Change back to "eye" icon
					}
				});

				document.getElementById('toggle_pwd_confirm').addEventListener('click', function() {
					const pwdConfirmField = document.getElementById('pwd_confirm');
					const pwdConfirmIcon = document.getElementById('pwd_confirm_icon');
					if (pwdConfirmField.type === 'password') {
						pwdConfirmField.type = 'text';
						pwdConfirmIcon.className = 'fas fa-eye-slash'; // Change to "eye-slash" icon
					} else {
						pwdConfirmField.type = 'password';
						pwdConfirmIcon.className = 'fas fa-eye'; // Change back to "eye" icon
					}
				});
			</script>


                <button type="submit">Valider les données</button>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. Tous droits réservés.</p>
    </footer>
	

</body>
</html>
