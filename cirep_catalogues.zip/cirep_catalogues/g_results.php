<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['id_enseignant'])) {
    header("Location: login.php");
    exit;
}

$id_enseignant = $_SESSION['id_enseignant'];

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les étudiants avec leurs cours attribués à cet enseignant
$sql = "
    SELECT 
        i.inscription_id,
        i.first_name,
        i.last_name,
        i.filiere,
        c.cours_id,
        c.code AS code_cours,
        c.intitule_cours,
        c.credit,
        (SELECT note FROM notes WHERE notes.inscription_id = i.inscription_id AND notes.cours_id = c.cours_id LIMIT 1) AS note_existante
    FROM 
        inscriptions i
    JOIN 
        filieres_departements f ON f.filieres_departements_designation = i.filiere
    JOIN 
        cours c ON c.id_filieres_departements = f.id_filieres_departements
    JOIN 
        attribution_cours ac ON ac.cours_id = c.cours_id
    WHERE 
        ac.id_enseignant = ?
    ORDER BY i.last_name, i.first_name, c.code
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_enseignant);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des étudiants et cours</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        main {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0077b6;
            color: white;
        }

        .actions button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        .actions button:hover {
            background-color: #45a049;
        }

        .back-button {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color: #0077b6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-button:hover {
            background-color: #0056b3;
        }

        .already-rated {
            color: #ff0000;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Liste des étudiants à coter pour vos cours</h1>
    </header>
    <main>
        <!-- Bouton de retour au tableau de bord -->
        <a href="dashboardEns.php" class="back-button">Retour au tableau de bord</a>

        <table>
            <thead>
                <tr>
                    <th>Étudiant</th>
                    <th>Filière</th>
                    <th>Code Cours</th>
                    <th>Intitulé</th>
                    <th>Crédits</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($student['filiere']); ?></td>
                        <td><?php echo htmlspecialchars($student['code_cours']); ?></td>
                        <td><?php echo htmlspecialchars($student['intitule_cours']); ?></td>
                        <td><?php echo htmlspecialchars($student['credit']); ?></td>
                        <td class="actions">
                            <?php if ($student['note_existante'] !== null): ?>
                                <span class="already-rated">Déjà coté</span>
                            <?php else: ?>
                                <form method="POST" action="rate_course.php">
                                    <input type="hidden" name="inscription_id" value="<?php echo htmlspecialchars($student['inscription_id']); ?>">
                                    <input type="hidden" name="cours_id" value="<?php echo htmlspecialchars($student['cours_id']); ?>">
                                    <button type="submit">Coter</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
