<?php
// Start session
session_start();

// Database connection
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the teacher is logged in
if (!isset($_SESSION['id_enseignant'])) {
    echo "<div class='error-message'>Vous devez être connecté pour voir vos cours.</div>";
    exit;
}

$id_enseignant = $_SESSION['id_enseignant'];
$nomcomplet = $_SESSION['nomcomplet'];

// Query to fetch all courses assigned to the logged-in teacher
$sql = "
    SELECT 
        cours.code AS code_cours,
        cours.intitule_cours AS designation_cours,
        cours.credit AS credit,
        cours.type_pro AS type_pro,
        filieres_departements.filieres_departements_designation AS designation_filiere
    FROM 
        attribution_cours
    INNER JOIN 
        cours ON attribution_cours.cours_id = cours.cours_id
    INNER JOIN 
        filieres_departements  ON cours.id_filieres_departements = filieres_departements.id_filieres_departements
    WHERE 
        attribution_cours.id_enseignant = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_enseignant);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vos Cours Attribués</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #4CAF50;
            margin-top: 20px;
        }

        p {
            font-size: 1.2em;
        }

        .table-container {
            width: 90%;
            max-width: 1200px;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table thead {
            background-color: #4CAF50;
            color: white;
        }

        table th, table td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .no-courses {
            color: #555;
            font-size: 1.2em;
            margin-top: 20px;
        }

        .error-message {
            color: red;
            font-size: 1.2em;
            margin-top: 20px;
        }

        .back-button {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1em;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .back-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <!-- Button to go back to dashboard -->
    <a href="dashboardEns.php" class="back-button">Retour au tableau de bord</a>

    <h2>Bonjour cher enseignant <?php echo htmlspecialchars($nomcomplet); ?>,</h2>

    <?php if ($result->num_rows > 0): ?>
        <p>Voici vos cours attribués dans différentes filières ou facultés :</p>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Code Cours</th>
                        <th>Désignation Cours</th>
                        <th>Crédit</th>
                        <th>Type Pro</th>
                        <th>Désignation de la Filière</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['code_cours']); ?></td>
                            <td><?php echo htmlspecialchars($row['designation_cours']); ?></td>
                            <td><?php echo htmlspecialchars($row['credit']); ?></td>
                            <td><?php echo htmlspecialchars($row['type_pro']); ?></td>
                            <td><?php echo htmlspecialchars($row['designation_filiere']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="no-courses">Vous n'avez aucun cours attribué pour le moment.</p>
    <?php endif; ?>

    <?php 
    $stmt->close();
    $conn->close();
    ?>
</body>
</html>
