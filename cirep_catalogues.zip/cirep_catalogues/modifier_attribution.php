<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set UTF-8 charset
$conn->set_charset("utf8mb4");

// Check if ID is provided
if (!isset($_GET['id'])) {
    header("Location: mise_en_forme_attributionDG.php");
    exit;
}

$attribution_id = intval($_GET['id']);

// Fetch attribution details
$sql = "SELECT * FROM attribution_cours WHERE id_attribution = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $attribution_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: mise_en_forme_attributionDG.php");
    exit;
}

$attribution = $result->fetch_assoc();
$stmt->close();

// Fetch options for enseignants and cours
$enseignants = $conn->query("SELECT id_enseignant, nomcomplet FROM enseignant");
$cours_list = $conn->query("SELECT cours_id, intitule_cours FROM cours");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $annee_academique = htmlspecialchars(trim($_POST['annee_academique']), ENT_QUOTES, 'UTF-8');
    $id_enseignant = intval($_POST['id_enseignant']);
    $cours_id = intval($_POST['cours_id']);

    // Validate inputs
    if (empty($annee_academique) || $id_enseignant === 0 || $cours_id === 0) {
        $error = "Tous les champs sont obligatoires.";
    } else {
        // Update the attribution
        $update_query = "UPDATE attribution_cours SET annee_academique = ?, id_enseignant = ?, cours_id = ? WHERE id_attribution = ?";
        $stmt_update = $conn->prepare($update_query);
        $stmt_update->bind_param("siii", $annee_academique, $id_enseignant, $cours_id, $attribution_id);

        if ($stmt_update->execute()) {
            $success = "Attribution mise à jour avec succès.";
            header("Location: mise_en_forme_attributionDG.php");
            exit;
        } else {
            $error = "Erreur lors de la mise à jour : " . $stmt_update->error;
        }

        $stmt_update->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Attribution - CIREP</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { margin: 20px auto; padding: 20px; max-width: 600px; background: white; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
        h1 { text-align: center; color: #333; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        input, select, button { width: 100%; padding: 10px; margin: 5px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { background-color: #3498DB; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #5DADE2; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 5px; }
        .error { background-color: #ffe6e6; color: red; }
        .success { background-color: #e6ffe6; color: green; }
        .btn-back { background-color: #2ecc71; color: white; text-decoration: none; padding: 10px 20px; border-radius: 5px; display: inline-block; margin-bottom: 15px; }
        .btn-back:hover { background-color: #27ae60; }
    </style>
</head>
<body>
    <div class="container">
        <a href="mise_en_forme_attributionDG.php" class="btn-back">Retour</a>
        <h1>Modifier l'Attribution</h1>
        
        <?php if (!empty($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
            <div class="message success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="annee_academique">Année Académique :</label>
                <input type="text" id="annee_academique" name="annee_academique" value="<?php echo htmlspecialchars($attribution['annee_academique']); ?>" required>
            </div>
            <div class="form-group">
                <label for="id_enseignant">Enseignant :</label>
                <select id="id_enseignant" name="id_enseignant" required>
                    <option value="" disabled>-- Sélectionnez un enseignant --</option>
                    <?php while ($enseignant = $enseignants->fetch_assoc()): ?>
                        <option value="<?php echo $enseignant['id_enseignant']; ?>" <?php echo $attribution['id_enseignant'] == $enseignant['id_enseignant'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($enseignant['nomcomplet']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="cours_id">Cours :</label>
                <select id="cours_id" name="cours_id" required>
                    <option value="" disabled>-- Sélectionnez un cours --</option>
                    <?php while ($cours = $cours_list->fetch_assoc()): ?>
                        <option value="<?php echo $cours['cours_id']; ?>" <?php echo $attribution['cours_id'] == $cours['cours_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cours['intitule_cours']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <button type="submit">Mettre à jour</button>
        </form>
    </div>
</body>
</html>
