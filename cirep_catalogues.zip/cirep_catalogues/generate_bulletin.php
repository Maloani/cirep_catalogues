<?php
// Démarrer la session
session_start();

// Vérifier si l'étudiant est connecté
if (!isset($_SESSION['matricule'])) {
    header("Location: student_login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les informations de l'étudiant et la déclaration de paiement
$matricule = $_SESSION['matricule'];
$sql = "
    SELECT 
        i.first_name, 
        i.last_name, 
        i.date_of_birth, 
        i.place_of_birth, 
        i.country,
        f.filieres_departements_designation AS filiere,
        p.designation_programmes AS faculte,
        dp.classe,
        dp.annee_academique
    FROM 
        inscriptions i
    JOIN 
        filieres_departements f ON f.filieres_departements_designation = i.filiere
    JOIN 
        programmes_formations p ON p.id_programmes = f.id_programmes
    JOIN 
        declarations_paiements dp ON dp.inscription_id = i.inscription_id
    WHERE 
        i.matricule = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $matricule);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    die("Aucune inscription ou déclaration de paiement trouvée pour le matricule : " . htmlspecialchars($matricule));
}
$stmt->close();

// Récupérer les cours et les notes associés à l'étudiant
$sql_courses = "
    SELECT 
        dp.classe,
        dp.annee_academique,
        c.code AS code_cours,
        c.intitule_cours,
        c.credit,
        n.note
    FROM 
        cours c
    JOIN 
        filieres_departements f ON c.id_filieres_departements = f.id_filieres_departements
    JOIN 
        inscriptions i ON i.filiere = f.filieres_departements_designation
    JOIN 
        attribution_cours ac ON ac.cours_id = c.cours_id
    JOIN 
        declarations_paiements dp ON dp.inscription_id = i.inscription_id
    LEFT JOIN 
        notes n ON n.cours_id = c.cours_id AND n.inscription_id = i.inscription_id
    WHERE 
        i.matricule = ?
    ORDER BY dp.classe, c.code
";

$stmt_courses = $conn->prepare($sql_courses);
$stmt_courses->bind_param("s", $matricule);
$stmt_courses->execute();
$courses_result = $stmt_courses->get_result();

$courses_by_class = [];
$total_credits = 0;
$total_credits_possible = 0;
$total_notes = 0;

while ($row = $courses_result->fetch_assoc()) {
    $classe = $row['classe'];
    $courses_by_class[$classe][] = $row;

    $total_credits_possible += $row['credit'] * 100; // Le total possible est 100 par crédit
    if ($row['note'] !== null) {
        $total_credits += $row['credit'];
        $total_notes += $row['note'] * $row['credit'];
    }
}
$stmt_courses->close();
$conn->close();

// Calcul du pourcentage
$percentage = $total_credits_possible > 0 ? ($total_notes / $total_credits_possible) * 100 : 0;

// Attribution de la mention
if ($percentage >= 90 && $percentage <= 99) {
    $mention = "Plus Grande Distinction";
} elseif ($percentage >= 80 && $percentage <= 89) {
    $mention = "Grande Distinction";
} elseif ($percentage >= 70 && $percentage <= 79) {
    $mention = "Distinction";
} elseif ($percentage >= 60 && $percentage <= 69) {
    $mention = "Satisfaction";
} elseif ($percentage >= 50 && $percentage <= 59) {
    $mention = "Passable";
} else {
    $mention = "Échec";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord étudiant</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* Menu principal */
        nav {
            background-color: #004080;
            padding: 10px;
        }

        nav .menu {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        nav .menu a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            font-size: 16px;
        }

        nav .menu a:hover {
            background-color: #0056b3;
        }

        /* Icône pour le menu hamburger */
        .menu-toggle {
            display: none;
            background-color: #004080;
            border: none;
            color: white;
            font-size: 20px;
            padding: 10px;
            cursor: pointer;
        }

        /* Affichage du menu sur mobile */
        @media (max-width: 768px) {
            nav .menu {
                display: none;
                flex-direction: column;
                align-items: center;
            }

            nav .menu a {
                width: 100%;
                text-align: center;
            }

            nav .menu.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }

        main {
            padding: 20px;
        }

        .container {
            margin-bottom: 20px;
        }

        .container h2 {
            color: #0077b6;
            margin-bottom: 15px;
        }

        .container table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0077b6;
            color: white;
        }

        .actions a {
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 8px 15px;
            border-radius: 5px;
            margin-right: 10px;
        }

        .actions a:hover {
            background-color: #3e8e41;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        nav .menu a.active {
    background-color: #0056b3;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    color: #fff;
}

.pagination {
    margin-top: 20px;
    text-align: center;
}

.pagination .btn {
    display: inline-block;
    padding: 10px 20px;
    margin: 5px;
    background-color: #0077b6;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.pagination .btn:hover {
    background-color: #0056b3;
}

    </style>
    <script>
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }
    </script>
</head>
<body>
    <!-- En-tête -->

    <!-- Menu principal -->
     <nav>
    <button class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i> Menu
    </button>
    <div class="menu">
        <?php
        // Détecter la page actuelle
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>
         <a href="dashboard_student.php" class="<?php echo $current_page == 'dashboard_student.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Accueil
        </a>
        <a href="mes_courses.php" class="<?php echo $current_page == 'mes_courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> Mes cours
        </a>
        <a href="all_preve.php" class="<?php echo $current_page == 'all_preve.php' ? 'active' : ''; ?>">
            <i class="fas fa-id-card"></i> Mes preuves de paiement
        </a>
        <a href="generate_bulletin.php" class="<?php echo $current_page == 'generate_bulletin.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i> Bulletin de notes
        </a>
      
        <a href="process_declaration.php" class="<?php echo $current_page == 'process_declaration.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Déclarer le paiement
        </a>
        <a href="mes_dossiers.php" class="<?php echo $current_page == 'mes_dossiers.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Envoyer votre dossier
        </a>
        <a href="student_logout.php" class="<?php echo $current_page == 'student_logout.php' ? 'active' : ''; ?>">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </a>
    </div>
</nav>

    <header>
        <h1>RELEVÉ DE NOTES</h1><!-- Bouton pour générer le PDF -->
    <a href="results_view.php" class="btn-download">Télécharger en PDF</a>
    </header>

    <section class="student-info">
        <p><strong>Noms et Prénom :</strong> <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></p>
        <p><strong>Date et lieu de naissance :</strong> Né le <?php echo htmlspecialchars(date("d M Y", strtotime($student['date_of_birth']))); ?> à <?php echo htmlspecialchars($student['place_of_birth']); ?>, <?php echo htmlspecialchars($student['country']); ?></p>
        <p><strong>Option :</strong> <?php echo htmlspecialchars($student['faculte']); ?> (Option : <?php echo htmlspecialchars($student['filiere']); ?>). Année Académique <?php echo htmlspecialchars($student['annee_academique']); ?></p>
    </section>

    <table>
        <thead>
            <tr>
                <th>Classe / Année</th>
                <th>Code</th>
                <th>Titre des cours</th>
                <th>Crédit</th>
                <th>Notes / 100</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total_credits = 0;
            $total_notes = 0;
            $total_courses = 0;
            $current_classe = '';

            foreach ($courses_by_class as $classe => $courses) {
                $first_row = true;
                $class_credits = 0;
                foreach ($courses as $course) {
                    echo '<tr>';
                    if ($first_row) {
                        echo '<td rowspan="' . count($courses) . '">' . htmlspecialchars($classe) . '</td>';
                        $first_row = false;
                    }
                    echo '<td>' . htmlspecialchars($course['code_cours']) . '</td>';
                    echo '<td>' . htmlspecialchars($course['intitule_cours']) . '</td>';
                    echo '<td>' . htmlspecialchars($course['credit']) . '</td>';
                    echo '<td>' . ($course['note'] !== null ? htmlspecialchars($course['note']) : 'Non attribuée') . '</td>';
                    echo '</tr>';
                    $class_credits += $course['credit'];
                    if ($course['note'] !== null) {
                        $total_notes += $course['note'] * $course['credit'];
                    }
                    $total_courses++;
                }
                echo '<tr class="total-row"><td colspan="3">Total Crédits pour ' . htmlspecialchars($classe) . '</td><td colspan="2">' . $class_credits . '</td></tr>';
                $total_credits += $class_credits;
            }
            ?>
        </tbody>
    </table>

    <section class="final-summary">
        <p><strong>Total Crédits :</strong> <?php echo $total_credits; ?></p>
        <p><strong>Pourcentage Total :</strong> <?php echo number_format($percentage); ?>%</p>
        <p><strong>Mention :</strong> <?php echo htmlspecialchars($mention); ?></p>
    </section>
    
    <footer><p>Fait à LISALA, le <?php echo date("d/m/Y"); ?></p>
        <p>Pr. J.Baptiste NIZEYIMANA</p>
        
        <p>Directeur Général du CIREP</p>
    </footer>
</body>
</html>
