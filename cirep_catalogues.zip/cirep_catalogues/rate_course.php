<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['id_enseignant'])) {
    header("Location: login.php");
    exit;
}

$id_enseignant = $_SESSION['id_enseignant'];

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les données du formulaire
$inscription_id = $_POST['inscription_id'] ?? null;
$cours_id = $_POST['cours_id'] ?? null;

if (!$inscription_id || !$cours_id) {
    die("Données manquantes.");
}

// Récupérer les informations de l'étudiant et du cours
$sql = "
    SELECT 
        i.first_name,
        i.last_name,
        c.intitule_cours,
        c.code
    FROM 
        inscriptions i
    JOIN 
        cours c ON c.cours_id = ?
    WHERE 
        i.inscription_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $cours_id, $inscription_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Étudiant ou cours non trouvé.");
}

$data = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note'])) {
    $note = $_POST['note'];
    $date_attribution = date("Y-m-d");

    $insert_sql = "
        INSERT INTO notes (inscription_id, cours_id, note, date_attribution) 
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE note = VALUES(note), date_attribution = VALUES(date_attribution)
    ";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("iiis", $inscription_id, $cours_id, $note, $date_attribution);

    if ($insert_stmt->execute()) {
        $success = "Note attribuée avec succès.";
    } else {
        $error = "Erreur lors de l'attribution de la note.";
    }
    $insert_stmt->close();
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attribuer une note</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        h2 {
            color: #0077b6;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: white;
            background-color: #0077b6;
            padding: 10px 15px;
            border-radius: 5px;
            text-align: center;
        }

        .back-button:hover {
            background-color: #0056b3;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Attribuer une note</h2>
        <?php if (isset($success)): ?>
            <div class="message success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <p><strong>Étudiant :</strong> <?php echo htmlspecialchars($data['first_name'] . ' ' . $data['last_name']); ?></p>
        <p><strong>Cours :</strong> <?php echo htmlspecialchars($data['intitule_cours']); ?> (<?php echo htmlspecialchars($data['code']); ?>)</p>

        <form method="POST">
            <input type="hidden" name="inscription_id" value="<?php echo htmlspecialchars($inscription_id); ?>">
            <input type="hidden" name="cours_id" value="<?php echo htmlspecialchars($cours_id); ?>">

            <div class="form-group">
                <label for="note">Note (/100) :</label>
                <input type="number" name="note" id="note" min="0" max="100" required>
            </div>

            <button type="submit">Attribuer</button>
        </form>

        <a href="g_results.php" class="back-button">Retour à la liste des étudiants</a>
    </div>
</body>
</html>
