<?php
require_once 'fpdf/fpdf.php';

// Démarrer la session
session_start();

// Vérifier si l'étudiant est connecté
if (!isset($_SESSION['matricule'])) {
    header("Location: student_login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les informations de l'étudiant et la déclaration de paiement
$matricule = $_SESSION['matricule'];
$sql = "
    SELECT 
        i.first_name, 
        i.last_name, 
        i.date_of_birth, 
        i.place_of_birth, 
        i.country,
        f.filieres_departements_designation AS filiere,
        p.designation_programmes AS faculte,
        dp.classe,
        dp.annee_academique
    FROM 
        inscriptions i
    JOIN 
        filieres_departements f ON f.filieres_departements_designation = i.filiere
    JOIN 
        programmes_formations p ON p.id_programmes = f.id_programmes
    JOIN 
        declarations_paiements dp ON dp.inscription_id = i.inscription_id
    WHERE 
        i.matricule = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $matricule);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    die("Aucune inscription ou déclaration de paiement trouvée pour le matricule : " . htmlspecialchars($matricule));
}
$stmt->close();

// Récupérer les cours et les notes associés à l'étudiant
$sql_courses = "
    SELECT 
        dp.classe,
        dp.annee_academique,
        c.code AS code_cours,
        c.intitule_cours,
        c.credit,
        n.note
    FROM 
        cours c
    JOIN 
        filieres_departements f ON c.id_filieres_departements = f.id_filieres_departements
    JOIN 
        inscriptions i ON i.filiere = f.filieres_departements_designation
    JOIN 
        attribution_cours ac ON ac.cours_id = c.cours_id
    JOIN 
        declarations_paiements dp ON dp.inscription_id = i.inscription_id
    LEFT JOIN 
        notes n ON n.cours_id = c.cours_id AND n.inscription_id = i.inscription_id
    WHERE 
        i.matricule = ?
    ORDER BY dp.classe, c.code
";

$stmt_courses = $conn->prepare($sql_courses);
$stmt_courses->bind_param("s", $matricule);
$stmt_courses->execute();
$courses_result = $stmt_courses->get_result();

$courses_by_class = [];
while ($row = $courses_result->fetch_assoc()) {
    $classe = $row['classe'];
    $courses_by_class[$classe][] = $row;
}
$stmt_courses->close();
$conn->close();

// Générer le PDF avec FPDF
$pdf = new FPDF();
$pdf->AddPage();

// Ajouter le logo à gauche
$pdf->Image('img/logo.PNG', 10, 10, 30); // Chemin vers votre logo
$pdf->SetFont('Arial', 'B', 14);

// En-tête
$pdf->SetY(10);
$pdf->SetX(50);
$pdf->Cell(0, 10, 'CENTRE INTERNATIONAL DE RECHERCHE PLURIDISCIPLINAIRE', 0, 1, 'C');
$pdf->SetX(50);
$pdf->Cell(0, 10, 'RELEVE DE NOTES', 0, 1, 'C');
$pdf->Ln(20);

// Informations sur l'étudiant
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Noms et Prenom : ' . $student['first_name'] . ' ' . $student['last_name'], 0, 1);
$pdf->Cell(0, 10, 'Date et lieu de Naissance : Ne le ' . date("d M Y", strtotime($student['date_of_birth'])) . ' a ' . $student['place_of_birth'] . ', ' . $student['country'], 0, 1);
$pdf->Cell(0, 10, 'Option : ' . $student['faculte'] . ' (Option : ' . $student['filiere'] . ')', 0, 1);
$pdf->Cell(0, 10, 'Annee Academique : ' . $student['annee_academique'], 0, 1);
$pdf->Ln(10);

// Tableau des cours
foreach ($courses_by_class as $classe => $courses) {
    // Classe dans le tableau
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Classe : ' . $classe, 0, 1);

    // En-tête du tableau
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(40, 10, 'Code', 1);
    $pdf->Cell(90, 10, 'Titre des cours', 1);
    $pdf->Cell(30, 10, 'Credit', 1);
    $pdf->Cell(30, 10, 'Note/100', 1);
    $pdf->Ln();

    // Contenu des cours
    $class_total_credits = 0;
    foreach ($courses as $course) {
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(40, 10, $course['code_cours'], 1);
        $pdf->Cell(90, 10, $course['intitule_cours'], 1);
        $pdf->Cell(30, 10, $course['credit'], 1);
        $pdf->Cell(30, 10, $course['note'] !== null ? $course['note'] : 'Non attribuee', 1);
        $pdf->Ln();
        $class_total_credits += $course['credit'];
    }

    // Total des crédits pour la classe dans la colonne "Crédits"
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(130, 10, 'Total Credits pour ' . $classe, 1);
    $pdf->Cell(30, 10, $class_total_credits, 1, 0, 'C');
    $pdf->Cell(30, 10, '', 1); // Colonne vide pour "Notes"
    $pdf->Ln(10);
}

// Footer
$pdf->SetFont('Arial', '', 10);
$pdf->Ln(20);
$pdf->Cell(0, 10, 'Fait a LISALA, le ' . date("d/m/Y"), 0, 1);
$pdf->Cell(0, 10, 'Pr. J.Baptiste NIZEYIMANA', 0, 1);
$pdf->Cell(0, 10, 'Directeur General du CIREP', 0, 1);

// Sortie du fichier PDF
$pdf->Output('D', 'Releve_de_notes.pdf');
?>
