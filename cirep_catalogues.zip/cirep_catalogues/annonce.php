<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté (remplacez la condition selon votre gestion des sessions)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Message de retour
$message = "";

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = trim($_POST['titre']);
    $contenu = trim($_POST['contenu']);

    if (!empty($titre) && !empty($contenu)) {
        $sql = "INSERT INTO annonces (titre, contenu) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $titre, $contenu);

        if ($stmt->execute()) {
            $message = "Annonce enregistrée avec succès.";
        } else {
            $message = "Erreur lors de l'enregistrement : " . $stmt->error;
        }

        $stmt->close();
    } else {
        $message = "Veuillez remplir tous les champs.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer une annonce</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f9f9f9; margin: 0; padding: 0;">

    <!-- Conteneur principal -->
    <div style="width: 60%; margin: auto; background-color: #fff; padding: 20px; margin-top: 50px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <h2 style="text-align: center; color: #007BFF;">Créer une nouvelle annonce</h2>

        <!-- Bouton retour -->
        <div style="margin-bottom: 20px; text-align: center;">
            <a href="dashboard.php" style="padding: 10px 15px; background-color: #3498DB; color: white; text-decoration: none; border-radius: 5px; font-size: 14px;">Retour au tableau de bord</a>
        </div>

        <!-- Formulaire d'ajout d'annonce -->
        <form action="annonce.php" method="post" style="display: flex; flex-direction: column; gap: 15px;">
            <!-- Titre de l'annonce -->
            <div>
                <label for="titre" style="font-size: 14px; color: #333;">Titre de l'annonce :</label>
                <input type="text" id="titre" name="titre" placeholder="Entrez le titre de l'annonce" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
            </div>

            <!-- Contenu de l'annonce -->
            <div>
                <label for="contenu" style="font-size: 14px; color: #333;">Contenu de l'annonce :</label>
                <textarea id="contenu" name="contenu" placeholder="Entrez le contenu de l'annonce" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; height: 150px;"></textarea>
            </div>

            <!-- Bouton de soumission -->
            <button type="submit" style="padding: 10px 15px; background-color: #007BFF; color: white; border: none; border-radius: 5px; font-size: 14px; cursor: pointer;">Enregistrer l'annonce</button>
        </form>

        <!-- Message de retour -->
        <?php if (!empty($message)): ?>
            <div style="margin-top: 20px; padding: 10px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 5px;">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>
