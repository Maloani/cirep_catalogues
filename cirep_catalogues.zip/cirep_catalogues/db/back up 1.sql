-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 16, 2024 at 03:35 PM
-- Server version: 8.0.39-cll-lve
-- PHP Version: 8.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `geoheininvest_heineken`
--

-- --------------------------------------------------------

--
-- Table structure for table `actualites`
--

CREATE TABLE `actualites` (
  `actuality_id` int NOT NULL,
  `titre` varchar(255) NOT NULL,
  `contenu` text NOT NULL,
  `dateHeure_publ` datetime NOT NULL,
  `user_id` int NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(55) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actualites`
--

INSERT INTO `actualites` (`actuality_id`, `titre`, `contenu`, `dateHeure_publ`, `user_id`, `image`, `status`) VALUES
(1, 'Appel Ã  candidatures 2024/25 â€“ Formations DiplÃ´mantes Ã€ Distance (FOAD) au CIREP', 'Vous Ãªtes un.e Ã©tudiant.e francophoneâ€¯ ?\r\nVous souhaitez intÃ©grer une formation ouverte et Ã  distance (FOAD) et obtenir un diplÃ´me universitaire sans quitter votre pays de rÃ©sidence ?\r\n\r\nConsultez le catalogue de CIREP des formations internationales Ã  distance et choisissez votre formation parmi les 153 formations universitaires diplÃ´mantes proposÃ©es par 55 Ã©tablissements universitaires de 15 pays : https://cirep.ac.cd/catalogue-formations-diplomantes/\r\n\r\nLe CIREP soutient, par lâ€™intermÃ©diaire de son Ã©cole doctorale dans divers pays du monde, les Ã©tudiants francophones souhaitant suivre une formation diplÃ´mante (FOAD) Ã  distance par :\r\n\r\n    Une allocation de mobilitÃ© virtuelle internationale sous forme dâ€™une prise en charge partielle voire totale des frais dâ€™inscription accessible aux Ã©tudiants les plus mÃ©ritants ou aux ressources limitÃ©es ;\r\n    Un accompagnement depuis la candidature jusquâ€™Ã  lâ€™obtention du diplÃ´me en passant par le suivi de la formation et lâ€™organisation des examens et des soutenances ;\r\n    Un accÃ¨s aux implantations de CIREP Ã  travers le monde durant tout le processus de la formation.', '2024-11-23 06:32:35', 1, 'uploads/add.jpeg', 'APPEL OUVERT'),
(3, 'Appel Ã  projets Formations Ouvertes et Ã€ Distance (FOAD) 2025-26 au CIREP', 'Vous reprÃ©sentez un Ã©tablissement universitaire membre de CIREP et dÃ©livrant des formations diplÃ´mantes de qualitÃ© ? Vous souhaitez internationaliser ces formations et de les rendre accessibles Ã  un public rÃ©parti gÃ©ographiquement dans lâ€™espace francophone, grÃ¢ce Ã  la transformation numÃ©rique des formations ?\r\n\r\nRÃ©pondez dÃ¨s maintenant Ã  notre appel Ã  projets. \r\nEn tant quâ€™Ã©tablissement universitaire membre de CIREP, vous bÃ©nÃ©ficierez dâ€™un accompagnement complet pour la transformation numÃ©rique de vos formations diplÃ´mantes et leur dÃ©ploiement Ã  lâ€™international. Cela englobe la promotion de la formation Ã  lâ€™international, lâ€™accompagnement Ã  la transformation numÃ©rique des formation et les appuis administratifs, financiers, logistiques et pÃ©dagogiques du rÃ©seau des implantations de CIREP dans le monde.', '2024-11-23 07:49:43', 1, 'uploads/forma.jpg', 'APPEL CLOS');

-- --------------------------------------------------------

--
-- Table structure for table `annonces`
--

CREATE TABLE `annonces` (
  `id` int NOT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `contenu` text,
  `date_publication` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `annonces`
--

INSERT INTO `annonces` (`id`, `titre`, `contenu`, `date_publication`) VALUES
(1, 'Rappel des inscriptions', 'Les inscriptions pour le semestre commencent le 10 janvier.', '2024-12-05 12:36:01'),
(2, 'Résultats disponibles', 'Les résultats du semestre précédent sont maintenant disponibles en ligne.', '2024-12-05 12:36:01'),
(3, 'Atelier de programmation', 'Participez à notre atelier Python ce week-end.', '2024-12-05 12:36:01'),
(4, 'Lancement du site de catalogue CIREP', 'Le Centre Interuniversitaire de Recherche Pluridisciplinaire (CIREP) est fier d\'annoncer le lancement de son tout nouveau site de catalogue. Conçu pour répondre aux besoins académiques et professionnels de la communauté universitaire, ce site offre un accès simplifié à une large gamme de ressources, notamment des articles scientifiques, des mémoires, des thèses, et des rapports de recherche. Grâce à une interface intuitive et des fonctionnalités avancées de recherche, les utilisateurs peuvent facilement trouver, consulter et télécharger les documents pertinents à leurs travaux. Cette initiative marque une étape importante dans l\'engagement du CIREP à promouvoir l\'excellence académique et à renforcer la visibilité des productions intellectuelles de ses chercheurs.', '2024-12-10 16:46:39');

-- --------------------------------------------------------

--
-- Table structure for table `attribution_cours`
--

CREATE TABLE `attribution_cours` (
  `id_attribution` int NOT NULL,
  `annee_academique` varchar(10) NOT NULL,
  `cours_id` int NOT NULL,
  `id_enseignant` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `attribution_cours`
--

INSERT INTO `attribution_cours` (`id_attribution`, `annee_academique`, `cours_id`, `id_enseignant`) VALUES
(4, '2024-2025', 13, 4),
(5, '2024-2025', 14, 4),
(6, '2024-2025', 15, 4);

-- --------------------------------------------------------

--
-- Table structure for table `carte`
--

CREATE TABLE `carte` (
  `id` int NOT NULL,
  `matricule` varchar(50) NOT NULL,
  `classe` varchar(100) NOT NULL,
  `annee_academique` varchar(20) NOT NULL,
  `logo_institution` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cours`
--

CREATE TABLE `cours` (
  `cours_id` int NOT NULL,
  `code` varchar(50) NOT NULL,
  `intitule_cours` varchar(255) NOT NULL,
  `credit` int NOT NULL,
  `type_pro` varchar(50) NOT NULL,
  `id_filieres_departements` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cours`
--

INSERT INTO `cours` (`cours_id`, `code`, `intitule_cours`, `credit`, `type_pro`, `id_filieres_departements`) VALUES
(12, 'HBFOOOO1', 'TECHNIQUES D&#039;EXPRESSION ORALES ET ECRITES', 25, 'Licence', 152),
(13, 'HBF00002', 'ANGLAIS COMMERCIAL', 20, 'Master', 152),
(14, 'HBF00003', 'DROIT CIVIL', 20, 'Master', 152),
(15, 'HBF00004', 'BUREAUTIQUE ET INTERNET', 25, 'Master', 152),
(16, 'HBF00005', 'ECONOMIE GENERALE', 20, 'Licence', 152),
(17, 'HBF00006', 'MARKETING DES SERVICES DE TRANSPORT', 25, 'Licence', 152),
(18, 'HBF00007', 'EVALUATION DU MARCHE', 20, 'Licence', 152),
(19, 'HBF00008', 'DE LA LOGISTIQUE AU SUPPLY CHAIN', 25, 'Licence', 152),
(20, 'HBF00009', 'ECONOMIE DES TRANSPORTS', 25, 'Licence', 152),
(21, 'HBF00010', 'Management des approvisionnements et des achats', 25, 'Licence', 152),
(22, 'HBF00011', 'Logistique de Production et de Distribution Physique', 25, 'Licence', 152),
(23, 'HBF00012', 'Levier d&#039;action Marketing', 20, 'Licence', 152),
(24, 'HBF00013', 'Manutention portuaire', 25, 'Licence', 152),
(25, 'HBF00014', 'Techniques maritimes et portuaires', 25, 'Licence', 152),
(26, 'HBF00015', 'Gestion des opérations de marchandises diverses', 25, 'Licence', 152),
(27, 'HBF00016', 'GESTION DE STOCK', 25, 'Licence', 152),
(28, 'HBF00017', 'Gestion des flux dans l&#039;entrepôt', 25, 'Licence', 152),
(29, 'HBF00018', 'Microéconomie', 20, 'Licence', 153),
(30, 'HBF00019', 'Marketing : fondements et concepts', 25, 'Licence', 153),
(31, 'HBF00020', 'Comptabilité analytique et de gestion', 25, 'Licence', 153),
(32, 'HBF00021', 'Taxe sur la valeur ajoutée', 25, 'Licence', 153),
(33, 'HBF00022', 'La Profession comptable, contrôle et financier', 30, 'Licence', 153),
(34, 'HBF00023', 'Comptabilité des sociétés', 24, 'Licence', 153);

-- --------------------------------------------------------

--
-- Table structure for table `cours_fichiers`
--

CREATE TABLE `cours_fichiers` (
  `id_fichier` int NOT NULL,
  `id_attribution` int NOT NULL,
  `nom_fichier` varchar(255) NOT NULL,
  `type_fichier` varchar(50) NOT NULL,
  `taille_fichier` int NOT NULL,
  `date_envoi` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cours_fichiers`
--

INSERT INTO `cours_fichiers` (`id_fichier`, `id_attribution`, `nom_fichier`, `type_fichier`, `taille_fichier`, `date_envoi`) VALUES
(1, 4, 'lisala Attestation de Participation AU SEMINAIRE RECHERCHE.docx', 'application/vnd.openxmlformats-officedocument.word', 58117, '2024-12-15 16:33:04'),
(2, 5, 'lisala Attestation de Participation AU SEMINAIRE RECHERCHE(1).docx', 'application/vnd.openxmlformats-officedocument.word', 58117, '2024-12-16 06:56:14'),
(3, 6, 'caneva.docx', 'application/vnd.openxmlformats-officedocument.word', 16274, '2024-12-16 06:56:35');

-- --------------------------------------------------------

--
-- Table structure for table `declarations_paiements`
--

CREATE TABLE `declarations_paiements` (
  `declaration_id` int NOT NULL,
  `inscription_id` int NOT NULL,
  `classe` varchar(255) NOT NULL,
  `annee_academique` varchar(255) NOT NULL,
  `somme` decimal(10,2) NOT NULL,
  `date_paiement` date NOT NULL,
  `motif` varchar(255) NOT NULL,
  `mode_paiement` varchar(50) NOT NULL,
  `photo_etudiant` varchar(255) NOT NULL,
  `photo_bordereau` varchar(255) NOT NULL,
  `date_declaration` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `declarations_paiements`
--

INSERT INTO `declarations_paiements` (`declaration_id`, `inscription_id`, `classe`, `annee_academique`, `somme`, `date_paiement`, `motif`, `mode_paiement`, `photo_etudiant`, `photo_bordereau`, `date_declaration`) VALUES
(2, 6, 'PhD I', '2024-2025', 8000.00, '2024-12-03', 'Frais d\'inscription', 'Western Union', 'uploads/etudiant_675586664730a_file.jpg', 'uploads/bordereau_675586664730e_CC.jpg', '2024-12-08 11:43:35');

-- --------------------------------------------------------

--
-- Table structure for table `dossiers_etudiants`
--

CREATE TABLE `dossiers_etudiants` (
  `dossiers_id` int NOT NULL,
  `inscription_id` int NOT NULL,
  `baccalaureat` varchar(255) DEFAULT NULL,
  `graduat` varchar(255) DEFAULT NULL,
  `releves_notes_graduat` varchar(255) DEFAULT NULL,
  `licence` varchar(255) DEFAULT NULL,
  `releves_notes_licence` varchar(255) DEFAULT NULL,
  `maitrise` varchar(255) DEFAULT NULL,
  `releves_notes_maitrise` varchar(255) DEFAULT NULL,
  `master` varchar(255) DEFAULT NULL,
  `releves_notes_master` varchar(255) DEFAULT NULL,
  `date_televersement` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `dossiers_etudiants`
--

INSERT INTO `dossiers_etudiants` (`dossiers_id`, `inscription_id`, `baccalaureat`, `graduat`, `releves_notes_graduat`, `licence`, `releves_notes_licence`, `maitrise`, `releves_notes_maitrise`, `master`, `releves_notes_master`, `date_televersement`) VALUES
(1, 6, 'uploads/Master/CIREP-MOG-2024_CHARGES HORAIRES.pdf', 'uploads/Master/CIREP-MOG-2024_CURRICULUM VITAE MALOANI SAIDI GEORGES.pdf', 'uploads/Master/CIREP-MOG-2024_CV JEANNE MANGA.pdf', 'uploads/Master/CIREP-MOG-2024_CV MALOANI SAIDI Georges chez IMA WORLD.pdf', 'uploads/Master/CIREP-MOG-2024_Lettre de motivation MALOANI SAIDI Georges chez ARC-CSU.pdf', NULL, NULL, NULL, NULL, '2024-12-10 15:03:21');

-- --------------------------------------------------------

--
-- Table structure for table `enseignant`
--

CREATE TABLE `enseignant` (
  `id_enseignant` int NOT NULL,
  `nomcomplet` varchar(255) NOT NULL,
  `sexe` varchar(25) NOT NULL,
  `niveau_etude` varchar(55) NOT NULL,
  `mail_enseignant` varchar(255) DEFAULT NULL,
  `contact` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `enseignant`
--

INSERT INTO `enseignant` (`id_enseignant`, `nomcomplet`, `sexe`, `niveau_etude`, `mail_enseignant`, `contact`, `login`, `password`) VALUES
(4, 'Maloani', 'M', 'Master', 'georgesmaloanis@gmail.com', '+226 60 20 16 5', 'kaka', 'kaka');

-- --------------------------------------------------------

--
-- Table structure for table `filieres_departements`
--

CREATE TABLE `filieres_departements` (
  `id_filieres_departements` int NOT NULL,
  `filieres_departements_designation` text NOT NULL,
  `objectif_filiere` text NOT NULL,
  `competence_vises` text NOT NULL,
  `metiers_cibles` text NOT NULL,
  `formation_type` varchar(50) NOT NULL,
  `id_programmes` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `filieres_departements`
--

INSERT INTO `filieres_departements` (`id_filieres_departements`, `filieres_departements_designation`, `objectif_filiere`, `competence_vises`, `metiers_cibles`, `formation_type`, `id_programmes`) VALUES
(152, 'Logistique transport et transit', 'La filière transport logistique vise à optimiser le déplacement et le stockage des marchandises afin d&amp;#039;assurer une chaîne d&amp;#039;approvisionnement efficace et fluide', 'Logistique transport douane et transit', 'Logisticien\r\nTransitaire', 'Master', 43),
(153, 'Technique Comptable et financière', 'Former des professionnels compétents en comptabilité et finance capables d\'analyser de gérer et de communiquer efficacement les informations financières pour soutenir la prise de décision stratégique au sein des organisations', 'Les compétences visées par la filière technique comptable et financière incluent \r\n\r\n1 Maîtrise des principes et normes comptables internationaux\r\n2 Capacité à analyser et interpréter les états financiers\r\n3 Connaissance des outils de gestion financière et budgétaire\r\n4 Compétence en audit et contrôle interne\r\n5 Aptitude à utiliser les logiciels comptables et financiers', '1 Comptable\r\n2 Contrôleur de gestion\r\n3 Analyste financier\r\n4 Auditeur interneexterne\r\n5 Responsable de la trésorerie\r\n6 Consultant en finance\r\n7 Gestionnaire de budget', 'Master', 42),
(154, 'COMPTABILTE CONTROLE ET AUDIT', 'Cette spécialisation se concentre sur la tenue des comptes dune entreprise la vérification de leur exactitude et laudit pour s\'assurer que les pratiques financières suivent les normes et règlements Elle inclut le contrôle de gestion pour optimiser les performances financières', '- COMPTABILITE\r\n- AUDIT', '- Auditeur financier  Externe ou interne il vérifie l\'exactitude des livres comptables et des états financiers et s\'assure que lentreprise est en conformité avec les lois et les régulations\r\n   - Chef comptable  Supervise l\'ensemble des activités comptables de l\'entreprise des entrées quotidiennes aux rapports financiers mensuels et annuels\r\n   - Contrôleur de gestion  Analyse les performances financières en rapport avec les budgets détecte les écarts et propose des mesures correctives', 'Master', 42),
(155, 'COMMUNICATION D\'ENTREPRISE', 'Cette filière traite des stratégies et des moyens utilisés par une organisation pour communiquer en interne avec ses employés et en externe avec ses clients partenaires et le grand public Elle couvre les relations publiques la communication corporative et la gestion de la réputation', 'COMMUNICATION', '- Responsable communication interne  Créé et met en œuvre des stratégies de communication destinées aux employés pour promouvoir la culture d\'entreprise et améliorer l\'engagement\r\n   - Chargé de communication  Gère la communication externe rédige les communiqués de presse crée des contenus pour les médias sociaux et supervise les relations publiques\r\n   - Directeur de la communication  Développe et gère la stratégie globale de communication de l\'entreprise y compris la gestion de la marque et les crises de communication', 'Master', 42),
(156, 'MARKETING ET COMMUNICATION', 'Elle combine les concepts de marketing analyse des marchés stratégies de promotion des produitsservices étude des comportements consommateurs avec les techniques de communication publicité relations publiques médias sociaux pour atteindre et engager les publics cibles', 'Marketing\r\ncommunication', '- Responsable marketing  Développe des stratégies pour promouvoir les produits ou services de l\'entreprise analyse le marché et suit l\'évolution de la concurrence\r\n   - Chef de produit  Gère un produit ou une gamme de produits depuis leur conception jusquà leur commercialisation\r\n   - Responsable des relations publiques  Gère limage de l\'entreprise auprès des médias et du public organise des événements et rédige des communiqués de presse\r\n   - Community manager  Gère et anime les communautés sur les réseaux sociaux répond aux commentaires et crée du contenu engageant', 'Master', 42),
(157, 'MANAGEMENT DES ORGANISATIONS ET DES PROJETS', 'Cette filière se concentre sur la planification l\'exécution et la clôture de projets en veillant au respect des délais des coûts et des standards de qualité Cela inclut la coordination des ressources humaines et matérielles pour atteindre les objectifs dun projet', 'MANAGEMENT', '- Chef de projet  Planifie exécute et clôture des projets en coordonnant les ressources les budgets et les délais pour atteindre les objectifs définis\r\n   - Directeur de projet  Supervise plusieurs chefs de projet gère des programmes complexes et veille à lalignement stratégique des projets\r\n   - Analyste de projet  Soutien le chef de projet dans l\'analyse des besoins la création de plans de projet et le suivi des performances\r\n   - Consultant en gestion de projet  Apporte une expertise et des conseils en gestion de projet à diverses organisations pour améliorer leurs processus et leurs résultats', 'Master', 42),
(158, 'GESTION DES RESSOURCES HUMAINES', 'Cette filière implique la gestion du personnel au sein d\'une organisation Elle couvre le recrutement la formation la gestion des performances les relations de travail la paie et le développement organisationnel pour améliorer à la fois la satisfaction des employés et lefficacité de lentreprise', 'GESTION HUMAINE', '- Responsable des ressources humaines RRH  Gère les politiques RH de l\'entreprise supervise le recrutement la formation et le développement des employés\r\n   - Chargé de recrutement  Responsable de la recherche de la sélection et de l\'intégration des nouveaux talents dans l\'entreprise\r\n   - Gestionnaire de la paie  Sassure que les employés sont payés correctement et à temps gère les déclarations sociales et fiscales liées à la paie\r\n   - Responsable formation  Développe et met en œuvre des programmes de formation pour les employés afin d\'améliorer leurs compétences et leur performance\r\n   - Consultant en RH  Apporte des conseils sur les stratégies RH et les meilleures pratiques pour améliorer la gestion du personnel et la satisfaction des employés', 'Master', 42),
(159, 'SYSTEMES RESEAUX INFORMATIQUES ET TELECOMS', 'L&amp;#039;objectif de la filière réseau informatique et télécoms est de former des professionnels capables de concevoir déployer et gérer des infrastructures de communication modernes et sécurisées Cela inclut la maîtrise des technologies réseau des protocoles de communication et des systèmes de sécurité pour répondre aux besoins des entreprises et des utilisateurs', '1 Conception et gestion des réseaux Savoir planifier concevoir et administrer des infrastructures réseau y compris les réseaux locaux LAN et étendus WAN\r\n  \r\n2 Sécurité des systèmes et des réseaux  Acquérir des compétences en matière de sécurité informatique pour protéger les données et les infrastructures contre les menaces et les intrusions\r\n\r\n3 Maintenance et dépannage  Être capable de diagnostiquer et résoudre des problèmes techniques liés aux réseaux et aux systèmes de communication\r\n\r\n4 Maîtrise des protocoles de communication Comprendre et appliquer les différents protocoles utilisés pour la transmission des données tels que TCPIP', '1 Ingénieur réseau Conçoit et met en œuvre des architectures réseau assure leur fonctionnement et leur sécurité\r\n\r\n2 Technicien en télécommunications Installe configure et maintient les équipements et infrastructures de communication\r\n\r\n3 Administrateur systèmes et réseaux  Gère et optimise les serveurs et les réseaux dune entreprise garantissant leur performance et leur sécurité\r\n\r\n4 Analyste en sécurité informatique  Évalue et renforce la sécurité des systèmes et des réseaux pour protéger contre les cybermenaces', 'Licence, Master', 43),
(160, 'GENIE LOGICIEL', '1 Conception et développement de logiciels  Former des professionnels capables de concevoir développer et maintenir des applications et systèmes logiciels de qualité\r\n\r\n2 Mise en œuvre des bonnes pratiques  Insister sur l\'utilisation de méthodologies et d\'outils de développement appropriés ainsi que sur les normes de qualité logicielle pour assurer la fiabilité et la performance des logiciels\r\n\r\n3 Gestion de projet logiciel  Acquérir des compétences en gestion de projet pour planifier coordonner et superviser le développement de logiciels dans le respect des délais et des budgets', 'DEVELLOPPEMENT D\'APPLICATION', '1 Développeur logiciel Conçoit code et teste des applications et des systèmes logiciels\r\n\r\n2 Ingénieur en ingénierie logicielle Supervise le processus de développement logiciel en s\'assurant de l\'application des meilleures pratiques et des méthodologies adaptées\r\n\r\n3 Architecte logiciel  Définit l\'architecture technique des systèmes logiciels en veillant à leur évolutivité et leur intégration\r\n\r\n4 Chef de projet informatique  Gère des projets de développement logiciel coordonnant les équipes et s\'assurant du respect des délais et des budgets', 'Licence, Master', 43),
(161, 'Sciences de l’ingénieur', 'Donner à l’étudiant une culture technologique assurant la maîtrise des connaissances académiques et pratiques dans les différents domaines de construction. Outre, une culture professionnelle conduisant à une bonne insertion à des fonctions d’encadrement, de gestion au sein des entreprises de construction, de suivi et contrôle de projets, cette Licence procure à l’étudiant une formation scientifique et spécifique de base qui lui confère une capacité d’évolution lui permettant d’accéder aux diplômes supérieurs : le Master et une possibilité de préparer un Doctorat dans les différentes spécialités du Génie Civil.', 'Cette formation vise à former des cadres pour le secteur de Génie civil, du Bâtiment et des Travaux Publics au sens le plus large de ces termes. Plus spécifiquement, les entreprises,les bureaux d’études, de suivi et de contrôle et les cabinets d’expertise.\\r\\nPar ailleurs, on assiste à l’éclosion d’un domaine, porteur en termes d’employabilité et de recherche, qui est en pleine évolution technologique : la fabrication de nouveaux matériaux. Qui dit nouveaux matériaux, sous-entend : nouvelles technologies, nouvelles méthodes d’exécution, nouvelles techniques commerciales et par conséquent une relance dans la demande en personnel spécialisé.', 'Les débouchés professionnels au niveau des cadres sont importants dans toutes les phases d’une opération de construction : Manual word wrap\\r\\nLa programmation des travaux : secteur public (collectivités locales, sociétés de constructions ;\\r\\n Le calcul des ouvrages : Bureaux d’études, cabinets d’ingénierie ;\\r\\nLa conduite et suivi de travaux et le contrôle – qualité des ouvrages : Entreprises de bâtiment de gros œuvres et de seconds œuvres, bureaux de contrôle ;\\r\\nMaintenance et gestion du patrimoine : Gestion technique, réhabilitation, aménagements ;\\r\\n Suivis des chantiers : B.T.P de moyenne et de grandes envergures.', 'Master, Doctorat', 46);

-- --------------------------------------------------------

--
-- Table structure for table `inscriptions`
--

CREATE TABLE `inscriptions` (
  `inscription_id` int NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matricule` varchar(50) NOT NULL,
  `prefix` varchar(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `place_of_birth` varchar(150) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(150) NOT NULL,
  `country` varchar(100) NOT NULL,
  `parent_name` varchar(150) NOT NULL,
  `parent_phone` varchar(15) NOT NULL,
  `current_level` varchar(255) NOT NULL,
  `desired_level` varchar(255) NOT NULL,
  `institution` varchar(15) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `statut` varchar(50) NOT NULL DEFAULT 'Pending'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inscriptions`
--

INSERT INTO `inscriptions` (`inscription_id`, `filiere`, `matricule`, `prefix`, `first_name`, `middle_name`, `last_name`, `date_of_birth`, `place_of_birth`, `gender`, `address`, `phone`, `email`, `country`, `parent_name`, `parent_phone`, `current_level`, `desired_level`, `institution`, `created_at`, `updated_at`, `statut`) VALUES
(6, 'Logistique transport et transit', 'CIREP-MOG-2024', 'Mme', 'MARTHE', 'OPENGE', 'GEORGES', '1998-12-05', 'MANIEMA', 'Fminin', 'Bukavu', '0819036309', 'georgesmaloanisgmailcom', 'RDC', 'MALOANI SAIDI', '0997749350', 'Licence', 'Master', 'HETEC BURKINA F', '2024-12-05 08:16:35', '2024-12-10 12:46:09', 'Confirmed'),
(7, 'COMPTABILTE CONTROLE ET AUDIT', 'CIREP--2024', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '2024-12-08 08:22:39', '2024-12-08 08:22:39', 'Pending'),
(8, 'COMPTABILTE CONTROLE ET AUDIT', 'CIREP-TTL-2024', '', 'Thai', 'Thai Luta', 'Luta', '0000-00-00', 'AK Shivering I ve only bought one Not even to the ones', '', '28 Green St', '17376358534', 'elzbibajmzuzidonotrespondme', 'US', 'Thai Luta', '17376358534', '', '', '', '2024-12-08 08:22:40', '2024-12-08 08:22:40', 'Pending'),
(9, 'COMPTABILTE CONTROLE ET AUDIT', 'CIREP-KKL-2024', 'Mr.', 'KIKUNI', 'KIKA', 'LAVIE', '1991-12-04', 'KIBANDA', 'Masculin', 'Bukavu', '684279392', 'ggg@gmail.com', 'RDC', 'MALOANI SAIDI', '0997749350', 'Licence', 'Master', 'HETEC BURKINA F', '2024-12-10 12:17:35', '2024-12-10 12:18:32', 'Confirmed');

-- --------------------------------------------------------

--
-- Table structure for table `institutions`
--

CREATE TABLE `institutions` (
  `institution_id` int NOT NULL,
  `designation_institution` text NOT NULL,
  `sigle` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `pays` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `institutions`
--

INSERT INTO `institutions` (`institution_id`, `designation_institution`, `sigle`, `logo`, `pays`) VALUES
(4, 'UniversitÃ© Africaine de Management au Gabon, Centrafrique et Congo', 'UAMT GABON', 'uploads_institution/67442bca99406_africaine_management.png', 'Gabon'),
(3, 'UniversitÃ© de Lisala', 'UNILIS', 'uploads_institution/67442a352d39b_unilis.jpg', 'Congo Democratic Republic (DRC)'),
(5, 'IRGIB Africa University', 'IRGIB-Africa', 'uploads_institution/67442bfb91726_irgib.jpg', 'Benin'),
(6, 'Distant Production House University', 'DPHU', 'uploads_institution/67442c2a26ab6_DPHU.jpg', 'Finland'),
(7, 'Hautes Etudes Technologiques et Commerciales', 'HETEC BURKINA FASO', 'uploads_institution/67509db79e1af_logohetec.jpg', 'Burkina Faso');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `note_id` int NOT NULL,
  `inscription_id` int NOT NULL,
  `cours_id` int NOT NULL,
  `note` decimal(5,2) NOT NULL,
  `date_attribution` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`note_id`, `inscription_id`, `cours_id`, `note`, `date_attribution`) VALUES
(1, 6, 13, 80.00, '2024-12-15'),
(2, 6, 14, 75.00, '2024-12-16'),
(3, 6, 15, 65.00, '2024-12-16');

-- --------------------------------------------------------

--
-- Table structure for table `paiements`
--

CREATE TABLE `paiements` (
  `paiement_id` int NOT NULL,
  `declaration_id` int NOT NULL,
  `nom_comptable` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_verification` datetime NOT NULL,
  `signature` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `appreciation_paiement` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `paiements`
--

INSERT INTO `paiements` (`paiement_id`, `declaration_id`, `nom_comptable`, `fonction`, `date_verification`, `signature`, `appreciation_paiement`) VALUES
(2, 2, 'Nelly Merveille', 'Secretaire comptable Logistique du CIREP', '2024-12-09 12:56:43', 'uploads/signatures/6756e9297fc3e_signature.PNG', 'Oui'),
(3, 2, 'Nelly Merveille', 'Secretaire comptable Logistique du CIREP', '2024-12-11 10:07:35', 'uploads/signatures/67596510bade3_signature.PNG', 'Oui');

-- --------------------------------------------------------

--
-- Table structure for table `programmes_formations`
--

CREATE TABLE `programmes_formations` (
  `id_programmes` int NOT NULL,
  `designation_programmes` text NOT NULL,
  `institution_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `programmes_formations`
--

INSERT INTO `programmes_formations` (`id_programmes`, `designation_programmes`, `institution_id`) VALUES
(46, 'Sciences et technologies', 4),
(45, 'Sciences et technologies', 6),
(44, 'Sciences et technologies', 3),
(43, 'Sciences et technologies', 7),
(42, 'Sciences de gestion', 7);

-- --------------------------------------------------------

--
-- Table structure for table `recherches`
--

CREATE TABLE `recherches` (
  `recherche_id` int NOT NULL,
  `auteur` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `contact` varchar(50) NOT NULL,
  `sujet` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `annee_obtention` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `institution` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `logo_institution` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `options` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `originalite_sujet` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `innovation_technologique` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `impact_entreprise` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `type_recherche` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recherches`
--

INSERT INTO `recherches` (`recherche_id`, `auteur`, `contact`, `sujet`, `annee_obtention`, `institution`, `logo_institution`, `options`, `originalite_sujet`, `innovation_technologique`, `impact_entreprise`, `type_recherche`) VALUES
(27, 'Assétou KABORE', '+226 70 62 56 20', 'ANALYSE DE LA PRISE EN COMPTE DU GENRE DANS LES STRATEGIES DE REHABILITATION ET DE REINSERTION SOCIOECONOMIQUE DES PERSONNES DEPLACEES INTERNES (PDI) AU BURKINA FASO : CAS DE LA REGION DU CENTRE-NORD', 'Mai 2020', 'INSTITUT PANAFRICAIN POUR LE DEVELOPPEMENT Région Afrique de l’Ouest et Sahel Université des Sciences appliquées du Développement (Francophone)', 'NN.jpg', 'Sciences appliquées du Développement', 'a. Analyse pionnière dans un contexte émergent\r\nCe mémoire se distingue par son focus sur un problème socio-économique et humanitaire rarement exploré dans le contexte burkinabé : la prise en compte du genre dans les stratégies de réhabilitation des PDI. Cette thématique est innovante, car elle relie des questions de justice sociale, de genre, et de lutte contre l’extrémisme violent.\r\nb. Lien entre le genre et la réinsertion sociale\r\nEn étudiant les dimensions de genre dans la réhabilitation des PDI, l’étude offre une perspective unique sur les impacts différenciés des déplacements sur les hommes et les femmes. Elle démontre que l’inefficacité des politiques actuelles est liée à une mauvaise compréhension de la dimension genre.\r\nc. Pertinence régionale et nationale\r\nEn ciblant la région du Centre-Nord, la recherche illustre comment des contextes spécifiques influencent la gestion des crises humanitaires, mettant en lumière des solutions locales adaptables à d’autres régions touchées par l’extrémisme violent.\r\nd. Approche interdisciplinaire\r\nL’intégration d’éléments de sociologie, de genre, et de politiques publiques montre une analyse holistique des enjeux. Cette interdisciplinarité enrichit la compréhension globale du sujet et inspire des recherches futures.\r\ne. Implications pour la paix et le développement durable\r\nEn liant la réhabilitation des PDI à des objectifs de cohésion sociale, le mémoire pose les bases d’une réflexion sur le rôle du genre dans la construction de sociétés inclusives, un sujet crucial pour les décideurs politiques.', 'a. Digitalisation des données des PDI\r\nLe mémoire propose indirectement des solutions technologiques, comme la mise en place de systèmes de gestion numériques pour suivre les parcours de réhabilitation des PDI. Cela inclut l’enregistrement des bénéficiaires et le suivi des services reçus.\r\nb. Cartographie des zones à risques\r\nL’utilisation de systèmes d’information géographique (SIG) pourrait optimiser la gestion des PDI en identifiant les zones de concentration et en facilitant la coordination des ressources.\r\nc. Applications mobiles pour les femmes PDI\r\nDes applications pourraient être développées pour permettre aux femmes déplacées de signaler leurs besoins spécifiques, accéder à des formations ou suivre des programmes de réinsertion.\r\nd. Plateformes éducatives sur le genre\r\nPour sensibiliser les acteurs locaux à l’importance de la dimension genre, des programmes de formation en ligne pourraient être déployés, intégrant des modules sur la réinsertion et la cohésion sociale.\r\ne. Suivi automatisé des impacts des politiques\r\nLes innovations en intelligence artificielle pourraient analyser les données collectées pour mesurer l’efficacité des stratégies de réhabilitation en fonction de la prise en compte du genre.', 'a. Création d\'outils technologiques\r\nLes entreprises spécialisées en technologie peuvent développer des systèmes numériques pour gérer les bases de données des PDI et les services associés, créant ainsi des opportunités économiques.\r\nb. Partenariats public-privé\r\nLes entreprises peuvent collaborer avec les gouvernements pour améliorer les infrastructures de gestion humanitaire, telles que des centres d’accueil équipés de solutions numériques.\r\nc. Formation et employabilité\r\nLes besoins en formation pour les acteurs locaux créent des opportunités pour les entreprises du secteur de la formation professionnelle, en particulier sur les questions de genre et de réhabilitation.\r\nd. Impact sur la responsabilité sociale des entreprises (RSE)\r\nEn s’impliquant dans des projets humanitaires liés aux PDI, les entreprises peuvent renforcer leur engagement en matière de RSE, améliorant leur image auprès des parties prenantes.\r\ne. Développement d’un marché pour les services humanitaires\r\nLa demande croissante de solutions spécifiques pour les PDI offre un nouveau marché pour les entreprises, allant des technologies de suivi aux services de logistique et de réhabilitation.', 'Mémoire de master'),
(32, 'Michel Marcel ENAMA ADA', '+237 98687157', 'Itinéraires thérapeutiques des traumatisés admis en rééducation chez les tradipraticiens dans la ville de Mfou', 'Mai 2020', 'UNILIS', 'unilis.jpg', 'Santé Publique', 'a. Une perspective centrée sur les tradipraticiens\r\nLe mémoire aborde un sujet rarement exploré dans les recherches en santé publique : les itinéraires thérapeutiques impliquant des tradipraticiens dans la rééducation des traumatismes. En intégrant cette dimension culturelle, il met en avant l’importance des réalités socioculturelles dans les choix de soins des populations locales.\r\nb. Approche qualitative détaillée\r\nLa méthodologie qualitative adoptée, avec des entretiens semi-directifs auprès de patients traumatisés, offre une analyse en profondeur des perceptions individuelles. Contrairement aux enquêtes quantitatives, cette approche révèle des motivations et barrières spécifiques liées aux décisions thérapeutiques.\r\nc. Contextualisation régionale\r\nL’étude se concentre sur Mfou, une zone où les recours alternatifs à la médecine biomédicale sont courants. Ce choix permet de documenter les spécificités locales et d’apporter des données uniques pour comprendre l’interaction entre médecine traditionnelle et moderne.\r\nd. Contribution interdisciplinaire\r\nEn intégrant des concepts de santé publique, de sociologie et de réhabilitation, ce mémoire propose une vision holistique des trajectoires thérapeutiques, contribuant à enrichir plusieurs disciplines académiques.\r\ne. Accent sur les implications sociales\r\nL’originalité réside également dans l’analyse des répercussions sociales des choix thérapeutiques, notamment en termes de retard dans la rééducation et des handicaps persistants qui en découlent.', 'a. Opportunités de digitalisation des itinéraires thérapeutiques\r\nLes résultats du mémoire suggèrent la possibilité de créer une application mobile ou une plateforme numérique pour guider les patients dans leurs choix thérapeutiques. Cette innovation pourrait inclure :\r\n•	Des cartes des services de santé locaux (traditionnels et modernes).\r\n•	Un outil éducatif sur les bienfaits de la rééducation fonctionnelle.\r\nb. Intégration des dossiers électroniques\r\nLe mémoire met en évidence l’absence de suivi cohérent des patients. L’introduction de dossiers médicaux électroniques accessibles à la fois par les médecins et tradipraticiens pourrait améliorer la coordination des soins.\r\nc. Utilisation des outils de télémédecine\r\nPour réduire les retards dans l\'accès aux soins spécialisés, les technologies de téléconsultation pourraient être adaptées, notamment pour les suivis post-hospitaliers dans des zones éloignées comme Mfou.\r\nd. Analyse des données pour la prévention\r\nL’étude fournit une base de données qualitative qui pourrait être utilisée pour développer des algorithmes prédictifs afin d’identifier les patients à risque de retards ou de choix non optimaux dans leur parcours de soins.\r\ne. Formation en ligne pour les tradipraticiens\r\nLe mémoire pourrait inspirer des programmes de formation en ligne, permettant aux tradipraticiens d\'acquérir des connaissances de base sur la rééducation fonctionnelle, renforçant ainsi la collaboration entre les pratiques traditionnelles et modernes.', 'a. Développement d’applications de santé\r\nLes entreprises spécialisées en technologie peuvent tirer parti des résultats pour concevoir des outils numériques adaptés à la gestion des itinéraires thérapeutiques, incluant des fonctionnalités comme :\r\n•	La géolocalisation des tradipraticiens et centres de rééducation.\r\n•	Des rappels pour les rendez-vous de rééducation.\r\nb. Création de centres hybrides de soins\r\nLes résultats pourraient encourager des partenariats entre entrepreneurs privés et autorités locales pour établir des centres hybrides combinant médecine traditionnelle et réhabilitation moderne.\r\nc. Opportunités en formation\r\nLes entreprises peuvent concevoir des programmes de formation continue pour les soignants, incluant des modules sur les approches intégrées en soins post-traumatiques.\r\nd. Contribution au développement économique local\r\nEn investissant dans des services de santé mieux coordonnés, les entreprises peuvent non seulement augmenter leur chiffre d’affaires, mais aussi stimuler l\'économie locale en créant des emplois liés à la gestion et au suivi des patients.\r\ne. Promotion de l’innovation sociale\r\nLes entreprises qui soutiennent des initiatives pour améliorer les services de rééducation fonctionnelle dans les zones rurales peuvent renforcer leur image de responsabilité sociale et leur positionnement sur les marchés émergents.', 'Mémoire de master'),
(33, 'IBA Karim', '+226 70 40 23 87', 'des déterminants du succès d’un projet public au Burkina-Faso : Cas du projet de modernisation et de sécurisation des titres de transports du Ministère des Transports de la Mobilité urbaine et la Sécurité Routière (MTMUSR)', '30 mai 2022', 'Université d’Abomey Calavi', 'obey.png', 'Analyse et Gestion des projets Publics', 'a. Sujet pertinent et contextuel\r\nLe mémoire explore un sujet clé : les déterminants du succès d’un projet public au Burkina Faso. Ce thème se distingue par son ancrage dans les réalités locales, mettant en lumière le lien entre la modernisation des titres de transport et la sécurité routière. L’approche contextualisée permet de combler un vide dans la recherche académique sur les projets publics dans des économies émergentes.\r\nb. Orientation interdisciplinaire\r\nL’étude intègre des éléments de gestion de projet, d’économie et de politique publique, proposant une perspective holistique. Cela enrichit non seulement le domaine de la gestion des projets publics, mais aussi le débat sur l’efficacité des politiques gouvernementales.\r\nc. Approche méthodologique rigoureuse\r\nEn utilisant une démarche hypothético-déductive, ce mémoire offre une analyse approfondie des variables clés influençant le succès des projets publics. Les cinq facteurs étudiés (compétence des dirigeants, environnement organisationnel, contrôle financier, personnel, caractéristiques du projet) sont rarement explorés ensemble dans des recherches similaires.\r\n\r\nd. Accent sur l\'impact sociétal\r\nL’étude souligne le rôle central des infrastructures modernes dans la réduction des accidents de la route, tout en identifiant les défis liés à leur mise en œuvre. Cet aspect sociétal ajoute une valeur supplémentaire à la recherche.\r\ne. Perspectives pour les décideurs publics\r\nLe travail propose des recommandations stratégiques pour améliorer la gestion des projets publics, aidant ainsi les responsables à mieux planifier, exécuter et évaluer les projets dans des environnements complexes.', 'a. Mise en place d’un système intégré de gestion\r\nL\'étude recommande l\'introduction d’un Card Management System (CMS) pour gérer la vie des cartes, incluant la production, la mise à jour, et la révocation des titres. Ce système innovant optimise la sécurité et la traçabilité des données.\r\nb. Digitalisation des processus administratifs\r\nLe mémoire met en avant le rôle de la digitalisation, avec des interfaces web modernes et ergonomiques pour gérer les données, améliorer l\'accès des usagers et réduire la fraude.\r\nc. Automatisation des opérations\r\nLes fonctionnalités automatisées proposées, comme les mises à jour des informations des cartes et la génération de rapports avancés, illustrent l\'importance de l\'automatisation pour réduire les erreurs humaines et accélérer les processus.\r\nd. Systèmes interconnectés\r\nL’interconnexion des différents acteurs (douanes, impôts, police, gendarmerie) via des bases de données centralisées est une innovation clé, renforçant la coordination entre institutions et améliorant l\'efficacité.\r\ne. Sécurisation des données\r\nLe recours aux mécanismes de non-répudiation pour toutes les transactions ajoute un niveau de sécurité élevé, essentiel dans la lutte contre la contrefaçon et les pratiques frauduleuses.', 'a. Opportunités dans le domaine technologique\r\nLes entreprises spécialisées en TIC peuvent développer des solutions adaptées pour la gestion des titres de transport, créant ainsi de nouveaux marchés. Cela inclut des applications pour suivre les titres en temps réel ou générer des statistiques.\r\nb. Contribution à la chaîne de valeur\r\nLes entreprises locales peuvent bénéficier de contrats pour la production et la maintenance des titres de transport modernes, stimulant ainsi l’économie locale.\r\nc. Formation et emplois spécialisés\r\nLe besoin accru en formation pour les opérateurs et administrateurs des systèmes créera de nouvelles opportunités d\'emplois et renforcera les compétences locales.\r\nd. Partenariats public-privé (PPP)\r\nLe mémoire démontre l’importance des PPP dans la mise en œuvre de projets complexes. Les entreprises peuvent collaborer avec le gouvernement pour fournir des services innovants, partageant les risques et les bénéfices.\r\ne. Amélioration de la réputation\r\nLes entreprises impliquées dans des projets d’intérêt public, comme la modernisation des titres de transport, améliorent leur image de marque en se positionnant comme partenaires du développement.', 'Mémoire de master'),
(31, 'Abou ZOURE', '+22672 15 17 18', 'Difficultés de fonctionnement des services publics communaux au Burkina Faso', '2019-2020', 'Normandie Université', 'normandie.jpg', 'droit public parcours « Services et politiques publics »', 'a. Analyse approfondie des dysfonctionnements locaux\r\nLe mémoire se distingue par sa capacité à identifier les causes structurelles et opérationnelles des dysfonctionnements des services publics communaux. Contrairement à de nombreuses études qui se concentrent sur les défis nationaux ou sectoriels, ce travail met en lumière les problèmes locaux spécifiques au Burkina Faso, comme l\'insuffisance des ressources humaines qualifiées et l\'inefficacité des transferts de compétences.\r\nb. Approche comparative des modèles administratifs\r\nLe travail s’appuie sur des comparaisons entre les systèmes administratifs centralisés et décentralisés pour démontrer comment l’absence d’adaptations locales freine la mise en œuvre des politiques publiques. Cette approche comparative enrichit la compréhension des défis uniques de la décentralisation.\r\nc. Lien entre la théorie et la pratique\r\nLe mémoire explore les écarts significatifs entre la législation et son application sur le terrain. Par exemple, bien que 11 blocs de compétences aient été transférés, seulement 6 ont été réellement opérationnalisés. Cela met en évidence une contradiction entre les politiques officielles et les réalités communales, une perspective souvent négligée.\r\nd. Focus sur les conséquences sociales\r\nL’originalité du mémoire réside également dans son attention aux impacts sociaux des dysfonctionnements administratifs, comme les difficultés d’accès des populations rurales aux services de base (état civil, santé, éducation). Ce focus social renforce l’utilité pratique de l’analyse pour les décideurs.\r\n\r\ne. Propositions novatrices\r\nL’étude se démarque par ses propositions, telles que la refonte des mécanismes de transfert des ressources et la modernisation des outils de gestion communale. Ces recommandations offrent des solutions concrètes et adaptables à d\'autres contextes similaires en Afrique subsaharienne.', 'a. Digitalisation des processus administratifs\r\nL’étude ouvre la voie à une digitalisation des services publics communaux. Par exemple, un système intégré de gestion communale pourrait automatiser des fonctions telles que la gestion de l’état civil, la collecte de taxes locales et le suivi des ressources budgétaires. Une telle innovation améliorerait l’efficacité et réduirait la corruption.\r\nb. Utilisation des systèmes d’information géographique (SIG)\r\nLe mémoire souligne indirectement l’importance de cartographier les zones communales pour une meilleure gestion foncière et urbaine. Les SIG permettraient d’optimiser l’utilisation des terres, de planifier les infrastructures et de surveiller les projets de développement local.\r\nc. Applications mobiles pour la participation citoyenne\r\nLes innovations technologiques pourraient inclure des applications mobiles qui permettraient aux citoyens de signaler les problèmes communaux, de suivre les projets de développement et de payer leurs taxes en ligne, renforçant ainsi la transparence et l\'engagement communautaire.\r\nd. Réseaux de communication pour renforcer les compétences\r\nUn autre domaine d’innovation technologique est l’utilisation de plateformes de formation en ligne pour renforcer les compétences des agents communaux. Cela répondrait directement aux défis de qualification relevés dans l’étude.\r\ne. Cloud computing pour la gestion des données\r\nEnfin, le cloud computing pourrait être utilisé pour centraliser et sécuriser les données communales, permettant une meilleure coordination entre les différentes administrations locales et régionales.', 'a. Opportunités commerciales dans la technologie\r\nLes entreprises spécialisées dans les logiciels de gestion administrative pourraient saisir l’occasion de développer des solutions pour la digitalisation des processus communaux. Par exemple, des outils de gestion intégrée pourraient inclure des modules pour l’état civil, la gestion budgétaire, et les rapports de performance.\r\n\r\nb. Partenariats public-privé (PPP)\r\nLe mémoire met en évidence des secteurs où les entreprises privées pourraient collaborer avec les collectivités, tels que la construction d’infrastructures ou la gestion de projets éducatifs et sanitaires. Ces partenariats pourraient réduire les charges communales tout en offrant des opportunités d’investissement aux entreprises.\r\nc. Contribution à la RSE\r\nLes entreprises peuvent renforcer leur image en s’engageant dans des initiatives locales, comme le financement de centres de santé ou de projets éducatifs. Ces actions, conformes à leurs objectifs de responsabilité sociale (RSE), pourraient également améliorer la qualité de vie des populations.\r\nd. Optimisation des marchés locaux\r\nL’identification des lacunes dans les services communaux peut aider les entreprises à ajuster leurs stratégies de marketing. Par exemple, elles pourraient proposer des solutions adaptées aux besoins des communes rurales, telles que des équipements abordables ou des services de maintenance.\r\ne. Développement d’un écosystème économique local\r\nEn améliorant les services publics locaux, les entreprises contribuent indirectement à la création d’un environnement économique propice. Des infrastructures locales améliorées attireraient d’autres investissements et augmenteraient la productivité locale.', 'Mémoire de master'),
(28, 'Michel BOINHIDWENDE OUÉDRAOGO', '+226 60 20 16 59', 'Problématique de la motivation des agents de l’Etat sous journée continue : Cas du Ministère de l’urbanisme et de l’habitat.', '2016 – 2017', 'UNIVERSITÉ AUBE NOUVELLE', 'haub.jpg', 'Gestion des Ressources Humaines', '1. Originalité thématique\r\nLe mémoire aborde une problématique encore peu explorée au Burkina Faso : l\'impact de la journée de travail continu sur la motivation des agents publics. Bien que le sujet de la motivation au travail soit classique, l\'angle d\'approche—liant directement l\'efficacité des réformes institutionnelles au système d\'horaires continus—constitue une perspective originale. Ce travail dépasse les revendications salariales habituelles en se concentrant sur des aspects structurels et organisationnels qui influencent directement la productivité et le bien-être des agents.\r\n2. Contribution inédite à la littérature\r\nLe mémoire offre une analyse contextuelle approfondie de la réforme des horaires de travail au Burkina Faso, ancrée dans des études de cas locales et des comparaisons internationales. Cette étude met en lumière des facettes jusqu\'alors négligées, comme les effets sociaux et environnementaux des changements d\'horaires. En combinant données qualitatives et quantitatives sur un sujet largement débattu mais rarement documenté, il enrichit la littérature existante sur la gestion publique en Afrique de l\'Ouest.\r\n3. Méthodologie novatrice\r\nLa méthodologie adoptée est une combinaison d\'approches documentaires et d\'enquêtes de terrain. Ce qui est particulièrement innovant ici, c\'est l\'utilisation d\'une grille d\'observation pour évaluer directement les attitudes et comportements des agents publics en réponse à la réforme. Cette méthode permet de croiser les perceptions subjectives des agents avec des observations concrètes, renforçant ainsi la fiabilité et la validité des conclusions.', 'Une dimension technologique intéressante du mémoire est l’intégration ou la proposition d’outils numériques pour la gestion et l\'évaluation des réformes. Bien que cela ne soit pas détaillé en tant que solution implémentée, l\'idée d\'utiliser des systèmes de suivi numérique ou des applications pour faciliter l\'adoption des nouvelles pratiques administratives est une innovation en soi, surtout dans un contexte où les administrations africaines font face à des contraintes technologiques.', 'L’étude met également en évidence l’impact environnemental positif de la réforme grâce à la réduction des déplacements domicile-travail. Cette approche, qui relie la réforme administrative à des questions environnementales, est novatrice dans le contexte burkinabè. Elle montre comment des politiques publiques, même dans des secteurs non directement liés à l\'environnement, peuvent contribuer aux objectifs de durabilité.', 'Mémoire de master'),
(29, 'NOUMA Enoc', '', 'MANAGEMENT DES ABSENCES DANS LES ENTREPRISES PUBLIQUES. CAS DU GOUVERNORAT DU CENTRE-SUD AU BURKINA FASO', '2017-2019', 'Institut Privé Online Training Center', 'otc.jpg', 'Gestion des Ressources Humaines', '1.	Originalité thématique \r\nCe mémoire traite de l\'absentéisme dans les entreprises publiques, avec un cas d\'étude spécifique sur le gouvernorat du Centre-Sud au Burkina Faso. L\'originalité réside dans l\'approche ciblée et contextuelle, qui analyse une problématique universelle mais souvent négligée dans le cadre des organisations publiques africaines. Ce travail met en lumière les défis uniques liés à la gestion des absences dans une structure étatique, en considérant les aspects organisationnels et culturels propres au gouvernorat.\r\n2.	Perspective empirique \r\nLe mémoire se distingue par son accent sur les données empiriques collectées directement auprès des chefs de service et des agents publics au sein du gouvernorat. Cette démarche terrain fournit des insights riches et spécifiques sur les causes et les conséquences de l’absentéisme, renforçant ainsi la pertinence et l\'applicabilité des recommandations formulées.\r\n3.	Innovation méthodologique \r\nLa méthodologie utilisée combine des outils qualitatifs et quantitatifs, notamment des grilles d’observation et des questionnaires adaptés au contexte du gouvernorat. Cette approche mixte permet d’examiner l’absentéisme sous plusieurs angles, incluant les comportements des agents, les impacts sur la productivité et les coûts indirects pour l’organisation.\r\n\r\nAu-delà de l’analyse descriptive, le mémoire propose des solutions concrètes pour réduire l’absentéisme, telles que des politiques de sensibilisation, des formations pour les cadres en gestion des absences et des systèmes de contrôle renforcés. Ces stratégies visent à améliorer non seulement la performance du gouvernorat, mais aussi la qualité des services publics.\r\nEn somme, l\'originalité de ce mémoire repose sur son approche localisée et son cadre analytique rigoureux, tandis que ses propositions technologiques et stratégiques illustrent une vision novatrice pour résoudre le problème de l’absentéisme dans les organisations publiques au Burkina Faso.\r\nL’étude quantifie l’impact économique de l’absentéisme en calculant les coûts directs et indirects liés aux absences. Cette analyse économique précise est une innovation dans le domaine de la gestion des ressources humaines dans le contexte public, apportant une vision claire des pertes financières et organisationnelles.', 'Le mémoire propose la mise en œuvre de systèmes numériques pour améliorer la gestion des absences. Ces solutions incluent des logiciels de suivi en temps réel et des registres électroniques pour centraliser les données sur les présences et absences des employés. Ces recommandations représentent une avancée importante pour la modernisation de la gestion administrative dans les organisations publiques burkinabè.', 'Le management des absences dans les entreprises publiques, illustré par le cas du Gouvernorat du Centre-Sud au Burkina Faso, a un impact majeur sur la performance organisationnelle et l’efficacité des services publics. Une gestion proactive des absences permet de réduire les perturbations dans le fonctionnement des équipes, d’optimiser l’utilisation des ressources humaines et d’améliorer la productivité globale. Cela contribue également à renforcer la satisfaction des usagers des services publics, qui bénéficient d’un service continu et de qualité. En identifiant les causes des absences et en y apportant des solutions adaptées (politiques de motivation, suivi rigoureux, mesures préventives), l’organisation peut minimiser les coûts liés au remplacement temporaire ou aux retards dans les missions. Par ailleurs, une gestion efficace des absences favorise un climat de travail plus harmonieux, limite les conflits sociaux, et positionne l’entreprise publique comme un modèle en matière de gouvernance des ressources humaines, stimulant ainsi la confiance des citoyens dans les institutions publiques.', 'Mémoire de master'),
(30, 'BAMOGO Razanwindé', '', 'La contribution du contrôle de gestion dans la performance de l’entreprise : Cas de la SONABEL', 'Juillet 2020', 'Institut Supérieur Privé Polytechnique', 'ISPP.jpg', 'Finance-Comptabilité et Contrôle', '1.	Originalité thématique \r\nCe mémoire explore le rôle du contrôle de gestion dans une entreprise publique au Burkina Faso, en particulier la SONABEL. Son originalité réside dans son approche pratique et contextuelle, mettant en lumière les défis spécifiques de gestion dans une entreprise de service public confrontée à des enjeux techniques et organisationnels. L\'accent mis sur les performances opérationnelles et stratégiques dans un contexte africain apporte une perspective nouvelle.\r\n2.	Contribution au domaine du contrôle de gestion \r\nL\'étude va au-delà des approches théoriques classiques pour fournir une analyse spécifique des outils de gestion, tels que les tableaux de bord, adaptés aux besoins et contraintes de la SONABEL. La mise en évidence des interactions entre le contrôle budgétaire, la planification stratégique et la gestion opérationnelle illustre une application concrète rarement documentée dans les entreprises publiques locales.\r\n3.	Innovation méthodologique \r\nLe mémoire introduit une méthodologie hybride, combinant une analyse documentaire approfondie avec une observation participante et des entretiens qualitatifs. Cette approche permet une compréhension détaillée des pratiques internes de la SONABEL, tout en offrant une vue critique sur l’efficacité des outils et processus en place.\r\nLe mémoire propose des améliorations stratégiques telles que la centralisation des processus de contrôle, l\'automatisation des flux d\'information et la mise en place de systèmes de gestion des risques. Ces initiatives visent à renforcer la résilience de la SONABEL face aux défis économiques et opérationnels, tout en maximisant l’utilisation des ressources disponibles.\r\nEn somme, ce mémoire se distingue par son originalité contextuelle et ses recommandations innovantes, combinant des approches traditionnelles du contrôle de gestion avec des solutions modernes adaptées à un environnement public burkinabè.', 'Le mémoire suggère la modernisation des systèmes d’information et de contrôle de gestion à travers l’intégration de logiciels de planification et d’analyse de données. Ces outils visent à améliorer le suivi des indicateurs de performance, réduire les inefficacités dans la gestion budgétaire et renforcer la prise de décision basée sur les données.', 'En analysant les interactions entre le contrôle de gestion et les objectifs de service public, le mémoire apporte une réflexion innovante sur la gouvernance des entreprises publiques. Les propositions de renforcement des processus de contrôle offrent des pistes pour aligner les performances opérationnelles avec les attentes des parties prenantes, notamment l’État et les clients.\r\nLa contribution du contrôle de gestion à la performance de l’entreprise, dans le cas de la SONABEL (Société Nationale d’Électricité du Burkina Faso), est cruciale pour optimiser ses résultats opérationnels et financiers. Le contrôle de gestion permet d’assurer un suivi rigoureux des coûts, de mesurer l’efficacité des processus internes, et de mettre en place des outils d’aide à la décision pour une allocation optimale des ressources. En identifiant les écarts entre les objectifs fixés et les performances réelles, il favorise l’élaboration de stratégies correctives pour améliorer la rentabilité et la qualité des services fournis aux usagers. Par ailleurs, le contrôle de gestion renforce la transparence et la responsabilité au sein de l’entreprise, contribuant ainsi à un meilleur pilotage global. Dans un contexte où la SONABEL joue un rôle clé dans le développement énergétique du Burkina Faso, une telle démarche est indispensable pour relever les défis liés à la demande croissante, tout en garantissant une gestion durable et efficiente de ses activités.', 'Mémoire de master');

-- --------------------------------------------------------

--
-- Table structure for table `type_diplome`
--

CREATE TABLE `type_diplome` (
  `type_id` int NOT NULL,
  `type_designation` text NOT NULL,
  `institution_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_diplome`
--

INSERT INTO `type_diplome` (`type_id`, `type_designation`, `institution_id`) VALUES
(1, 'Licence', 5),
(2, 'Licence', 4),
(3, 'Master', 6),
(4, 'Master', 5),
(5, 'Master', 4),
(6, 'Master', 3),
(7, 'Doctorat', 6),
(8, 'Doctorat', 5),
(9, 'Doctorat', 4),
(10, 'Doctorat', 3),
(12, 'Licence', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pwd` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `prenom`, `nom`, `email`, `role`, `login`, `pwd`) VALUES
(1, 'CIREP', 'Catalogue', 'georgesmaloanis@gmail.com', 'Admin', 'Georges', 'Georges'),
(3, 'OCHOU', 'Hermann', 'ochou@gmail.com', 'DG', 'OCHOU24', 'OCHOU24'),
(4, 'Nelly', 'Merveille', 'nelly@gmail.com', 'Finances', 'nelly', 'nelly');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actualites`
--
ALTER TABLE `actualites`
  ADD PRIMARY KEY (`actuality_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `annonces`
--
ALTER TABLE `annonces`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attribution_cours`
--
ALTER TABLE `attribution_cours`
  ADD PRIMARY KEY (`id_attribution`);

--
-- Indexes for table `carte`
--
ALTER TABLE `carte`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cours`
--
ALTER TABLE `cours`
  ADD PRIMARY KEY (`cours_id`);

--
-- Indexes for table `cours_fichiers`
--
ALTER TABLE `cours_fichiers`
  ADD PRIMARY KEY (`id_fichier`),
  ADD KEY `id_attribution` (`id_attribution`);

--
-- Indexes for table `declarations_paiements`
--
ALTER TABLE `declarations_paiements`
  ADD PRIMARY KEY (`declaration_id`);

--
-- Indexes for table `dossiers_etudiants`
--
ALTER TABLE `dossiers_etudiants`
  ADD PRIMARY KEY (`dossiers_id`);

--
-- Indexes for table `enseignant`
--
ALTER TABLE `enseignant`
  ADD PRIMARY KEY (`id_enseignant`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `mail_enseignant` (`mail_enseignant`);

--
-- Indexes for table `filieres_departements`
--
ALTER TABLE `filieres_departements`
  ADD PRIMARY KEY (`id_filieres_departements`);

--
-- Indexes for table `inscriptions`
--
ALTER TABLE `inscriptions`
  ADD PRIMARY KEY (`inscription_id`),
  ADD UNIQUE KEY `matricule` (`matricule`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `filiere_id` (`filiere`);

--
-- Indexes for table `institutions`
--
ALTER TABLE `institutions`
  ADD PRIMARY KEY (`institution_id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `paiements`
--
ALTER TABLE `paiements`
  ADD PRIMARY KEY (`paiement_id`);

--
-- Indexes for table `programmes_formations`
--
ALTER TABLE `programmes_formations`
  ADD PRIMARY KEY (`id_programmes`);

--
-- Indexes for table `recherches`
--
ALTER TABLE `recherches`
  ADD PRIMARY KEY (`recherche_id`);

--
-- Indexes for table `type_diplome`
--
ALTER TABLE `type_diplome`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actualites`
--
ALTER TABLE `actualites`
  MODIFY `actuality_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `annonces`
--
ALTER TABLE `annonces`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `attribution_cours`
--
ALTER TABLE `attribution_cours`
  MODIFY `id_attribution` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `carte`
--
ALTER TABLE `carte`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cours`
--
ALTER TABLE `cours`
  MODIFY `cours_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `cours_fichiers`
--
ALTER TABLE `cours_fichiers`
  MODIFY `id_fichier` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `declarations_paiements`
--
ALTER TABLE `declarations_paiements`
  MODIFY `declaration_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dossiers_etudiants`
--
ALTER TABLE `dossiers_etudiants`
  MODIFY `dossiers_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enseignant`
--
ALTER TABLE `enseignant`
  MODIFY `id_enseignant` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `filieres_departements`
--
ALTER TABLE `filieres_departements`
  MODIFY `id_filieres_departements` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `inscriptions`
--
ALTER TABLE `inscriptions`
  MODIFY `inscription_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `institutions`
--
ALTER TABLE `institutions`
  MODIFY `institution_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `note_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `paiements`
--
ALTER TABLE `paiements`
  MODIFY `paiement_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `programmes_formations`
--
ALTER TABLE `programmes_formations`
  MODIFY `id_programmes` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `recherches`
--
ALTER TABLE `recherches`
  MODIFY `recherche_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `type_diplome`
--
ALTER TABLE `type_diplome`
  MODIFY `type_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cours_fichiers`
--
ALTER TABLE `cours_fichiers`
  ADD CONSTRAINT `cours_fichiers_ibfk_1` FOREIGN KEY (`id_attribution`) REFERENCES `attribution_cours` (`id_attribution`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
