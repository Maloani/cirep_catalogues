<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Configurer l'encodage UTF-8
$conn->set_charset("utf8mb4");

// Vérifier si un ID de cours est passé
if (!isset($_GET['id'])) {
    die("ID du cours non fourni.");
}

$id_cours = intval($_GET['id']);

// Récupérer les données du cours
$sql_cours = "SELECT * FROM cours WHERE cours_id = ?";
$stmt_cours = $conn->prepare($sql_cours);

if ($stmt_cours === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt_cours->bind_param("i", $id_cours);
$stmt_cours->execute();
$result_cours = $stmt_cours->get_result();

if ($result_cours->num_rows === 0) {
    die("Cours non trouvé.");
}

$cours = $result_cours->fetch_assoc();
$stmt_cours->close();

// Récupérer toutes les filières pour les afficher dans la liste déroulante
$sql_filieres = "SELECT id_filieres_departements, filieres_departements_designation FROM filieres_departements";
$result_filieres = $conn->query($sql_filieres);

// Traiter la soumission du formulaire
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = htmlspecialchars(trim($_POST['code']), ENT_QUOTES, 'UTF-8');
    $intitule_cours = htmlspecialchars(trim($_POST['intitule_cours']), ENT_QUOTES, 'UTF-8');
    
    $credit = intval($_POST['credit']);
    $type_pro = htmlspecialchars(trim($_POST['type_pro']), ENT_QUOTES, 'UTF-8');
    $id_filieres_departements = intval($_POST['id_filieres_departements']);

    // Vérifier les champs obligatoires
    if (empty($code) || empty($intitule_cours) || empty($credit) || empty($id_filieres_departements) || empty($type_pro)) {
        $error = "Tous les champs sont obligatoires.";
    } elseif (!in_array($type_pro, ['Licence', 'Master', 'Doctorat'], true)) {
        $error = "Type de programme invalide.";
    } else {
        // Mettre à jour le cours
        $update_sql = "UPDATE cours 
                       SET code = ?, intitule_cours = ?, credit = ?, type_pro = ?, id_filieres_departements = ?
                       WHERE cours_id = ?";
        $stmt_update = $conn->prepare($update_sql);

        if ($stmt_update === false) {
            die("Erreur de préparation de la requête : " . $conn->error);
        }

        $stmt_update->bind_param("ssisii", $code, $intitule_cours,  $credit, $type_pro,$id_filieres_departements, $id_cours);

        if ($stmt_update->execute()) {
            echo "<script>alert('Cours mis à jour avec succès.'); window.location.href = 'mise_en_forme_coursDG.php';</script>";
        } else {
            $error = "Erreur lors de la mise à jour : " . $stmt_update->error;
        }

        $stmt_update->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Cours</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #3498DB;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        form label {
            margin-top: 10px;
            font-weight: bold;
        }

        form input, form select, form button {
            margin-top: 5px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        form button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        form button:hover {
            background-color: #45a049;
        }

        .return-btn {
            display: block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #3498DB;
            color: white;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
        }

        .return-btn:hover {
            background-color: #2980b9;
        }

        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="mise_en_forme_coursDG.php" class="return-btn">Retour</a>
        <h1>Modifier Cours</h1>

        <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="code">Code du cours :</label>
            <input type="text" id="code" name="code" value="<?php echo htmlspecialchars($cours['code']); ?>" required>

            <label for="intitule_cours">Intitulé du cours :</label>
            <input type="text" id="intitule_cours" name="intitule_cours" value="<?php echo htmlspecialchars($cours['intitule_cours']); ?>" required>

           

            <label for="credit">Nombre de crédits :</label>
            <input type="number" id="credit" name="credit" value="<?php echo htmlspecialchars($cours['credit']); ?>" required>
            
             <label for="type_pro">Type de programme :</label>
            <select id="type_pro" name="type_pro" required>
                <option value="" disabled>-- Sélectionnez un type --</option>
                <option value="Licence" <?php echo ($cours['type_pro'] === 'Licence') ? 'selected' : ''; ?>>Licence</option>
                <option value="Master" <?php echo ($cours['type_pro'] === 'Master') ? 'selected' : ''; ?>>Master</option>
                <option value="Doctorat" <?php echo ($cours['type_pro'] === 'Doctorat') ? 'selected' : ''; ?>>Doctorat</option>
            </select>

            <label for="id_filieres_departements">Filière :</label>
            <select id="id_filieres_departements" name="id_filieres_departements" required>
                <option value="" disabled>-- Sélectionnez une filière --</option>
                <?php while ($filiere = $result_filieres->fetch_assoc()): ?>
                    <option value="<?php echo $filiere['id_filieres_departements']; ?>"
                        <?php echo ($filiere['id_filieres_departements'] == $cours['id_filieres_departements']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($filiere['filieres_departements_designation']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Mettre à jour</button>
        </form>
    </div>
</body>
</html>
