<?php
// Start session
session_start();

// Database connection
$servername = "localhost";
$username = "geoheininvest"; 
$password = "KUW3.84Hx4wV"; 
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the teacher is logged in
if (!isset($_SESSION['id_enseignant'])) {
    echo "Vous devez être connecté pour envoyer des fichiers.";
    exit;
}

$id_enseignant = $_SESSION['id_enseignant'];
$id_attribution = $_GET['id_attribution'] ?? null;

if (!$id_attribution) {
    echo "Aucune attribution sélectionnée.";
    exit;
}

// Fetch course details for the attribution
$sql = "
    SELECT 
        cours.intitule_cours AS designation_cours
    FROM 
        attribution_cours
    INNER JOIN 
        cours ON attribution_cours.cours_id = cours.cours_id
    WHERE 
        attribution_cours.id_attribution = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_attribution);
$stmt->execute();
$result = $stmt->get_result();
$course = $result->fetch_assoc();

if (!$course) {
    echo "Cours non trouvé pour cette attribution.";
    exit;
}

$designation_cours = $course['designation_cours'];

// Message d'état
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['fichier'])) {
    $fichier = $_FILES['fichier'];
    $nom_fichier = basename($fichier['name']);
    $type_fichier = $fichier['type'];
    $taille_fichier = $fichier['size'];
    $chemin_temporaire = $fichier['tmp_name'];

    // Vérification des types de fichiers autorisés
    $extensions_autorisees = [
        'application/pdf', 
        'application/msword', 
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    if (!in_array($type_fichier, $extensions_autorisees)) {
        $message = "<span style='color: red;'>❌ Seuls les fichiers Word ou PDF sont autorisés.</span>";
    } else {
        // Déplacement du fichier vers le dossier de destination
        $chemin_destination = "uploads/" . $nom_fichier;

        if (move_uploaded_file($chemin_temporaire, $chemin_destination)) {
            // Enregistrer les informations du fichier dans la base de données
            $stmt = $conn->prepare("
                INSERT INTO cours_fichiers (id_attribution, nom_fichier, type_fichier, taille_fichier) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("issi", $id_attribution, $nom_fichier, $type_fichier, $taille_fichier);
            $stmt->execute();

            $message = "<span style='color: green;'>✅ Fichier envoyé avec succès.</span>";
        } else {
            $message = "<span style='color: red;'>❌ Erreur lors de l'envoi du fichier.</span>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envoyer un fichier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }

        h2 {
            color: #4CAF50;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="file"] {
            display: block;
            margin-bottom: 20px;
        }

        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        a.back-button {
            margin-bottom: 20px;
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        a.back-button:hover {
            background-color: #45a049;
        }

        .message {
            margin-top: 10px;
            font-size: 1em;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Button to go back -->
    <a href="g_notes_cours.php" class="back-button">Retour à vos cours</a>

    <h2>Envoyer un fichier pour le cours "<?php echo htmlspecialchars($designation_cours); ?>"</h2>

    <!-- Formulaire d'envoi de fichier -->
    <form method="POST" enctype="multipart/form-data">
        <label for="fichier">📁 Sélectionnez un fichier (PDF ou Word) :</label>
        <input type="file" name="fichier" id="fichier" required>
        <button type="submit">📤 Envoyer</button>
    </form>

    <!-- Message d'état -->
    <?php if ($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>
</body>
</html>
