<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set UTF-8 charset
$conn->set_charset("utf8mb4");

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the logged-in user's information
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql_user);

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows > 0) {
    $logged_user = $user_result->fetch_assoc();
} else {
    die("Utilisateur non trouvé.");
}

$stmt->close();

// Initialize messages
$error = "";
$success = "";

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and clean form data
    $designation = trim($_POST['filieres_departements_designation']);
    $objectif = trim($_POST['objectif_filiere']);
    $competences = trim($_POST['competence_vises']);
    $metiers = trim($_POST['metiers_cibles']);
    $formation_types = isset($_POST['formation_type']) ? implode(", ", $_POST['formation_type']) : null; 
    $id_programmes = intval($_POST['id_programmes']);
    
    // Clean data to avoid unwanted characters and ensure proper accents handling
    $designation = preg_replace('/[^\p{L}\p{N}\s\'\-]/u', '', $designation);
    $objectif = preg_replace('/[^\p{L}\p{N}\s\'\-]/u', '', $objectif);
    $competences = preg_replace('/[^\p{L}\p{N}\s\'\-]/u', '', $competences);
    $metiers = preg_replace('/[^\p{L}\p{N}\s\'\-]/u', '', $metiers);

    // Check for duplicates
    $checkQuery = "SELECT * FROM filieres_departements 
                   WHERE filieres_departements_designation = ? AND id_programmes = ?";
    $stmt_check = $conn->prepare($checkQuery);

    if ($stmt_check === false) {
        die("Erreur de préparation de la requête : " . $conn->error);
    }

    $stmt_check->bind_param("si", $designation, $id_programmes);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        $error = "Une filière avec cette désignation existe déjà pour ce programme.";
    } else {
        // Insertion dans la table `filieres_departements`
        $insertQuery = "INSERT INTO filieres_departements 
                        (filieres_departements_designation, objectif_filiere, competence_vises, metiers_cibles, formation_type, id_programmes) 
                        VALUES (?, ?, ?, ?, ?, ?)";

        $stmt_insert = $conn->prepare($insertQuery);

        if ($stmt_insert === false) {
            die("Erreur de préparation de la requête d'insertion : " . $conn->error);
        }

        $stmt_insert->bind_param("sssssi", $designation, $objectif, $competences, $metiers, $formation_types, $id_programmes);

        if ($stmt_insert->execute()) {
            $success = "Filière enregistrée avec succès.";
        } else {
            $error = "Erreur lors de l'enregistrement : " . $stmt_insert->error;
        }

        $stmt_insert->close();
    }

    $stmt_check->close();
}

$conn->close();
?>





<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Programmes - CIREP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            background-color: #5DADE2;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #3498DB;
            color: white;
            padding: 15px 20px;
        }

        header img {
            width: 60px;
            height: auto;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            gap: 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            padding: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            padding: 20px;
        }

        .sidebar {
            width: 200px;
            background: #f4f4f4;
            border: 1px solid #ddd;
            padding: 15px;
        }

        .sidebar h3 {
            margin-bottom: 15px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            text-decoration: none;
            color: #333;
        }

        .register-container {
            flex: 1;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        label {
            width: 30%;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="email"], input[type="password"], select {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            background-color: #3498DB;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #5DADE2;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
<style>
    .error {
        color: red;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #ffe6e6;
        padding: 10px;
        border: 1px solid red;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .error-icon {
        color: red;
        font-size: 18px;
    }

    .success {
        color: green;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #e6ffe6;
        padding: 10px;
        border: 1px solid green;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .success-icon {
        color: green;
        font-size: 18px;
    }
</style>

   <header>
        
        <h1 style='color:white'>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <div class="navbar">
        <a href="dashboardDG.php">Accueil</a>
       
        <a href="logout.php">Déconnexion</a>
    </div>

    <div class="main-content">
       <div class="sidebar">
    <h3>Liens rapides</h3>
   <ul>
      
       <li><a href="g_programmesDG.php">Facultés </a></li>
   
        <li><a href="g_filiereDG.php">Filières ou départements </a></li>
        <li><a href="g_coursDG.php">Les cours </a></li>
        <li><a href="g_enseignantDG.php">Les Enseignants </a></li>
         <li><a href="g_attributionDG.php">Attribution des cours aux enseignants </a></li>
    
    </ul>
</div>
<style>
    .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.update-link {
    display: inline-block;
    text-decoration: none;
    font-size: 16px;
    color: white;
    background-color: #3498DB; /* Bleu */
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.update-link:hover {
    background-color: #2C81BA; /* Couleur légèrement plus foncée au survol */
    transform: scale(1.05); /* Agrandir légèrement au survol */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
}
</style>


        <div class="register-container">
	 <a href="mise_en_forme_filieresDG.php" class="update-link">Mise à jour </a>


            <h3 style='color:red'>Enregistrez les filières des facultés organisées par votre institution dans le système CIREP catalogue</h3>
            <?php if (!empty($error)): ?>
				<p class="error">
					<span class="error-icon">&#10060;</span> <!-- Error Icon -->
					<?php echo $error; ?>
				</p>
			<?php endif; ?>

			<?php if (!empty($success)): ?>
				<p class="success">
					<span class="success-icon">&#10004;</span> <!-- Success Icon -->
					<?php echo $success; ?>
				</p>
			<?php endif; ?>

		<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">

           <div class="form-group">
                <label for="filieres_departements_designation">Désignation de la Filière :</label>
                <input type="text" id="filieres_departements_designation" name="filieres_departements_designation" required>
            </div>
			<div class="form-group">
				<label for="objectif_filiere">Objectif de la filière :</label>
				<textarea id="objectif_filiere" name="objectif_filiere" rows="4" required 
						  style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
				<ul id="objectif_filiere_preview" class="preview-list"></ul>
			</div>

			<div class="form-group">
				<label for="competence_vises">Compétences visées :</label>
				<textarea id="competence_vises" name="competence_vises" rows="4" required 
						  style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
				<ul id="competence_vises_preview" class="preview-list"></ul>
			</div>

			<div class="form-group">
				<label for="metiers_cibles">Métiers cibles ou Perspectives d'emploi de la filière :</label>
				<textarea id="metiers_cibles" name="metiers_cibles" rows="4" required 
						  style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
				<ul id="metiers_cibles_preview" class="preview-list"></ul>
			</div>

			<script>
				// Fonction pour mettre à jour les puces dynamiques
				function updateBulletList(textareaId, previewId) {
					const textarea = document.getElementById(textareaId);
					const previewList = document.getElementById(previewId);

					textarea.addEventListener('input', () => {
						const lines = textarea.value.split('\n');
						previewList.innerHTML = ''; // Réinitialiser les puces

						lines.forEach(line => {
							if (line.trim() !== '') {
								const li = document.createElement('li');
								li.textContent = line.trim();
								previewList.appendChild(li);
							}
						});
					});
				}

				// Appliquer la fonction à chaque champ
				updateBulletList('objectif_filiere', 'objectif_filiere_preview');
				updateBulletList('competence_vises', 'competence_vises_preview');
				updateBulletList('metiers_cibles', 'metiers_cibles_preview');
			</script>

			<style>
				.preview-list {
					list-style-type: disc; /* Type de puce */
					margin-top: 10px;
					padding-left: 20px;
					color: #3498DB; /* Couleur bleue pour les puces */
				}

				.preview-list li {
					margin-bottom: 5px; /* Espacement entre les lignes */
					font-size: 14px; /* Taille du texte */
				}
			</style>
		

		<div class="form-group">
			<label>Cocher le type de formation pour cette filière :</label>
			<div style="margin-top: 10px;">
				<label>
					<input type="checkbox" name="formation_type[]" value="Courte durée" style="margin-right: 5px;">
					Courte durée
				</label><br>
				<label>
					<input type="checkbox" name="formation_type[]" value="Licence" style="margin-right: 5px;">
					Licence
				</label><br>
				<label>
					<input type="checkbox" name="formation_type[]" value="Master" style="margin-right: 5px;">
					Master
				</label><br>
				<label>
					<input type="checkbox" name="formation_type[]" value="Doctorat" style="margin-right: 5px;">
					Doctorat
				</label>
			</div>
		</div>



           <div class="form-group">
				<label for="id_programmes">La faculté pour cette filière:</label>
				<select id="id_programmes" name="id_programmes" required>
					<option value="" disabled selected>-- Sélectionnez une faculté --</option>
					<?php
					// Connexion à la base de données
				$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

					$conn = new mysqli($servername, $username, $password, $database);

					// Vérifier la connexion
					if ($conn->connect_error) {
						die("Échec de la connexion : " . $conn->connect_error);
					}

					// Récupérer les institutions
					$query = "SELECT * from institutions, programmes_formations  WHERE programmes_formations.institution_id = institutions.institution_id ORDER BY sigle ASC";
					$result = $conn->query($query);

					// Remplir le select avec les résultats
					if ($result->num_rows > 0) {
						while ($row = $result->fetch_assoc()) {
							echo '<option value="' . $row['id_programmes'] . '">' . htmlspecialchars($row['designation_programmes']) . ' / '.htmlspecialchars($row['sigle']).'</option>';
						}
					} else {
						echo '<option value="" disabled>Aucun programme disponible</option>';
					}

					// Fermer la connexion
					$conn->close();
					?>
				</select><br><br>
			</div>

			
            
            
            <button type="submit">Enregistrer</button>
        </form>
           
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. Tous droits réservés.</p>
    </footer>
	

</body>
</html>
