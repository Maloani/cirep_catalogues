<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "geoheininvest", "KUW3.84Hx4wV", "geoheininvest_heineken");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Variables de pagination
$resultsPerPage = 4;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $resultsPerPage;

// Construire les filtres dynamiques
$whereClauses = [];
if (!empty($_GET['search'])) {
    $whereClauses[] = "(f.filieres_departements_designation LIKE '%" . $conn->real_escape_string($_GET['search']) . "%' OR p.designation_programmes LIKE '%" . $conn->real_escape_string($_GET['search']) . "%')";
}
if (!empty($_GET['programme'])) {
    $whereClauses[] = "p.designation_programmes = '" . $conn->real_escape_string($_GET['programme']) . "'";
}
if (!empty($_GET['filiere'])) {
    $whereClauses[] = "f.filieres_departements_designation = '" . $conn->real_escape_string($_GET['filiere']) . "'";
}
if (!empty($_GET['institution'])) {
    $whereClauses[] = "i.sigle = '" . $conn->real_escape_string($_GET['institution']) . "'";
}

$whereSql = count($whereClauses) > 0 ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

// Requête principale avec filtres ou par défaut
$sql = "
    SELECT 
        f.filieres_departements_designation AS filiere,
        p.designation_programmes AS programme,
        GROUP_CONCAT(DISTINCT CONCAT(i.sigle, '|', i.logo, '|', i.pays) SEPARATOR ';') AS institutions,
        f.formation_type AS type_formation
    FROM filieres_departements f
    LEFT JOIN programmes_formations p ON f.id_programmes = p.id_programmes
    LEFT JOIN institutions i ON p.institution_id = i.institution_id
    $whereSql
    GROUP BY f.filieres_departements_designation, p.designation_programmes, f.formation_type
    ORDER BY f.filieres_departements_designation
    LIMIT $resultsPerPage OFFSET $offset";

$result = $conn->query($sql);

// Pagination
$sqlTotal = "
    SELECT COUNT(DISTINCT f.filieres_departements_designation) AS total
    FROM filieres_departements f
    LEFT JOIN programmes_formations p ON f.id_programmes = p.id_programmes
    LEFT JOIN institutions i ON p.institution_id = i.institution_id
    $whereSql";
$totalResult = $conn->query($sqlTotal);
$totalRows = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $resultsPerPage);

// Fonction d'affichage
function displayFiliere($row) {
    $filiere = htmlspecialchars($row['filiere']);
    $programme = htmlspecialchars($row['programme']);
    $typeFormation = htmlspecialchars($row['type_formation']);
    $institutions = explode(';', $row['institutions']);

    echo '<div class="filiere-card" style="border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 20px; background-color: #f9f9f9; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">';
    echo '<h5 style="color: #007BFF; text-align: center;">' . $programme . '</h5>';
    echo '<div style="display: flex; flex-wrap: wrap; gap: 15px; justify-content: center;">';
    foreach ($institutions as $institution) {
        list($sigle, $logo, $country) = explode('|', $institution);
        $logo = $logo ?: 'default_logo.png';
        echo '<div style="text-align: center;">';
        echo '<img src="' . $logo . '" alt="' . htmlspecialchars($sigle) . '" style="height: 50px;">';
        echo '<div><strong>' . htmlspecialchars($sigle) . '</strong><br><span>' . htmlspecialchars($country) . '</span></div>';
        echo '</div>';
    }
    echo '</div>';
    echo '<h6 style="color: #800000; text-align: center;">Filière : ' . $filiere . '</h6>';
    echo '<p style="text-align: center;"><strong>Type :</strong> ' . $typeFormation . '</p>';
    echo '<div style="text-align: center;">';
    echo '<a href="apply.php?filiere=' . urlencode($filiere) . '" class="btn btn-apply">Postuler</a>';
    echo '<a href="details_filiere.php?filiere=' . urlencode($filiere) . '" class="btn btn-details">Voir plus</a>';
    echo '</div>';
    echo '</div>';
}

// Affichage des résultats
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        displayFiliere($row);
    }

    // Pagination
    echo '<div class="pagination">';
    if ($page > 1) {
        echo '<a href="?page=' . ($page - 1) . '" class="btn btn-pagination">Précédent</a>';
    }
    for ($i = 1; $i <= $totalPages; $i++) {
        if ($i == 1 || $i == $totalPages || abs($i - $page) <= 1) {
            echo '<a href="?page=' . $i . '" class="btn btn-pagination ' . ($i == $page ? 'btn-active' : '') . '">' . $i . '</a>';
        } elseif (abs($i - $page) == 2) {
            echo '<span style="padding: 10px 20px; margin: 5px; color: #777;">...</span>';
        }
    }
    if ($page < $totalPages) {
        echo '<a href="?page=' . ($page + 1) . '" class="btn btn-pagination">Suivant</a>';
    }
    echo '</div>';
} else {
    echo '<p>Aucune filière trouvée.</p>';
}

$conn->close();
?>
