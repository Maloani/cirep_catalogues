<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set UTF-8 charset
$conn->set_charset("utf8mb4");

// Check if a program ID is passed
if (!isset($_GET['id'])) {
    die("ID du programme non fourni.");
}

$id_programme = intval($_GET['id']);

// Fetch the program data
$sql_programme = "SELECT * FROM programmes_formations WHERE id_programmes = ?";
$stmt_programme = $conn->prepare($sql_programme);

if ($stmt_programme === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt_programme->bind_param("i", $id_programme);
$stmt_programme->execute();
$result_programme = $stmt_programme->get_result();

if ($result_programme->num_rows === 0) {
    die("Programme non trouvé.");
}

$programme = $result_programme->fetch_assoc();
$stmt_programme->close();

// Fetch institutions for the dropdown
$sql_institutions = "SELECT institution_id, sigle FROM institutions";
$result_institutions = $conn->query($sql_institutions);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $designation_programmes = htmlspecialchars(trim($_POST['designation_programmes']), ENT_QUOTES, 'UTF-8');
    $institution_id = intval($_POST['institution_id']);

    // Validate input
    if (empty($designation_programmes) || $institution_id <= 0) {
        $error = "Tous les champs sont obligatoires.";
    } else {
        // Update the program
        $update_sql = "UPDATE programmes_formations 
                       SET designation_programmes = ?, institution_id = ?
                       WHERE id_programmes = ?";
        $stmt_update = $conn->prepare($update_sql);

        if ($stmt_update === false) {
            die("Erreur de préparation de la requête : " . $conn->error);
        }

        $stmt_update->bind_param("sii", $designation_programmes, $institution_id, $id_programme);

        if ($stmt_update->execute()) {
            echo "<script>alert('Programme mis à jour avec succès.'); window.location.href = 'mise_en_forme_programmesDG.php';</script>";
        } else {
            $error = "Erreur lors de la mise à jour : " . $stmt_update->error;
        }

        $stmt_update->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Programme</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #3498DB;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        form label {
            margin-top: 10px;
            font-weight: bold;
        }

        form input, form select, form button {
            margin-top: 5px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        form button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        form button:hover {
            background-color: #45a049;
        }

        .return-btn {
            display: block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #3498DB;
            color: white;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
        }

        .return-btn:hover {
            background-color: #2980b9;
        }

        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="mise_en_jour_programmesDG.php" class="return-btn">Retour</a>
        <h1>Modifier Faculté</h1>

        <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="designation_programmes">Faculté :</label>
            <input type="text" id="designation_programmes" name="designation_programmes" 
                   value="<?php echo htmlspecialchars($programme['designation_programmes']); ?>" required>

            <label for="institution_id">Institution :</label>
            <select id="institution_id" name="institution_id" required>
                <option value="" disabled>-- Sélectionnez une institution --</option>
                <?php while ($institution = $result_institutions->fetch_assoc()): ?>
                    <option value="<?php echo $institution['institution_id']; ?>" 
                        <?php echo ($institution['institution_id'] == $programme['institution_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($institution['sigle']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Mettre à jour</button>
        </form>
    </div>
</body>
</html>
