<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}


// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Configurer l'encodage UTF-8
$conn->set_charset("utf8mb4");

// Variables pour la recherche et la pagination
$search = isset($_GET['search']) ? htmlspecialchars(trim($_GET['search']), ENT_QUOTES, 'UTF-8') : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Construire la requête pour la recherche
$sql_enseignants = "SELECT * FROM enseignant WHERE 
    (nomcomplet LIKE ? OR niveau_etude LIKE ? OR sexe LIKE ?) 
    LIMIT ?, ?";
$stmt = $conn->prepare($sql_enseignants);
if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$search_param = "%$search%";
$stmt->bind_param("sssii", $search_param, $search_param, $search_param, $offset, $items_per_page);
$stmt->execute();
$result_enseignants = $stmt->get_result();

// Obtenir le nombre total de résultats pour la pagination
$sql_count = "SELECT COUNT(*) as total FROM enseignant WHERE 
    (nomcomplet LIKE ? OR niveau_etude LIKE ? OR sexe LIKE ?)";
$stmt_count = $conn->prepare($sql_count);
if ($stmt_count === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt_count->bind_param("sss", $search_param, $search_param, $search_param);
$stmt_count->execute();
$count_result = $stmt_count->get_result();
$total_items = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);

$stmt->close();
$stmt_count->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Enseignants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #3498DB;
        }

        form {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        form input[type="text"] {
            width: 80%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        form button {
            padding: 8px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        table th {
            background-color: #3498DB;
            color: white;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        .pagination a {
            padding: 8px 12px;
            margin: 0 5px;
            text-decoration: none;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #3498DB;
        }

        .pagination a.active {
            background-color: #3498DB;
            color: white;
        }

        .pagination a:hover {
            background-color: #45a049;
            color: white;
        }

        footer {
            text-align: center;
            background-color: #333;
            color: white;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    
    
    <?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}


// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Configurer l'encodage UTF-8
$conn->set_charset("utf8mb4");

// Variables pour la recherche et la pagination
$search = isset($_GET['search']) ? htmlspecialchars(trim($_GET['search']), ENT_QUOTES, 'UTF-8') : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Construire la requête pour la recherche
$sql_enseignants = "SELECT * FROM enseignant WHERE 
    (nomcomplet LIKE ? OR niveau_etude LIKE ? OR sexe LIKE ?) 
    LIMIT ?, ?";
$stmt = $conn->prepare($sql_enseignants);
if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$search_param = "%$search%";
$stmt->bind_param("sssii", $search_param, $search_param, $search_param, $offset, $items_per_page);
$stmt->execute();
$result_enseignants = $stmt->get_result();

// Obtenir le nombre total de résultats pour la pagination
$sql_count = "SELECT COUNT(*) as total FROM enseignant WHERE 
    (nomcomplet LIKE ? OR niveau_etude LIKE ? OR sexe LIKE ?)";
$stmt_count = $conn->prepare($sql_count);
if ($stmt_count === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt_count->bind_param("sss", $search_param, $search_param, $search_param);
$stmt_count->execute();
$count_result = $stmt_count->get_result();
$total_items = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);

$stmt->close();
$stmt_count->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Enseignants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3498DB;
            color: white;
            padding: 15px 20px;
            text-align: center;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            padding: 5px;
            border-radius: 5px;
        }

        .main-content {
            display: flex;
        }

        .sidebar {
            background-color: #3498DB;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            width: 300px;
            color: white;
        }

        .sidebar h3 {
            font-size: 18px;
            margin-bottom: 15px;
            text-transform: uppercase;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 5px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 10px;
        }

        .sidebar ul li a {
            text-decoration: none;
            font-size: 16px;
            color: white;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .sidebar ul li a:hover {
            background-color: #2C81BA;
            color: white;
        }

        .container {
            flex: 1;
            padding: 20px;
            background: white;
            margin: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        form input[type="text"] {
            width: 80%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        form button {
            padding: 8px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        table th {
            background-color: #3498DB;
            color: white;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        .pagination a {
            padding: 8px 12px;
            margin: 0 5px;
            text-decoration: none;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #3498DB;
        }

        .pagination a.active {
            background-color: #3498DB;
            color: white;
        }

        .pagination a:hover {
            background-color: #45a049;
            color: white;
        }

        footer {
            text-align: center;
            background-color: #333;
            color: white;
            padding: 10px 0;
        }
    </style>
</head>
<body>
<header>
    <h1>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>
</header>

<div class="navbar">
    <a href="dashboard.php">Accueil</a>
    <a href="logout.php">Déconnexion</a>
</div>

<div class="main-content">
    <div class="sidebar">
        <h3>Liens rapides</h3>
        <ul>
            <ul>
        <li><a href="register.php">Ajouter un utilisateur</a></li>
        <li><a href="g_institution.php">Ajouter une institution</a></li>
        <li><a href="g_programmes.php">Programmes organisés </a></li>
        <li><a href="g_recherche.php">Recherches </a></li>
        <li><a href="g_filiere.php">Filières ou départements </a></li>
        <li><a href="s_inscription.php">Situation des inscriptions </a></li>
		 <li><a href="g_cours.php">Gestion des cours </a></li>
        <li><a href="g_Resultats.php">Gestion des résultats </a></li>
        <li><a href="#">Voir les rapports</a></li>
        </ul>
    </div>
   
        <div class="container">
        <h1>Liste des Enseignants</h1>

        <!-- Barre de recherche -->
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Rechercher par nom, grade ou sexe" value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">Rechercher</button>
        </form>

        <!-- Tableau des enseignants -->
        <?php if ($result_enseignants && $result_enseignants->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom Complet</th>
                        <th>Sexe</th>
                        <th>Niveau d'Étude</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Login</th>
                        <th>Mot de passe</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($enseignant = $result_enseignants->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $enseignant['id_enseignant']; ?></td>
                            <td><?php echo htmlspecialchars($enseignant['nomcomplet']); ?></td>
                            <td><?php echo htmlspecialchars($enseignant['sexe']); ?></td>
                            <td><?php echo htmlspecialchars($enseignant['niveau_etude']); ?></td>
                            <td><?php echo htmlspecialchars($enseignant['mail_enseignant']); ?></td>
                            <td><?php echo htmlspecialchars($enseignant['contact']); ?></td>
                            <td><?php echo htmlspecialchars($enseignant['login']); ?></td>
                            <td><?php echo htmlspecialchars($enseignant['password']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Aucun enseignant trouvé.</p>
        <?php endif; ?>

        <!-- Pagination -->
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>">Précédent</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo ($i == $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>">Suivant</a>
            <?php endif; ?>
        </div>

    </div>
</div>


    
    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. Tous droits réservés.</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
