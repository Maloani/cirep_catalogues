<?php
// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérifier si un ID est passé
if (!isset($_GET['id'])) {
    die("ID non fourni.");
}

$id = intval($_GET['id']);

// Récupérer les données de la filière
$sql = "SELECT fd.*, pf.designation_programmes 
        FROM filieres_departements fd
        LEFT JOIN programmes_formations pf ON fd.id_programmes = pf.id_programmes
        WHERE id_filieres_departements = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Filière non trouvée.");
}

$filiere = $result->fetch_assoc();

// Traiter la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $designation = htmlspecialchars(trim($_POST['designation']), ENT_QUOTES, 'UTF-8');
    $formation_type = htmlspecialchars(trim($_POST['formation_type']), ENT_QUOTES, 'UTF-8');
    $objectif_filiere = htmlspecialchars(trim($_POST['objectif_filiere']), ENT_QUOTES, 'UTF-8');
    $competence_vises = htmlspecialchars(trim($_POST['competence_vises']), ENT_QUOTES, 'UTF-8');
    $metiers_cibles = htmlspecialchars(trim($_POST['metiers_cibles']), ENT_QUOTES, 'UTF-8');
    $id_programmes = intval($_POST['id_programmes']);

    // Mettre à jour uniquement les données de filieres_departements
    $update_sql = "UPDATE filieres_departements 
                   SET filieres_departements_designation = ?, 
                       formation_type = ?, 
                       objectif_filiere = ?, 
                       competence_vises = ?, 
                       metiers_cibles = ?, 
                       id_programmes = ?
                   WHERE id_filieres_departements = ?";
    $update_stmt = $conn->prepare($update_sql);

    if ($update_stmt === false) {
        die("Erreur de préparation de la requête : " . $conn->error);
    }

    $update_stmt->bind_param("ssssssi", $designation, $formation_type, $objectif_filiere, $competence_vises, $metiers_cibles, $id_programmes, $id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Filière mise à jour avec succès.'); window.location.href = 'mise_en_forme_filieres.php';</script>";
    } else {
        echo "Erreur lors de la mise à jour : " . $update_stmt->error;
    }

    $update_stmt->close();
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Filière</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #3498DB;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        form label {
            margin-top: 10px;
            font-weight: bold;
        }

        form input, form select, form textarea, form button {
            margin-top: 5px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        form textarea {
            height: 100px;
            resize: vertical;
        }

        form button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        form button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Modifier Filière</h1>
        <form method="POST" action="">
            <label for="designation">Désignation :</label>
            <input type="text" id="designation" name="designation" value="<?php echo htmlspecialchars($filiere['filieres_departements_designation']); ?>" required>

            <label for="formation_type">Type de Formation :</label>
            <input type="text" id="formation_type" name="formation_type" value="<?php echo htmlspecialchars($filiere['formation_type']); ?>" required>

            <label for="objectif_filiere">Objectif :</label>
            <textarea id="objectif_filiere" name="objectif_filiere" required><?php echo htmlspecialchars($filiere['objectif_filiere']); ?></textarea>

            <label for="competence_vises">Compétences visées :</label>
            <textarea id="competence_vises" name="competence_vises" required><?php echo htmlspecialchars($filiere['competence_vises']); ?></textarea>

            <label for="metiers_cibles">Métiers cibles :</label>
            <textarea id="metiers_cibles" name="metiers_cibles" required><?php echo htmlspecialchars($filiere['metiers_cibles']); ?></textarea>

            <label for="id_programmes">Faculté :</label>
            <select id="id_programmes" name="id_programmes" required>
                <option value="" disabled selected>-- Sélectionnez une faculté --</option>
                <?php
                // Récupérer la liste des programmes pour le menu déroulant
                $programme_sql = "SELECT * FROM programmes_formations";
                $programme_result = $conn->query($programme_sql);

                if (!$programme_result) {
                    echo "<option value='' disabled>Erreur de récupération</option>";
                } elseif ($programme_result->num_rows > 0) {
                    while ($programme = $programme_result->fetch_assoc()) {
                        echo "<option value='{$programme['id_programmes']}'" . 
                            (($programme['id_programmes'] == $filiere['id_programmes']) ? ' selected' : '') . 
                            ">{$programme['designation_programmes']}</option>";
                    }
                } else {
                    echo '<option value="" disabled>Aucun programme disponible</option>';
                }
                ?>
            </select>

            <button type="submit">Mettre à jour</button>
        </form>
    </div>
</body>
</html>
