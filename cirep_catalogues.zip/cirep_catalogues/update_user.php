<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

try {
    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        throw new Exception("Erreur de connexion : " . $conn->connect_error);
    }
} catch (Exception $e) {
    die($e->getMessage());
}

// Vérifier si l'ID de l'utilisateur est passé dans l'URL
if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']); // S'assurer que l'ID est un entier

    // Récupérer les informations de l'utilisateur
    $sql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
    } else {
        die("Erreur dans la préparation de la requête.");
    }
} else {
    die("Aucun utilisateur spécifié.");
}

// Vérifier si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = htmlspecialchars($_POST['prenom']);
    $nom = htmlspecialchars($_POST['nom']);
    $email = htmlspecialchars($_POST['email']);
    $role = htmlspecialchars($_POST['role']);
    $login = htmlspecialchars($_POST['login']);
    $pwd = htmlspecialchars($_POST['pwd']); // Vous pouvez utiliser password_hash() ici

    // Mise à jour de l'utilisateur
    $sql_update = "UPDATE users SET prenom = ?, nom = ?, email = ?, role = ?, login = ?, pwd = ? WHERE user_id = ?";
    $stmt_update = $conn->prepare($sql_update);

    if ($stmt_update) {
        $stmt_update->bind_param("ssssssi", $prenom, $nom, $email, $role, $login, $pwd, $user_id);
        if ($stmt_update->execute()) {
            header("Location: dashboard.php?message=Utilisateur modifié avec succès");
            exit();
        } else {
            echo "Erreur lors de la mise à jour.";
        }
    } else {
        die("Erreur dans la préparation de la requête de mise à jour.");
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Modifier un utilisateur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #3498DB;
            color: white;
            padding: 10px;
            text-align: center;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        form label {
            display: block;
            margin: 15px 0 5px;
        }

        form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        form button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
        }

        form button:hover {
            opacity: 0.9;
        }

        .back-link {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #3498DB;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<header>
    <h1>Modifier un utilisateur</h1>
</header>
<div class="container">
    <form method="POST">
        <label for="prenom">Prénom :</label>
        <input type="text" name="prenom" id="prenom" value="<?php echo htmlspecialchars($user['prenom']); ?>" required>

        <label for="nom">Nom :</label>
        <input type="text" name="nom" id="nom" value="<?php echo htmlspecialchars($user['nom']); ?>" required>

        <label for="email">Email :</label>
        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

        <label for="role">Rôle :</label>
        <input type="text" name="role" id="role" value="<?php echo htmlspecialchars($user['role']); ?>" required>

        <label for="login">Login :</label>
        <input type="text" name="login" id="login" value="<?php echo htmlspecialchars($user['login']); ?>" required>

        <label for="pwd">Mot de passe :</label>
        <input type="password" name="pwd" id="pwd" value="<?php echo htmlspecialchars($user['pwd']); ?>" required>

        <button type="submit">Enregistrer</button>
    </form>
    <a class="back-link" href="dashboard.php">Retour à la liste des utilisateurs</a>
</div>
</body>
</html>
