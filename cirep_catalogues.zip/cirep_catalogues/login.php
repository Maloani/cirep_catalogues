<?php
// Start the session
session_start();

// Activer l'affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "Étape 2 : Formulaire soumis<br>";

    $login = trim($_POST['login']);
    $pwd = trim($_POST['pwd']);

    // Check if fields are empty
    if (empty($login) || empty($pwd)) {
        $error = "All fields are required.";
        echo $error . "<br>";
    } else {
        $userFound = false;

        // Function to handle user login and set session
        function handleUserLogin($user, $isTeacher = false) {
            if ($isTeacher) {
                // Enseignant login
                $_SESSION['id_enseignant'] = $user['id_enseignant'];
                $_SESSION['nomcomplet'] = $user['nomcomplet'];
                $_SESSION['sexe'] = $user['sexe'];
                $_SESSION['niveau_etude'] = $user['niveau_etude'];
                $_SESSION['mail_enseignant'] = $user['mail_enseignant'];
                header("Location: dashboardEns.php");
            } else {
                // Users login with roles
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['prenom'] = $user['prenom'];
                $_SESSION['nom'] = $user['nom'];
                $_SESSION['role'] = $user['role'];

                switch ($user['role']) {
                    case 'Admin':
                        header("Location: dashboard.php");
                        break;
                    case 'DG':
                        header("Location: dashboardDG.php");
                        break;
                    case 'Finances':
                        header("Location: dashboardcomptable.php");
                        break;
                    default:
                        header("Location: dashboard.php");
                        break;
                }
            }
            exit;
        }

        // Check in `users` table
      
        $stmt = $conn->prepare("SELECT * FROM users WHERE login = ?");
        $stmt->bind_param("s", $login);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // Vérifier le mot de passe
            if ($pwd === $user['pwd']) { // Remplacez par `password_verify` si nécessaire
                $userFound = true;
                handleUserLogin($user);
            }
        }
        $stmt->close();

        // If not found in `users`, check in `enseignant`
        if (!$userFound) {
            
            $stmt = $conn->prepare("SELECT * FROM enseignant WHERE login = ?");
            $stmt->bind_param("s", $login);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $teacher = $result->fetch_assoc();
                // Vérifier le mot de passe
                if ($pwd === $teacher['password']) { // Remplacez par `password_verify` si nécessaire
                    handleUserLogin($teacher, true);
                }
            } else {
                $error = "Invalid login or password.";
                echo $error . "<br>";
            }
            $stmt->close();
        }

        // Final check for errors
        if (!$userFound) {
            $error = "Invalid login or password.";
            echo $error . "<br>";
        }
    }
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CIREP</title>
    <style>
        /* Body with a multicolor gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #ff7eb9, #8b93ff, #50e3c2, #ffcc00);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Gradient animation */
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Login container styling */
        .login-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        /* Icon image styling */
        .login-icon img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: bold;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            outline: none;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="password"]:focus {
            border-color: #4CAF50;
        }

        button {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .footer {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }

        .footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>
    <div class="login-container">
       
        <h1>Login to CIREP</h1>
         <!-- Custom Icon -->
        <div class="login-icon">
            <img src="icone.png" alt="User Icon">
        </div>
        <?php if (!empty($error)): ?>
            <p class="error" style="color:red;"><?php echo $error; ?></p>
        <?php endif; ?>
        <!-- Formulaire -->
        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="login">Login:</label>
                <input type="text" name="login" id="login" placeholder="Enter your login" required>
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" name="pwd" id="pwd" placeholder="Enter your password" required>
            </div>
            <button type="submit">Login</button>
        </form>
        <!-- Footer -->
        <div class="footer">
            <p>Forgot password? <a href="mailto:info@cirep.ac.cd" target="_blank">Contact here</a>.</p>
        </div>
    </div>
</body>
</html>

