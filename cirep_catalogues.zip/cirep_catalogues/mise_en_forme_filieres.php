<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}



// Database connection
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set UTF-8 charset
$conn->set_charset("utf8mb4");

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the logged-in user's information
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql_user);

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows > 0) {
    $logged_user = $user_result->fetch_assoc();
} else {
    die("Utilisateur non trouvé.");
}

$stmt->close();
// Initialiser les variables
$message = "";

// Vérifier l'action de suppression
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_filieres_departements = intval($_GET['id']);

    // Préparer la requête de suppression
    $delete_query = "DELETE FROM filieres_departements WHERE id_filieres_departements = ?";
    $stmt_delete = $conn->prepare($delete_query);

    if ($stmt_delete === false) {
        die("Erreur de préparation de la requête de suppression : " . $conn->error);
    }

    $stmt_delete->bind_param("i", $id_filieres_departements);

    if ($stmt_delete->execute()) {
        $message = "Filière supprimée avec succès.";
    } else {
        $message = "Erreur lors de la suppression : " . $stmt_delete->error;
    }

    $stmt_delete->close();
}

// Nombre de résultats par page
$results_per_page = 4;

// Récupérer la page actuelle (par défaut : 1)
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($page < 1) $page = 1;

// Calculer l'offset pour la requête SQL
$offset = ($page - 1) * $results_per_page;

// Modifier la requête SQL pour la pagination
$sql_paginated = "SELECT filieres_departements.id_filieres_departements, filieres_departements.filieres_departements_designation, 
                         filieres_departements.objectif_filiere, filieres_departements.competence_vises,filieres_departements.metiers_cibles,
						 filieres_departements.formation_type,institutions.sigle, institutions.logo
                  FROM filieres_departements
                  JOIN programmes_formations ON filieres_departements.id_programmes = programmes_formations.id_programmes
                  JOIN institutions ON programmes_formations.institution_id = institutions.institution_id
                  ORDER BY institutions.sigle ASC
                  LIMIT ? OFFSET ?";

$stmt_paginated = $conn->prepare($sql_paginated);
if ($stmt_paginated === false) {
    die("Erreur de préparation de la requête paginée : " . $conn->error);
}
$stmt_paginated->bind_param("ii", $results_per_page, $offset);
$stmt_paginated->execute();
$result_paginated = $stmt_paginated->get_result();

// Vérifier les erreurs SQL pour la pagination
if ($result_paginated === false) {
    die("Erreur lors de l'exécution de la requête : " . $conn->error);
}

// Calculer le nombre total de résultats
$sql_count = "SELECT COUNT(*) AS total FROM filieres_departements";
$result_count = $conn->query($sql_count);

if ($result_count === false) {
    die("Erreur lors de la requête de comptage : " . $conn->error);
}

$row_count = $result_count->fetch_assoc();
$total_results = $row_count['total'];

// Calculer le nombre total de pages
$total_pages = ceil($total_results / $results_per_page);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title><?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom']); ?> - CIREP Dashboard</title>
    <style>
        /* General Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #5DADE2;
            color: white;
            padding: 20px;
            text-align: center;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        header img {
            height: 50px;
            margin-right: 20px;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            padding: 5px 10px;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            border-radius: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            gap: 20px;
            padding: 20px;
            background-color: #5DADE2;
        }

        .sidebar {
            flex: 1;
            background-color: white;
            padding: 15px;
            border: 1px solid #ddd;
        }

        .content {
            flex: 2;
            background-color: white;
            padding: 20px;
            border: 1px solid #ddd;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #5DADE2;
            color: white;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        footer p {
            margin: 0;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }

            .sidebar {
                flex: none;
            }

            .content {
                flex: none;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        
       <h1>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <!-- Navbar -->
    <div class="navbar">
        <a href="dashboard.php">Accueil</a>
       
        
        <a href="logout.php">Déconnexion</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Left Sidebar -->
          <div class="sidebar">
    <h3>Liens rapides</h3>
      <ul>
        <li><a href="register.php">Ajouter un utilisateur</a></li>
        <li><a href="g_institution.php">Ajouter une institution</a></li>
        <li><a href="g_programmes.php">Programmes organisés </a></li>
        <li><a href="g_recherche.php">Recherches </a></li>
        <li><a href="g_filiere.php">Filières ou départements </a></li>
        <li><a href="s_inscription.php">Situation des inscriptions </a></li>
		 <li><a href="g_cours.php">Gestion des cours </a></li>
        <li><a href="g_Resultats.php">Gestion des résultats </a></li>
        <li><a href="#">Voir les rapports</a></li>
    </ul>
</div>
<style>
   .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.success-message {
    background-color: #d4edda;
    color: #155724;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #c3e6cb;
    border-radius: 5px;
}

.error-message {
    background-color: #f8d7da;
    color: #721c24;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #f5c6cb;
    border-radius: 5px;
}

</style>

 <div class="container">
     
    <h4>Rechercher la filière  organisé par votre institution pour la mise à jour</h4></br>

    <!-- Message de confirmation -->
    <?php if (!empty($message)): ?>
        <p class="message"><?php echo $message; ?></p>
    <?php endif; ?>

    <?php
    // Nombre de résultats par page
    $results_per_page = 4;

    // Récupérer la page actuelle (par défaut : 1)
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    if ($page < 1) $page = 1;

    // Calculer l'offset pour la requête SQL
    $offset = ($page - 1) * $results_per_page;

    // Définir la variable de recherche
    $search_query = "";
    $search_term = "%%"; // Par défaut, aucun filtre

    // Vérifier si une recherche a été soumise
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search_query = trim($_GET['search']);
        $search_term = "%" . $search_query . "%"; // Préparer le filtre pour la recherche
    }

    // Modifier la requête SQL pour inclure le filtre de recherche et la pagination
    $sql_paginated = "SELECT filieres_departements.id_filieres_departements, filieres_departements.filieres_departements_designation, 
                             filieres_departements.objectif_filiere, filieres_departements.competence_vises,filieres_departements.metiers_cibles,
						 filieres_departements.formation_type,institutions.sigle, institutions.logo,programmes_formations.designation_programmes
                      FROM filieres_departements
                      JOIN programmes_formations ON filieres_departements.id_programmes = programmes_formations.id_programmes
                      JOIN institutions ON programmes_formations.institution_id = institutions.institution_id
                      WHERE institutions.sigle LIKE ? OR filieres_departements.filieres_departements_designation LIKE ?
                      ORDER BY institutions.sigle ASC
                      LIMIT ? OFFSET ?";

    // Préparer la requête
    $stmt_paginated = $conn->prepare($sql_paginated);

    if ($stmt_paginated === false) {
        die("Erreur de préparation de la requête : " . $conn->error);
    }

    // Passer les paramètres à la requête
    $stmt_paginated->bind_param("ssii", $search_term, $search_term, $results_per_page, $offset);

    // Exécuter la requête
    $stmt_paginated->execute();
    $result_paginated = $stmt_paginated->get_result();

    if ($result_paginated === false) {
        die("Erreur lors de l'exécution de la requête : " . $conn->error);
    }

    // Calculer le nombre total de résultats pour la pagination
    $sql_count = "SELECT COUNT(*) AS total 
                  FROM filieres_departements
                  JOIN programmes_formations ON filieres_departements.id_programmes = programmes_formations.id_programmes
                  JOIN institutions ON programmes_formations.institution_id = institutions.institution_id
                  WHERE institutions.logo LIKE ? OR filieres_departements.filieres_departements_designation LIKE ?";

    $stmt_count = $conn->prepare($sql_count);

    if ($stmt_count === false) {
        die("Erreur de préparation de la requête de comptage : " . $conn->error);
    }

    // Passer les mêmes termes de recherche à la requête de comptage
    $stmt_count->bind_param("ss", $search_term, $search_term);
    $stmt_count->execute();
    $result_count = $stmt_count->get_result();

    if ($result_count === false) {
        die("Erreur lors de la requête de comptage : " . $conn->error);
    }

    $row_count = $result_count->fetch_assoc();
    $total_results = $row_count['total'];

    // Calculer le nombre total de pages
    $total_pages = ceil($total_results / $results_per_page);
    ?>

    <div class="search-container" style="margin-bottom: 20px;">
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Rechercher une institution ou une filière" 
                   value="<?php echo htmlspecialchars($search_query); ?>" 
                   style="padding: 8px; width: 300px; border: 1px solid #ddd; border-radius: 5px;">
            <button type="submit" style="padding: 8px 15px; background-color: red; color: white; border: none; border-radius: 5px; cursor: pointer;">
                Rechercher
            </button>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>Filière</th>
                
                <th>Type de Formation</th>
                <th>Faculté</th>
                <th>Institution</th>
               
                <th>Actions</th>
            </tr>
        </thead>
       <tbody>
    <?php if ($result_paginated->num_rows > 0): ?>
        <?php while ($row = $result_paginated->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['filieres_departements_designation']); ?></td>
                <td><?php echo htmlspecialchars($row['formation_type']); ?></td>
                <td><?php echo htmlspecialchars($row['designation_programmes']); ?></td>
                <td>
                    <?php if (!empty($row['logo']) && file_exists($row['logo'])): ?>
                        <img src="<?php echo $row['logo']; ?>" alt="<?php echo htmlspecialchars($row['sigle']); ?>" 
                             style="width: 50px; height: auto;">
                    <?php else: ?>
                        <span style="color: red;">Pas de logo</span>
                    <?php endif; ?>
                </td>
                <td>
                    <!-- Bouton Supprimer -->
                    <a href="?action=delete&id=<?php echo $row['id_filieres_departements']; ?>" 
                       onclick="return confirm('Voulez-vous vraiment supprimer cette filière ?');"
                       class="btn delete-btn">
                        <i class="fas fa-trash"></i> Supprimer
                    </a>
                    <!-- Bouton Modifier -->
                    <a href="modifier_filiere2.php?id=<?php echo $row['id_filieres_departements']; ?>" 
                       class="btn edit-btn">
                        <i class="fas fa-edit"></i> Modifier
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="5" style="text-align: center;">Aucune filière trouvée.</td>
        </tr>
    <?php endif; ?>
</tbody>
<style>
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 8px 15px;
        border-radius: 5px;
        text-decoration: none;
        color: white;
        font-size: 14px;
        font-weight: bold;
        transition: all 0.3s ease;
        margin-right: 5px;
    }

    .btn i {
        margin-right: 5px;
    }

    .delete-btn {
        background-color: #e74c3c; /* Rouge pour supprimer */
    }

    .delete-btn:hover {
        background-color: #c0392b;
        transform: scale(1.05);
    }

    .edit-btn {
        background-color: #3498db; /* Bleu pour modifier */
    }

    .edit-btn:hover {
        background-color: #2980b9;
        transform: scale(1.05);
    }
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


    </table>

    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search_query); ?>" class="prev">Précédent</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search_query); ?>" 
               class="<?php echo $i == $page ? 'active' : ''; ?>">
               <?php echo $i; ?>
            </a>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search_query); ?>" class="next">Suivant</a>
        <?php endif; ?>
    </div>
</div>



<style>
    .search-container {
        text-align: left;
        margin-bottom: 20px;
    }
    .search-container input[type="text"] {
        padding: 8px;
        width: 300px;
        border: 1px solid #ddd;
        border-radius: 5px;
        margin-right: 10px;
    }
    .search-container button {
        padding: 8px 15px;
        background-color: #3498DB;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .search-container button:hover {
        background-color: #2980B9;
    }
</style>

</div>
<style>
.pagination {
    text-align: center;
    margin-top: 20px;
}

.pagination a {
    display: inline-block;
    margin: 0 5px;
    padding: 10px 15px;
    text-decoration: none;
    border: 1px solid #ddd;
    color: #3498DB;
    border-radius: 5px;
}

.pagination a.active {
    background-color: #3498DB;
    color: white;
    font-weight: bold;
}

.pagination a:hover {
    background-color: #2980B9;
    color: white;
}

.pagination a.prev, .pagination a.next {
    font-weight: bold;
}
</style>



<style>
/* Table Styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    font-family: Arial, sans-serif;
}

thead th {
    padding: 10px;
    background-color: #5DADE2;
    text-align: left;
}

tbody tr {
    border-bottom: 1px solid #ddd;
}

tbody tr:hover {
    background-color: #f9f9f9;
}

td {
    padding: 10px;
    vertical-align: middle;
}

/* Button Styling */
.btn {
    padding: 8px 12px;
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
}

.btn-edit {
    background-color: #4CAF50; /* Green */
}

.btn-delete {
    background-color: #f44336; /* Red */
}

.btn:hover {
    opacity: 0.9;
}

/* Icon Styling */
i {
    font-size: 16px;
}
.actions a {
    text-decoration: none;
    padding: 5px 10px;
    border-radius: 5px;
    color: white;
    font-size: 14px;
}

.actions a.edit {
    background-color: #2980B9;
}

.actions a.delete {
    background-color: #E74C3C;
}

.actions a:hover {
    opacity: 0.8;
}

td img {
    width: 50px;
    height: auto;
    border: 1px solid #ddd;
    border-radius: 5px;
}


</style>

        
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. All rights reserved.</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
