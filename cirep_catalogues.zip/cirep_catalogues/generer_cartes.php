<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer l'ID de l'utilisateur connecté depuis la session
$user_id = intval($_SESSION['user_id']);

// Récupérer les informations de l'utilisateur connecté
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt_user = $conn->prepare($sql_user);
if ($stmt_user === false) {
    die("Erreur de préparation de la requête utilisateur : " . $conn->error);
}
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();

if ($result_user->num_rows > 0) {
    $logged_user = $result_user->fetch_assoc();
} else {
    // Si l'utilisateur n'existe pas, déconnecter et rediriger vers la page de connexion
    header("Location: logout.php");
    exit;
}
$stmt_user->close();

// Initialiser les variables
$message = "";

// Action : Suppression
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $inscription_id = intval($_GET['id']);
    $delete_query = "DELETE FROM inscriptions WHERE inscription_id = ?";
    $stmt_delete = $conn->prepare($delete_query);
    if ($stmt_delete === false) {
        die("Erreur de préparation de la requête de suppression : " . $conn->error);
    }
    $stmt_delete->bind_param("i", $inscription_id);
    if ($stmt_delete->execute()) {
        $message = "Inscription supprimée avec succès.";
    } else {
        $message = "Erreur lors de la suppression : " . $stmt_delete->error;
    }
    $stmt_delete->close();
}

// Action : Confirmation
if (isset($_GET['action']) && $_GET['action'] === 'confirm' && isset($_GET['id'])) {
    $inscription_id = intval($_GET['id']);
    $confirm_query = "UPDATE inscriptions SET statut = 'Confirmed' WHERE inscription_id = ?";
    $stmt_confirm = $conn->prepare($confirm_query);
    if ($stmt_confirm === false) {
        die("Erreur de préparation de la requête de confirmation : " . $conn->error);
    }
    $stmt_confirm->bind_param("i", $inscription_id);
    if ($stmt_confirm->execute()) {
        $message = "Inscription confirmée avec succès.";
    } else {
        $message = "Erreur lors de la confirmation : " . $stmt_confirm->error;
    }
    $stmt_confirm->close();
}

// Action : Rejeter
if (isset($_GET['action']) && $_GET['action'] === 'reject' && isset($_GET['id'])) {
    $inscription_id = intval($_GET['id']);
    $reject_query = "UPDATE inscriptions SET statut = 'Rejected' WHERE inscription_id = ?";
    $stmt_reject = $conn->prepare($reject_query);
    if ($stmt_reject === false) {
        die("Erreur de préparation de la requête de rejet : " . $conn->error);
    }
    $stmt_reject->bind_param("i", $inscription_id);
    if ($stmt_reject->execute()) {
        $message = "Inscription rejetée avec succès.";
    } else {
        $message = "Erreur lors du rejet de l'inscription : " . $stmt_reject->error;
    }
    $stmt_reject->close();
}

// Action : Mettre en attente
if (isset($_GET['action']) && $_GET['action'] === 'pending' && isset($_GET['id'])) {
    $inscription_id = intval($_GET['id']);
    $pending_query = "UPDATE inscriptions SET statut = 'Pending' WHERE inscription_id = ?";
    $stmt_pending = $conn->prepare($pending_query);
    if ($stmt_pending === false) {
        die("Erreur de préparation de la requête de mise en attente : " . $conn->error);
    }
    $stmt_pending->bind_param("i", $inscription_id);
    if ($stmt_pending->execute()) {
        $message = "Inscription mise en attente avec succès.";
    } else {
        $message = "Erreur lors de la mise en attente de l'inscription : " . $stmt_pending->error;
    }
    $stmt_pending->close();
}


// Pagination : Configuration
$results_per_page = 4; // Nombre de résultats par page
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1; // Page actuelle
$offset = ($page - 1) * $results_per_page;

// Calculer LIMIT et OFFSET (assurez-vous que $results_per_page et $offset sont des entiers)
$results_per_page = intval($results_per_page);
$offset = intval($offset);

// Récupérer les inscriptions avec pagination
$sql_paginated = "SELECT * FROM inscriptions WHERE statut='Confirmed' ORDER BY first_name ASC LIMIT $results_per_page OFFSET $offset";

$stmt_paginated = $conn->prepare($sql_paginated);
if ($stmt_paginated === false) {
    die("Erreur de préparation de la requête paginée : " . $conn->error);
}

// Exécuter la requête
$stmt_paginated->execute();

// Obtenir les résultats
$result_paginated = $stmt_paginated->get_result();



// Calculer le nombre total de résultats
$sql_count = "SELECT COUNT(*) AS total FROM inscriptions";
$result_count = $conn->query($sql_count);
if ($result_count === false) {
    die("Erreur lors de la requête de comptage : " . $conn->error);
}
$row_count = $result_count->fetch_assoc();
$total_results = intval($row_count['total']);
$total_pages = ceil($total_results / $results_per_page);

?>

<?php
// Initialiser la variable de recherche
$search_query = ""; // Initialiser avec une valeur par défaut vide
$search_term = "%%"; // Par défaut, aucun filtre

// Vérifier si une recherche a été soumise
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_query = trim($_GET['search']); // Récupérer la requête de recherche
    $search_term = "%" . $search_query . "%"; // Préparer le filtre pour la requête SQL
}

// Définir les autres paramètres pour la pagination et l'affichage des résultats
// Requête SQL pour récupérer les inscriptions Confirmed avec pagination
$sql_paginated = "SELECT * 
                  FROM inscriptions
                  WHERE statut = 'Confirmed'
                  ORDER BY matricule ASC
                  LIMIT ? OFFSET ?";

$stmt_paginated = $conn->prepare($sql_paginated);
if ($stmt_paginated === false) {
    die("Erreur de préparation de la requête paginée : " . $conn->error);
}
$stmt_paginated->bind_param("ii", $results_per_page, $offset);

// Exécuter la requête
$stmt_paginated->execute();
$result_paginated = $stmt_paginated->get_result();

// Requête SQL pour compter les inscriptions Confirmed
$sql_count = "SELECT COUNT(*) AS total 
              FROM inscriptions
              WHERE statut = 'Confirmed'";

$result_count = $conn->query($sql_count);
if ($result_count === false) {
    die("Erreur lors de la requête de comptage : " . $conn->error);
}

$row_count = $result_count->fetch_assoc();
$total_results = intval($row_count['total']);
$total_pages = ceil($total_results / $results_per_page);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	

    <title><?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom']); ?> - CIREP Dashboard</title>
    <style>
        /* General Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #5DADE2;
            color: white;
            padding: 20px;
            text-align: center;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        header img {
            height: 50px;
            margin-right: 20px;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            padding: 5px 10px;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            border-radius: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            gap: 20px;
            padding: 20px;
            background-color: #5DADE2;
        }

        .sidebar {
            flex: 1;
            background-color: white;
            padding: 15px;
            border: 1px solid #ddd;
        }

        .content {
            flex: 2;
            background-color: white;
            padding: 20px;
            border: 1px solid #ddd;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #5DADE2;
            color: white;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        footer p {
            margin: 0;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }

            .sidebar {
                flex: none;
            }

            .content {
                flex: none;
            }
        }
		/* Styles CSS pour le tableau et la pagination */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        table th {
            background-color: #3498DB;
            color: white;
        }

        .pagination {
            text-align: center;
            margin-bottom: 20px;
        }

        .pagination a {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 4px;
            border: 1px solid #ddd;
            color: #3498DB;
            text-decoration: none;
        }

        .pagination a.active {
            background-color: #3498DB;
            color: white;
        }

        .message {
            color: green;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .error {
            color: red;
            font-weight: bold;
            margin-bottom: 20px;
        }

    </style>
</head>
<body>
    <!-- Header -->
    <header>
        
       <h1>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <!-- Navbar -->
    <div class="navbar">
        <a href="dashboardcomptable.php">Accueil</a>
       
        
        <a href="logout.php">Déconnexion</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Left Sidebar -->
          <div class="sidebar">
    <h3>Liens rapides</h3>
      <ul>
         <li><a href="s_inscription2.php">Situation des inscriptions</a></li>
        <li><a href="generer_cartes.php">Generer les cartes d'étudiant</a></li>
        <li><a href="generer_recus.php">Gérer les déclarations de paiements</a></li>
       
    </ul>
</div>
<style>
   .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.success-message {
    background-color: #d4edda;
    color: #155724;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #c3e6cb;
    border-radius: 5px;
}

.error-message {
    background-color: #f8d7da;
    color: #721c24;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #f5c6cb;
    border-radius: 5px;
}

</style>

 <div class="container">
    <h1>Recherchez un étudiant pour générer sa carte</h1></br>

   

  <div class="search-container" style="margin-bottom: 20px; display: flex; gap: 10px; align-items: center;">
    <!-- Formulaire de recherche -->
    <form method="GET" action="" style="display: flex; align-items: center; gap: 10px;">
        <input type="text" name="search" placeholder="Rechercher par matricule, nom, filière, institution ou pays" 
               value="<?php echo htmlspecialchars($search_query); ?>" 
               style="padding: 8px; width: 300px; border: 1px solid #ddd; border-radius: 5px;">
        <button type="submit" style="padding: 8px 15px; background-color: blue; color: white; border: none; border-radius: 5px; cursor: pointer; display: flex; align-items: center; gap: 5px;">
            <i class="fas fa-search"></i> Rechercher
        </button>
    </form>

    <!-- Bouton pour générer les cartes d'étudiant -->
    <button type="button" onclick="location.href='generer_cartes.php';" style="padding: 8px 15px; background-color: green; color: white; border: none; border-radius: 5px; cursor: pointer; display: flex; align-items: center; gap: 5px;">
        <i class="fas fa-id-card"></i> Générer les cartes d'étudiant
    </button>
    
    <!-- Bouton pour générer les reçus d'inscription -->
    <button type="button" onclick="location.href='generer_recus.php';" style="padding: 8px 15px; background-color: orange; color: white; border: none; border-radius: 5px; cursor: pointer; display: flex; align-items: center; gap: 5px;">
        <i class="fas fa-receipt"></i> Générer les reçus d'inscription
    </button>

</div>


<table>
    <thead>
        <tr>
            <th>Matricule</th>
            <th>Nom complet</th>
            <th>Filière</th>
            <th>Institution</th>
            <th>Pays</th>
            <th>Date de naissance</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Statut</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
<?php if ($result_paginated->num_rows > 0): ?>
    <?php while ($row = $result_paginated->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['matricule']); ?></td>
            <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
            <td><?php echo htmlspecialchars($row['filiere']); ?></td>
            <td><?php echo htmlspecialchars($row['institution']); ?></td>
            <td><?php echo htmlspecialchars($row['country']); ?></td>
            <td><?php echo htmlspecialchars($row['date_of_birth']); ?></td>
            <td><?php echo htmlspecialchars($row['email']); ?></td>
            <td><?php echo htmlspecialchars($row['phone']); ?></td>
            <td>
                <span style="color: green;"><?php echo htmlspecialchars($row['statut']); ?></span>
            </td>
            <td>
                <!-- Ajouter les boutons d'action ici -->
                <a href="generate_student_card.php?id=<?php echo $row['inscription_id']; ?>" 
                   class="btn btn-edit">Générer</a>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr>
        <td colspan="10" style="text-align: center;">Aucune inscription Confirmed trouvée.</td>
    </tr>
<?php endif; ?>
</tbody>


</table>



<style>
    /* Style général du tableau */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        font-family: Arial, sans-serif;
    }

    table th, table td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
    }

    table th {
        background-color: #3498DB;
        color: white;
    }

    /* Style pour les boutons */
    .btn {
        padding: 8px 15px;
        border-radius: 5px;
        font-size: 14px;
        text-decoration: none;
        color: white;
        display: inline-block;
        text-align: center;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .btn-edit {
        background-color: #4CAF50; /* Vert */
    }

    .btn-edit:hover {
        background-color: #45A049;
        transform: scale(1.05);
    }

    .btn-delete {
        background-color: #E74C3C; /* Rouge */
    }

    .btn-delete:hover {
        background-color: #C0392B;
        transform: scale(1.05);
    }
</style>


    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search_query); ?>" class="prev">Précédent</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search_query); ?>" 
               class="<?php echo $i == $page ? 'active' : ''; ?>">
               <?php echo $i; ?>
            </a>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search_query); ?>" class="next">Suivant</a>
        <?php endif; ?>
    </div>
</div>



<style>
    .search-container {
        text-align: left;
        margin-bottom: 20px;
    }
    .search-container input[type="text"] {
        padding: 8px;
        width: 300px;
        border: 1px solid #ddd;
        border-radius: 5px;
        margin-right: 10px;
    }
    .search-container button {
        padding: 8px 15px;
        background-color: #3498DB;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .search-container button:hover {
        background-color: #2980B9;
    }
</style>

</div>
<style>
.pagination {
    text-align: center;
    margin-top: 20px;
}

.pagination a {
    display: inline-block;
    margin: 0 5px;
    padding: 10px 15px;
    text-decoration: none;
    border: 1px solid #ddd;
    color: #3498DB;
    border-radius: 5px;
}

.pagination a.active {
    background-color: #3498DB;
    color: white;
    font-weight: bold;
}

.pagination a:hover {
    background-color: #2980B9;
    color: white;
}

.pagination a.prev, .pagination a.next {
    font-weight: bold;
}
</style>



<style>
/* Table Styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    font-family: Arial, sans-serif;
}

thead th {
    padding: 10px;
    background-color: #5DADE2;
    text-align: left;
}

tbody tr {
    border-bottom: 1px solid #ddd;
}

tbody tr:hover {
    background-color: #f9f9f9;
}

td {
    padding: 10px;
    vertical-align: middle;
}

/* Button Styling */
.btn {
    padding: 8px 12px;
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
}

.btn-edit {
    background-color: #4CAF50; /* Green */
}

.btn-delete {
    background-color: #f44336; /* Red */
}

.btn:hover {
    opacity: 0.9;
}

/* Icon Styling */
i {
    font-size: 16px;
}
.actions a {
    text-decoration: none;
    padding: 5px 10px;
    border-radius: 5px;
    color: white;
    font-size: 14px;
}

.actions a.edit {
    background-color: #2980B9;
}

.actions a.delete {
    background-color: #E74C3C;
}

.actions a:hover {
    opacity: 0.8;
}

td img {
    width: 50px;
    height: auto;
    border: 1px solid #ddd;
    border-radius: 5px;
}


</style>

        
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. All rights reserved.</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
