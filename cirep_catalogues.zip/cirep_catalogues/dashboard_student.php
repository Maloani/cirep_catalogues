<?php
// Démarrer la session
session_start();

// Vérifier si l'étudiant est connecté
if (!isset($_SESSION['matricule'])) {
    header("Location: student_login.php");
    exit;
}

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les informations de l'étudiant
$matricule = $_SESSION['matricule'];
$sql = "SELECT * FROM inscriptions WHERE matricule = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt->bind_param("s", $matricule);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    header("Location: student_login.php");
    exit;
}

$stmt->close();

// Requête SQL pour récupérer les cours de la filière associée à l'étudiant
$sql_courses = "
    SELECT c.*
    FROM cours c
    JOIN filieres_departements f ON c.id_filieres_departements = f.id_filieres_departements
    JOIN inscriptions i ON i.filiere = f.filieres_departements_designation
    WHERE i.matricule = ?
";

$stmt_courses = $conn->prepare($sql_courses);
if ($stmt_courses === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt_courses->bind_param("s", $matricule);
$stmt_courses->execute();
$courses_result = $stmt_courses->get_result();
$courses = [];

while ($row = $courses_result->fetch_assoc()) {
    $courses[] = $row;
}

$stmt_courses->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord étudiant</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* Menu principal */
        nav {
            background-color: #004080;
            padding: 10px;
        }

        nav .menu {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        nav .menu a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            font-size: 16px;
        }

        nav .menu a:hover {
            background-color: #0056b3;
        }

        /* Icône pour le menu hamburger */
        .menu-toggle {
            display: none;
            background-color: #004080;
            border: none;
            color: white;
            font-size: 20px;
            padding: 10px;
            cursor: pointer;
        }

        /* Affichage du menu sur mobile */
        @media (max-width: 768px) {
            nav .menu {
                display: none;
                flex-direction: column;
                align-items: center;
            }

            nav .menu a {
                width: 100%;
                text-align: center;
            }

            nav .menu.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }

        main {
            padding: 20px;
        }

        .container {
            margin-bottom: 20px;
        }

        .container h2 {
            color: #0077b6;
            margin-bottom: 15px;
        }

        .container table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0077b6;
            color: white;
        }

        .actions a {
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 8px 15px;
            border-radius: 5px;
            margin-right: 10px;
        }

        .actions a:hover {
            background-color: #3e8e41;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
      #annonces-container {
    max-height: 200px; /* Hauteur maximale pour le conteneur des annonces */
    overflow: hidden; /* Cache les annonces en dehors des limites */
    position: relative;
}

#annonces-container .annonce {
    padding: 10px;
    border: 1px solid #ccc;
    background-color: #f9f9f9;
    margin-bottom: 10px;
    border-radius: 5px;
    font-size: 16px;
    animation: slideUp 10s linear infinite; /* Animation pour le défilement */
}

#annonces-container .annonce h3 {
    margin: 0;
    font-size: 18px;
    color: #007bff;
}

@keyframes slideUp {
    0% {
        transform: translateY(0);
    }
    100% {
        transform: translateY(-100%);
    }
}


    </style>
    <script>
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        let container = $('#annonces-container');
        let height = container.height();

        function scrollAnnonces() {
            container.animate(
                { scrollTop: container.prop("scrollHeight") }, 
                10000, 
                "linear", 
                function () {
                    container.scrollTop(0); // Réinitialiser au début
                    scrollAnnonces(); // Recommencer
                }
            );
        }

        scrollAnnonces();
    });
</script>

</head>
<body>
    <!-- En-tête -->
    <header>
        
        <h1><p>Bienvenue, <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> !</p></h1>
    </header>

    <!-- Menu principal -->
    <nav>
        <button class="menu-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i> Menu
        </button>
         <div class="menu">
        <?php
        // Détecter la page actuelle
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>
        <a href="dashboard_student.php" class="<?php echo $current_page == 'dashboard_student.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Accueil
        </a>
        <a href="mes_courses.php" class="<?php echo $current_page == 'mes_courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> Mes cours
        </a>
        <a href="all_preve.php" class="<?php echo $current_page == 'all_preve.php' ? 'active' : ''; ?>">
            <i class="fas fa-id-card"></i> Mes preuves de paiement
        </a>
        <a href="generate_bulletin.php" class="<?php echo $current_page == 'generate_bulletin.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i> Bulletin de notes
        </a>
      
        <a href="process_declaration.php" class="<?php echo $current_page == 'process_declaration.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Déclarer le paiement
        </a>
        <a href="mes_dossiers.php" class="<?php echo $current_page == 'mes_dossiers.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Envoyer votre dossier
        </a>
        <a href="student_logout.php" class="<?php echo $current_page == 'student_logout.php' ? 'active' : ''; ?>">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </a>
    </div>
    </nav>

   <!-- Contenu principal -->
<main style="display: flex; flex-wrap: wrap; gap: 20px; padding: 20px;">
    <!-- Section des cours -->
    

    <!-- Section des informations personnelles -->
    <div id="student-info" class="container" style="flex: 1; min-width: 300px; background: #f9f9f9; border: 1px solid #ddd; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <h2>Mes informations</h2>
        <ul style="list-style: none; padding: 0; font-size: 16px;">
            <li><strong>Matricule :</strong> <?php echo htmlspecialchars($student['matricule']); ?></li>
            <li><strong>Filière :</strong> <?php echo htmlspecialchars($student['filiere']); ?></li>
            <li><strong>Pays :</strong> <?php echo htmlspecialchars($student['country']); ?></li>
            <li><strong>Lieu de naissance :</strong> <?php echo htmlspecialchars($student['place_of_birth']); ?></li>
            <li><strong>Date de naissance :</strong> <?php echo htmlspecialchars($student['date_of_birth']); ?></li>
            <li><strong>Téléphone :</strong> <?php echo htmlspecialchars($student['phone']); ?></li>
            <li><strong>Email :</strong> <?php echo htmlspecialchars($student['email']); ?></li>
        </ul>
    </div>

   

   <div id="charts" class="container" style="flex: 2; min-width: 300px;">
    <h2>Annonces</h2>
    <div id="annonces-container">
        <?php include 'annonces_tout.php'; ?>
    </div>
</div>



</main>

</body>
</html>
