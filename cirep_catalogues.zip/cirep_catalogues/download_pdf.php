﻿<?php
// Inclure la bibliothèque FPDF
require 'fpdf/fpdf.php';

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Définir l'encodage de la base de données
$conn->set_charset("utf8");

// Vérifier l'ID de la recherche
if (!isset($_GET['id'])) {
    die("ID de la recherche manquant.");
}
$recherche_id = intval($_GET['id']);

// Récupérer les détails de la recherche
$sql = "SELECT * FROM recherches WHERE recherche_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recherche_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Aucune recherche trouvée pour cet ID.");
}
$recherche = $result->fetch_assoc();

// Fermer la connexion à la base
$conn->close();

// Générer le PDF avec FPDF
class PDF extends FPDF
{
    // Ajouter une méthode pour écrire du texte UTF-8
    function WriteUTF8($text)
    {
        $this->Write(10, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $text));
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Ajouter un logo si disponible
if (!empty($recherche['logo_institution']) && file_exists("uploads/recherche/" . $recherche['logo_institution'])) {
    $pdf->Image("uploads/recherche/" . $recherche['logo_institution'], 10, 10, 30); // Position (x, y) et largeur (30 mm)
    $pdf->Ln(35); // Ajouter un saut de ligne pour le décalage
}

// Titre
$pdf->Cell(0, 10, utf8_decode('Détail de la Recherche'), 0, 1, 'C');
$pdf->Ln(10);

// Ajouter les détails de la recherche
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Auteur :'), 0, 0);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['auteur']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Sujet :'), 0, 0);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['sujet']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Année d\'obtention :'), 0, 0);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['annee_obtention']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Institution :'), 0, 0);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['institution']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Options :'), 0, 0);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['options']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Originalité :'), 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['originalite_sujet']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Innovation Technologique :'), 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['innovation_technologique']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Impact sur l\'entreprise :'), 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['impact_entreprise']);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(50, 10, utf8_decode('Type de recherche :'), 0, 0);
$pdf->SetFont('Arial', '', 12);
$pdf->WriteUTF8($recherche['type_recherche']);
$pdf->Ln(10);

// Téléchargement du fichier PDF
$pdf->Output('D', 'detail_recherche_' . $recherche_id . '.pdf');
?>
