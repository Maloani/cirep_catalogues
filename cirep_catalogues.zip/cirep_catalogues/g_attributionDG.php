<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Configurer l'encodage UTF-8
$conn->set_charset("utf8mb4");

// Initialiser les messages
$error = "";
$success = "";

// Récupérer les enseignants et les cours
$sql_enseignants = "SELECT id_enseignant, nomcomplet, niveau_etude FROM enseignant";
$result_enseignants = $conn->query($sql_enseignants);

$sql_cours = "SELECT cours_id, intitule_cours, type_pro FROM cours";
$result_cours = $conn->query($sql_cours);

// Traiter la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier si les champs existent avant de les traiter
    $annee_academique = isset($_POST['annee_academique']) ? htmlspecialchars(trim($_POST['annee_academique']), ENT_QUOTES, 'UTF-8') : '';
    $cours_id = isset($_POST['cours_id']) ? intval($_POST['cours_id']) : 0;
    $id_enseignant = isset($_POST['id_enseignant']) ? intval($_POST['id_enseignant']) : 0;

    // Vérifier si les champs sont bien remplis
    if (empty($annee_academique) || $cours_id === 0 || $id_enseignant === 0) {
        $error = "Tous les champs sont obligatoires.";
    } else {
        // Vérifier si l'attribution existe déjà
        $checkQuery = "SELECT * FROM attribution_cours WHERE annee_academique = ? AND cours_id = ? AND id_enseignant = ?";
        $stmt_check = $conn->prepare($checkQuery);
        $stmt_check->bind_param("sii", $annee_academique, $cours_id, $id_enseignant);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            $error = "Cette attribution existe déjà.";
        } else {
            // Insérer l'attribution
            $insertQuery = "INSERT INTO attribution_cours (annee_academique, cours_id, id_enseignant) VALUES (?, ?, ?)";
            $stmt_insert = $conn->prepare($insertQuery);
            $stmt_insert->bind_param("sii", $annee_academique, $cours_id, $id_enseignant);

            if ($stmt_insert->execute()) {
                $success = "L'attribution a été enregistrée avec succès.";
                
            } else {
                $error = "Erreur lors de l'enregistrement : " . $stmt_insert->error;
            }

            $stmt_insert->close();
        }

        $stmt_check->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attribution des cours - CIREP</title>
    <style>
        /* Style général */
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            background-color: #5DADE2;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #3498DB;
            color: white;
            padding: 15px 20px;
        }

        header img {
            width: 60px;
            height: auto;
        }

        /* Navbar principale */
        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            gap: 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            padding: 5px;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #3498DB;
            color: white;
            padding: 20px;
            height: 100vh;
        }

        .sidebar h3 {
            text-transform: uppercase;
            margin-bottom: 15px;
            padding-bottom: 5px;
            border-bottom: 2px solid #4CAF50;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 10px;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: white;
            padding: 10px;
            display: block;
            border-radius: 5px;
        }

        .sidebar ul li a:hover {
            background-color: #2C81BA;
        }

        /* Contenu principal */
        .main-content {
            display: flex;
            flex: 1;
            padding: 20px;
        }

        .container {
            flex: 1;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #3498DB;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #5DADE2;
        }

        /* Messages d'erreur et de succès */
        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .error {
            background-color: #ffe6e6;
            border: 1px solid red;
            color: red;
        }

        .success {
            background-color: #e6ffe6;
            border: 1px solid green;
            color: green;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <!-- Barre de navigation -->
    <div class="navbar">
        <a href="dashboardDG.php">Accueil</a>
       
        <a href="logout.php">Déconnexion</a>
    </div>

    <div class="main-content">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Liens rapides</h3>
            <ul>
                <li><a href="g_programmesDG.php">Facultés</a></li>
                <li><a href="g_filiereDG.php">Filières ou départements</a></li>
                <li><a href="g_coursDG.php">Les cours</a></li>
                <li><a href="g_enseignantDG.php">Les enseignants</a></li>
                <li><a href="g_attributionDG.php">Attribution des cours</a></li>
            </ul>
        </div>

        <!-- Contenu principal -->
        <div class="container">
            <a href="mise_en_forme_attributionDG.php" class="update-link">Mise à jour </a>

            <h1>Attribution des cours</h1>

            <?php if (!empty($error)): ?>
                <div class="message error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="message success"><?php echo $success; ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="annee_academique">Année Académique :</label>
                    <input type="text" id="annee_academique" name="annee_academique" placeholder="Exemple : 2024-2025" required>
                </div>
                <div class="form-group">
                    <label for="cours_id">Cours :</label>
                    <select id="cours_id" name="cours_id" required>
                        <option value="" disabled selected>-- Sélectionnez un cours --</option>
                        <?php if ($result_cours && $result_cours->num_rows > 0): ?>
                            <?php while ($cours = $result_cours->fetch_assoc()): ?>
                                <option value="<?php echo $cours['cours_id']; ?>"><?php echo htmlspecialchars($cours['intitule_cours'] . ' (' . $cours['type_pro'] . ')'); ?></option>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <option value="" disabled>Aucun cours disponible</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_enseignant">Enseignant :</label>
                    <select id="id_enseignant" name="id_enseignant" required>
                        <option value="" disabled selected>-- Sélectionnez un enseignant --</option>
                        <?php if ($result_enseignants && $result_enseignants->num_rows > 0): ?>
                            <?php while ($enseignant = $result_enseignants->fetch_assoc()): ?>
                                <option value="<?php echo $enseignant['id_enseignant']; ?>"><?php echo htmlspecialchars($enseignant['niveau_etude'] . ' - ' . $enseignant['nomcomplet']); ?></option>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <option value="" disabled>Aucun enseignant disponible</option>
                        <?php endif; ?>
                    </select>
                </div>
                <button type="submit">Enregistrer l'attribution</button>
            </form>
        </div>
    </div>

    <footer>
        &copy; 2024 CIREP Dashboard. Tous droits réservés.
    </footer>
</body>
</html>
