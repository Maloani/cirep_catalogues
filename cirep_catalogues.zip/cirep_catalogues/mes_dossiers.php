<?php
// Démarrer la session
session_start();

// Vérifier si l'étudiant est connecté
if (!isset($_SESSION['matricule'])) {
    header("Location: student_login.php");
    exit;
}

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les informations de l'étudiant
$matricule = $_SESSION['matricule'];
$sql = "SELECT * FROM inscriptions WHERE matricule = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt->bind_param("s", $matricule);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
    $desired_level = $student['desired_level']; // Niveau souhaité
    $inscription_id = $student['inscription_id']; // ID de l'inscription
} else {
    header("Location: student_login.php");
    exit;
}

$stmt->close();

// Gérer le téléchargement des fichiers
$message = "";
$max_file_size = 1 * 1024 * 1024; // 1 Mo
$upload_dir = "uploads/" . $desired_level . "/";

// Créer le répertoire s'il n'existe pas
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Définir les champs requis en fonction du niveau
$fields = [];
if ($desired_level === "Licence") {
    $fields = [
        "baccalaureat" => "Diplôme de baccalauréat ou diplôme d'État *",
        "graduat" => "Diplôme de graduat ou BTS *",
        "releves_notes" => "Relevés de notes *",
    ];
} elseif ($desired_level === "Master") {
    $fields = [
        "baccalaureat" => "Diplôme de baccalauréat ou diplôme d'État *",
        "graduat" => "Diplôme de graduat ou BTS *",
        "releves_notes_graduat" => "Relevés de notes de graduat *",
        "licence" => "Diplôme de licence *",
        "releves_notes_licence" => "Relevés de notes de licence *",
    ];
} elseif ($desired_level === "Doctorat") {
    $fields = [
        "baccalaureat" => "Diplôme de baccalauréat ou diplôme d'État *",
        "graduat" => "Diplôme de graduat ou BTS *",
        "releves_notes_graduat" => "Relevés de notes de graduat *",
        "licence" => "Diplôme de licence *",
        "releves_notes_licence" => "Relevés de notes de licence *",
        "maitrise" => "Diplôme de maîtrise *",
        "releves_notes_maitrise" => "Relevés de notes de maîtrise *",
        "master" => "Diplôme de master *",
        "releves_notes_master" => "Relevés de notes de master *",
    ];
}

// Traitement des fichiers téléversés
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploaded_files = [];

    foreach ($fields as $field => $label) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            // Vérifier la taille du fichier
            if ($_FILES[$field]['size'] > $max_file_size) {
                $message .= "Le fichier " . htmlspecialchars($_FILES[$field]['name']) . " dépasse la taille maximale de 1 Mo.<br>";
                continue;
            }

            // Déplacer le fichier dans le répertoire
            $file_path = $upload_dir . $matricule . "_" . basename($_FILES[$field]['name']);
            if (move_uploaded_file($_FILES[$field]['tmp_name'], $file_path)) {
                $uploaded_files[$field] = $file_path;
            } else {
                $message .= "Erreur lors du téléversement de " . htmlspecialchars($_FILES[$field]['name']) . ".<br>";
            }
        }
    }

    // Si des fichiers ont été téléversés, insérer dans la base de données
    if (!empty($uploaded_files)) {
        $sql = "INSERT INTO dossiers_etudiants (inscription_id, ";
        $sql .= implode(", ", array_keys($uploaded_files));
        $sql .= ") VALUES (?," . str_repeat("?,", count($uploaded_files) - 1) . "?)";

        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $params = [$inscription_id];
            foreach ($uploaded_files as $file_path) {
                $params[] = $file_path;
            }
            $stmt->bind_param(str_repeat("s", count($params)), ...$params);

            if ($stmt->execute()) {
                $message .= "Les fichiers ont été enregistrés avec succès dans la base de données.<br>";
            } else {
                $message .= "Erreur lors de l'enregistrement des fichiers dans la base de données : " . $stmt->error . "<br>";
            }
            $stmt->close();
        } else {
            $message .= "Erreur lors de la préparation de la requête SQL.<br>";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord étudiant</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* Menu principal */
        nav {
            background-color: #004080;
            padding: 10px;
        }

        nav .menu {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        nav .menu a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            font-size: 16px;
        }

        nav .menu a:hover {
            background-color: #0056b3;
        }

        /* Icône pour le menu hamburger */
        .menu-toggle {
            display: none;
            background-color: #004080;
            border: none;
            color: white;
            font-size: 20px;
            padding: 10px;
            cursor: pointer;
        }

        /* Affichage du menu sur mobile */
        @media (max-width: 768px) {
            nav .menu {
                display: none;
                flex-direction: column;
                align-items: center;
            }

            nav .menu a {
                width: 100%;
                text-align: center;
            }

            nav .menu.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }

        main {
            padding: 20px;
        }

        .container {
            margin-bottom: 20px;
        }

        .container h2 {
            color: #0077b6;
            margin-bottom: 15px;
        }

        .container table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0077b6;
            color: white;
        }

        .actions a {
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 8px 15px;
            border-radius: 5px;
            margin-right: 10px;
        }

        .actions a:hover {
            background-color: #3e8e41;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        nav .menu a.active {
    background-color: #0056b3;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    color: #fff;
}

.pagination {
    margin-top: 20px;
    text-align: center;
}

.pagination .btn {
    display: inline-block;
    padding: 10px 20px;
    margin: 5px;
    background-color: #0077b6;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.pagination .btn:hover {
    background-color: #0056b3;
}
form {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 20px;
        }
        input[type="file"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin: 20px 0;
            text-align: center;
            color: green;
        }

    </style>
    <script>
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }
    </script>
</head>
<body>
    <!-- En-tête -->
    <header>
        
         <h1>Mes Dossiers</h1>
        <p>Bienvenue, <?php echo htmlspecialchars($student['first_name'] . " " . $student['last_name']); ?>. Niveau souhaité : <strong><?php echo htmlspecialchars($desired_level); ?></strong></p>
    </header>

    <!-- Menu principal -->
     <nav>
    <button class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i> Menu
    </button>
    <div class="menu">
        <?php
        // Détecter la page actuelle
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>
         <a href="dashboard_student.php" class="<?php echo $current_page == 'dashboard_student.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Accueil
        </a>
        <a href="mes_courses.php" class="<?php echo $current_page == 'mes_courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> Mes cours
        </a>
        <a href="all_preve.php" class="<?php echo $current_page == 'all_preve.php' ? 'active' : ''; ?>">
            <i class="fas fa-id-card"></i> Mes preuves de paiement
        </a>
        <a href="generate_bulletin.php" class="<?php echo $current_page == 'generate_bulletin.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i> Bulletin de notes
        </a>
        
        <a href="process_declaration.php" class="<?php echo $current_page == 'process_declaration.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Déclarer le paiement
        </a>
        <a href="mes_dossiers.php" class="<?php echo $current_page == 'mes_dossiers.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Envoyer votre dossier
        </a>
        <a href="student_logout.php" class="<?php echo $current_page == 'student_logout.php' ? 'active' : ''; ?>">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </a>
    </div>
</nav>
<body>
    <div class="container">
       <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
       <form action="mes_dossiers.php" method="post" enctype="multipart/form-data">
            <?php foreach ($fields as $field => $label): ?>
                <label for="<?php echo $field; ?>"><?php echo htmlspecialchars($label); ?></label>
                <input type="file" name="<?php echo $field; ?>" id="<?php echo $field; ?>" required>
            <?php endforeach; ?>
            <button type="submit">Envoyer les dossiers</button>
        </form>
        
    </div>
</body>
</html>

<?php
$conn->close();
?>
