<?php
// Démarrer la session
session_start();

// Vérifier si l'étudiant est connecté
if (!isset($_SESSION['matricule'])) {
    header("Location: student_login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les informations de l'étudiant connecté
$matricule = $_SESSION['matricule'];
$sql = "SELECT * FROM inscriptions WHERE matricule = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $matricule);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    header("Location: student_login.php");
    exit;
}

$stmt->close();

// Message de retour
$message = "";

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inscription_id = $student['inscription_id'];
    $classe = trim($_POST['classe']);
    $annee_academique = trim($_POST['annee_academique']);
    $somme = floatval($_POST['somme']);
    $date_paiement = $_POST['datepaiement'];
    $motif = trim($_POST['motif']);
    $mode_paiement = trim($_POST['mode_paiement']);

    // Gestion des fichiers uploadés
    $target_dir = "uploads/";
    $photo_etudiant = $_FILES['photo_etudiant'];
    $photo_bordereau = $_FILES['photo_bordereau'];

    $photo_etudiant_path = $target_dir . uniqid("etudiant_") . "_" . basename($photo_etudiant['name']);
    $photo_bordereau_path = $target_dir . uniqid("bordereau_") . "_" . basename($photo_bordereau['name']);

    // Vérifier si un paiement similaire existe déjà
    $stmt_check = $conn->prepare("SELECT COUNT(*) AS count FROM declarations_paiements WHERE inscription_id = ? AND motif = ? AND date_paiement = ?");
    $stmt_check->bind_param("iss", $inscription_id, $motif, $date_paiement);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    $row_check = $result_check->fetch_assoc();

    if ($row_check['count'] > 0) {
        $message = "Ce paiement a déjà été enregistré.";
    } else {
        // Enregistrer les fichiers
        if (move_uploaded_file($photo_etudiant['tmp_name'], $photo_etudiant_path) && move_uploaded_file($photo_bordereau['tmp_name'], $photo_bordereau_path)) {
            // Insérer dans la base de données
            $stmt_insert = $conn->prepare("INSERT INTO declarations_paiements (inscription_id, classe, annee_academique, somme, date_paiement, motif, mode_paiement, photo_etudiant, photo_bordereau) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt_insert->bind_param("issdsssss", $inscription_id, $classe, $annee_academique, $somme, $date_paiement, $motif, $mode_paiement, $photo_etudiant_path, $photo_bordereau_path);

            if ($stmt_insert->execute()) {
                $message = "Déclaration envoyée à la comptabilite du CIREP, patientez votre reçu.";
            } else {
                $message = "Erreur lors de l'enregistrement : " . $stmt_insert->error;
            }
            $stmt_insert->close();
        } else {
            $message = "Erreur lors de l'upload des fichiers.";
        }
    }
    $stmt_check->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Déclaration de Paiement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #0077b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* Menu principal */
        nav {
            background-color: #004080;
            padding: 10px;
        }

        nav .menu {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        nav .menu a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            font-size: 16px;
        }

        nav .menu a:hover {
            background-color: #0056b3;
        }

        /* Icône pour le menu hamburger */
        .menu-toggle {
            display: none;
            background-color: #004080;
            border: none;
            color: white;
            font-size: 20px;
            padding: 10px;
            cursor: pointer;
        }

        /* Affichage du menu sur mobile */
        @media (max-width: 768px) {
            nav .menu {
                display: none;
                flex-direction: column;
                align-items: center;
            }

            nav .menu.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #28a745;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #218838;
        }

        .message {
            text-align: center;
            font-weight: bold;
            color: green;
            margin-bottom: 20px;
        }

        .error {
            color: red;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        nav .menu a.active {
    background-color: #0056b3;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    color: #fff;
}

    </style>
    <script>
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }
    </script>
</head>
<body>
    <header>
        <h1>Bienvenue, <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> !</h1>
        <p>Déclarez votre paiement ici</p>
    </header>

    <nav>
    <button class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i> Menu
    </button>
    <div class="menu">
        <?php
        // Détecter la page actuelle
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>
        <a href="dashboard_student.php" class="<?php echo $current_page == 'dashboard_student.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Accueil
        </a>
        <a href="mes_courses.php" class="<?php echo $current_page == 'mes_courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> Mes cours
        </a>
        <a href="all_preve.php" class="<?php echo $current_page == 'all_preve.php' ? 'active' : ''; ?>">
            <i class="fas fa-id-card"></i> Mes preuves de paiement
        </a>
        <a href="generate_bulletin.php" class="<?php echo $current_page == 'generate_bulletin.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i> Bulletin de notes
        </a>
       
        <a href="process_declaration.php" class="<?php echo $current_page == 'process_declaration.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Déclarer le paiement
        </a>
        <a href="mes_dossiers.php" class="<?php echo $current_page == 'mes_dossiers.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Envoyer votre dossier
        </a>
        <a href="student_logout.php" class="<?php echo $current_page == 'student_logout.php' ? 'active' : ''; ?>">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </a>
    </div>
</nav>


    <div class="container">
        <h2>Formulaire de Déclaration</h2>
        <?php if (!empty($message)): ?>
            <p class="message <?php echo strpos($message, 'Erreur') !== false ? 'error' : ''; ?>">
                <?php echo htmlspecialchars($message); ?>
            </p>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <label for="classe">Classe :</label>
            <input type="text" id="classe" name="classe" placeholder="Ex : Terminale S" required>

            <label for="annee_academique">Année académique :</label>
            <input type="text" id="annee_academique" name="annee_academique" placeholder="Ex : 2023-2024" required>

            <label for="somme">Somme payée :</label>
            <input type="text" id="somme" name="somme" placeholder="Ex : 500 XOF" required>

            <label for="datepaiement">Date de paiement :</label>
            <input type="date" id="datepaiement" name="datepaiement" required>

            <label for="motif">Motif :</label>
            <select id="motif" name="motif" required>
                <option value="">-- Sélectionnez un motif --</option>
                <option value="Frais d'inscription">Frais d'inscription</option>
                <option value="Frais de 3 cartes d’étudiants et autres attestations">Frais de 3 cartes d’étudiants et autres attestations</option>
                <option value="Frais de direction de thèse">Frais de direction de thèse</option>
                <option value="Frais de rattachement de laboratoire de recherche">Frais de rattachement de laboratoire de recherche</option>
                <option value="Frais de révision et publication des 3 articles">Frais de révision et publication des 3 articles</option>
                <option value="Frais d’évaluation externe de la thèse">Frais d’évaluation externe de la thèse</option>
                <option value="Frais de soutenance">Frais de soutenance</option>
                <option value="Frais de certification PhD">Frais de certification PhD</option>
                <option value="Frais de certification Master">Frais de certification Master</option>
            </select>

            <label for="mode_paiement">Mode de paiement :</label>
            <select id="mode_paiement" name="mode_paiement" required>
                <option value="">-- Sélectionnez un mode --</option>
                <option value="Western Union">Western Union</option>
                <option value="RIA">RIA</option>
                <option value="Money Gram">Money Gram</option>
            </select>
            <label for="photo_bordereau">Votre Photo :</label>
            <input type="file" id="photo_etudiant" name="photo_etudiant" accept="image/*" required>

            <label for="photo_bordereau">Photo du bordereau :</label>
            <input type="file" id="photo_bordereau" name="photo_bordereau" accept="image/*" required>

            <button type="submit">Soumettre</button>
        </form>
    </div>
</body>
</html>
