<?php
// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Initialisation des messages
$error = $success = "";

// Récupérer l'ID de l'institution à modifier
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "SELECT * FROM institutions WHERE institution_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $institution = $result->fetch_assoc();
    } else {
        $error = "Institution introuvable.";
    }
    $stmt->close();
} else {
    $error = "ID manquant.";
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $designation = $conn->real_escape_string($_POST['designation']);
    $sigle = $conn->real_escape_string($_POST['sigle']);
    $pays = $conn->real_escape_string($_POST['pays']);
    $logo = $institution['logo']; // Par défaut, conserver l'ancien logo

    // Gestion du téléchargement de l'image
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = "uploads_institution/";
        $logoName = uniqid() . "_" . basename($_FILES['logo']['name']);
        $uploadFile = $uploadDir . $logoName;

        if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadFile)) {
            $logo = $logoName; // Mettre à jour avec le nouveau logo
        } else {
            $error = "Erreur lors de l'upload du fichier.";
        }
    }

    // Mise à jour dans la base de données
    if (empty($error)) {
        $updateQuery = "UPDATE institutions SET designation_institution = ?, sigle = ?, pays = ?, logo = ? WHERE institution_id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ssssi", $designation, $sigle, $pays, $logo, $id);

        if ($stmt->execute()) {
            $success = "Institution mise à jour avec succès.";
        } else {
            $error = "Erreur lors de la mise à jour : " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Institution</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #3498DB;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button, a {
            display: inline-block;
            padding: 10px 15px;
            text-decoration: none;
            color: white;
            border-radius: 5px;
            margin-top: 10px;
            text-align: center;
        }
        .btn-save {
            background-color: #3498DB;
            border: none;
            cursor: pointer;
        }
        .btn-save:hover {
            background-color: #2980B9;
        }
        .btn-cancel {
            background-color: #E74C3C;
            cursor: pointer;
        }
        .btn-cancel:hover {
            background-color: #C0392B;
        }
        .message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        .message.error {
            background-color: #E74C3C;
            color: white;
        }
        .message.success {
            background-color: #2ECC71;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Modifier une Institution</h1>

        <?php if (!empty($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="message success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (!empty($institution)): ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="designation">Nom de l'institution :</label>
                <input type="text" name="designation" id="designation" value="<?php echo htmlspecialchars($institution['designation_institution']); ?>" required>
            </div>

            <div class="form-group">
                <label for="sigle">Sigle :</label>
                <input type="text" name="sigle" id="sigle" value="<?php echo htmlspecialchars($institution['sigle']); ?>" required>
            </div>

            <div class="form-group">
                <label for="pays">Pays :</label>
                <input type="text" name="pays" id="pays" value="<?php echo htmlspecialchars($institution['pays']); ?>" required>
            </div>

            <div class="form-group">
                <label for="logo">Logo (facultatif) :</label>
                <input type="file" name="logo" id="logo" accept="image/*">
                <?php if (!empty($institution['logo'])): ?>
                    <p>Logo actuel : <img src="<?php echo $institution['logo']; ?>" alt="Logo" style="width: 100px; height: auto;"></p>
                <?php endif; ?>
            </div>

            <div class="buttons">
                <button type="submit" class="btn-save">Enregistrer</button>
                <a href="mise_en_forme_institution.php" class="btn-cancel">Annuler ou Retourner</a>
            </div>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
