<?php
require('fpdf/fpdf.php');
require('phpqrcode/qrlib.php'); // Inclure la bibliothèque phpqrcode

session_start();

// Vérifier si les informations nécessaires existent dans la session
if (!isset($_GET['id'], $_SESSION['photo_path'], $_SESSION['classe'], $_SESSION['annee_academique'])) {
    die("Erreur : Les fichiers ou données nécessaires pour générer la carte ne sont pas disponibles.");
}

// Récupérer l'ID de l'étudiant depuis l'URL
$inscription_id = intval($_GET['id']);

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Erreur : Échec de la connexion à la base de données.");
}

// Récupérer les informations de l'étudiant
$sql_student = "SELECT matricule, first_name, last_name, institution, filiere FROM inscriptions WHERE inscription_id = ?";
$stmt_student = $conn->prepare($sql_student);
$stmt_student->bind_param("i", $inscription_id);
$stmt_student->execute();
$result_student = $stmt_student->get_result();

if ($result_student->num_rows > 0) {
    $student = $result_student->fetch_assoc();
} else {
    die("Étudiant introuvable.");
}

$stmt_student->close();

// Récupérer le programme associé à la filière
$sql_programme = "
    SELECT p.designation_programmes
    FROM filieres_departements f
    JOIN programmes_formations p ON f.id_programmes = p.id_programmes
    WHERE f.filieres_departements_designation = ?";
$stmt_programme = $conn->prepare($sql_programme);
$stmt_programme->bind_param("s", $student['filiere']);
$stmt_programme->execute();
$result_programme = $stmt_programme->get_result();

$programme = $result_programme->fetch_assoc();
if (!$programme) {
    $programme = ["designation_programmes" => "Non défini"];
}
$stmt_programme->close();
$conn->close();

// Générer un QR code unique avec toutes les informations
$qr_data = "Matricule : " . $student['matricule'] . "\n" .
           "Nom complet : " . $student['first_name'] . " " . $student['last_name'] . "\n" .
           "Faculté : " . $student['filiere'] . "\n" .
           "Département : " . $programme['designation_programmes'] . "\n" .
           "Classe : " . $_SESSION['classe'] . "\n" .
           "Année académique : " . $_SESSION['annee_academique'];

$qr_file = 'qrcode_' . $student['matricule'] . '.png';
QRcode::png($qr_data, $qr_file, QR_ECLEVEL_L, 3);

// Informations institutionnelles
$website = "www.cirep.ac.cd / Email : info@cirep.ac.cd";

// Classe pour créer le PDF
class PDF extends FPDF {
    function Header() {
        global $student;

        // Fond bleu pour l'en-tête
        $this->SetFillColor(0, 102, 204);
        $this->Rect(0, 0, $this->w, 40, 'F');

        // Ajouter le logo
        $logo_path = 'img/logo.PNG';
        if (file_exists($logo_path)) {
            $this->Image($logo_path, 10, 5, 30, 30); // Position du logo : X=10, Y=5, Largeur=30, Hauteur ajustée
        } else {
            $this->SetXY(10, 15);
            $this->SetFont('Arial', 'I', 10);
            $this->SetTextColor(255, 0, 0);
            $this->Cell(30, 10, utf8_decode('Logo introuvable'), 0, 0, 'C');
        }

       
        // Signification complète
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 10, strtoupper("CENTRE INTERUNIVERSITAIRE DE RECHERCHE PLURIDISCIPLINAIRE"), 0, 1, 'C');

        // Sigle "CIREP"
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, "CIREP", 0, 1, 'C');
    }

    function StudentCardHeader() {
        // Titre de la carte
        $this->SetFillColor(0, 102, 204);
        $this->SetTextColor(255, 255, 255);
        $this->SetFont('Arial', 'B', 14);
        $this->SetXY(10, 50);
        $this->Cell(190, 10, utf8_decode('CARTE D\'ÉTUDIANT'), 0, 1, 'C', true);
    }

    function StudentCard($student, $programme, $photo_path, $classe, $annee_academique, $website, $qr_file) {
        // Encadrer le contenu
        $this->SetDrawColor(0, 102, 204);
        $this->Rect(10, 65, 190, 100, 'D');

        // Ajouter la photo
        $this->Rect(15, 70, 42, 52);
        if (file_exists($photo_path)) {
            $this->Image($photo_path, 16, 71, 40, 50);
        } else {
            $this->SetXY(15, 90);
            $this->SetFont('Arial', 'I', 10);
            $this->SetTextColor(255, 0, 0);
            $this->Cell(40, 10, utf8_decode('Photo introuvable'), 0, 0, 'C');
        }

        // Texte
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(0, 0, 0);
        $this->SetXY(60, 75);
        $this->Cell(0, 8, utf8_decode('Nom : ') . $student['first_name'] . ' ' . $student['last_name'], 0, 1);
        $this->SetX(60);
        $this->Cell(0, 8, utf8_decode('Département : ') . $programme['designation_programmes'], 0, 1);
        $this->SetX(60);
        $this->Cell(0, 8, utf8_decode('Faculté : ') . $student['filiere'], 0, 1);
        $this->SetX(60);
        $this->Cell(0, 8, utf8_decode('Classe : ') . $classe, 0, 1);
        $this->SetX(60);
        $this->Cell(0, 8, utf8_decode('Matricule : ') . $student['matricule'], 0, 1);
        $this->SetX(60);
        $this->Cell(0, 8, utf8_decode('Année académique : ') . $annee_academique, 0, 1);

        // Ajouter le QR code
        $this->Image($qr_file, 160, 130, 30, 30);

        // Pied de page
        $this->SetFillColor(0, 102, 204);
        $this->SetTextColor(255, 255, 255);
        $this->Rect(10, 160, 190, 10, 'F');
        $this->SetY(160);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Web : ') . $website, 0, 0, 'C');
    }
}

// Générer le PDF
$pdf = new PDF();
$pdf->AddPage();
$pdf->StudentCardHeader();
$pdf->StudentCard(
    $student,
    $programme,
    $_SESSION['photo_path'],
    $_SESSION['classe'],
    $_SESSION['annee_academique'],
    $website,
    $qr_file
);
$pdf->Output('I', 'Student_Card_' . $student['matricule'] . '.pdf');

// Supprimer le QR code temporaire
unlink($qr_file);

?>
