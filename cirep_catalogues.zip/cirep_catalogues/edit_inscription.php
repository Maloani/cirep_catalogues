<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérifier si l'ID de l'inscription est passé en paramètre
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Aucune inscription spécifiée.");
}

$inscription_id = intval($_GET['id']);

// Récupérer les données de l'inscription
$sql = "SELECT * FROM inscriptions WHERE inscription_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}
$stmt->bind_param("i", $inscription_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Inscription introuvable.");
}

$inscription = $result->fetch_assoc();
$stmt->close();

// Vérifier si le formulaire est soumis pour mise à jour
// Vérifier si le formulaire est soumis pour mise à jour
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filiere = $_POST['filiere'];
    $matricule = $_POST['matricule'];
    $prefix = $_POST['prefix'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $date_of_birth = $_POST['date_of_birth'];
    $place_of_birth = $_POST['place_of_birth'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $country = $_POST['country'];
    $parent_name = $_POST['parent_name'];
    $parent_phone = $_POST['parent_phone'];
    $current_level = $_POST['current_level'];
    $desired_level = $_POST['desired_level'];
    $institution = $_POST['institution'];

    // Mettre à jour les données dans la base
    $update_query = "UPDATE inscriptions SET filiere = ?, matricule = ?, prefix = ?, first_name = ?, middle_name = ?, last_name = ?, date_of_birth = ?, place_of_birth = ?, gender = ?, address = ?, phone = ?, email = ?, country = ?, parent_name = ?, parent_phone = ?, current_level = ?, desired_level = ?, institution = ? WHERE inscription_id = ?";
    $stmt_update = $conn->prepare($update_query);
    if ($stmt_update === false) {
        die("Erreur de préparation de la requête de mise à jour : " . $conn->error);
    }
    $stmt_update->bind_param(
        "ssssssssssssssssssi",
        $filiere,
        $matricule,
        $prefix,
        $first_name,
        $middle_name,
        $last_name,
        $date_of_birth,
        $place_of_birth,
        $gender,
        $address,
        $phone,
        $email,
        $country,
        $parent_name,
        $parent_phone,
        $current_level,
        $desired_level,
        $institution,
        $inscription_id
    );

    if ($stmt_update->execute()) {
        // Rediriger vers s_inscription.php après une mise à jour réussie
        header("Location: s_inscription.php?message=updated");
        exit;
    } else {
        $message = "Erreur lors de la mise à jour : " . $stmt_update->error;
    }

    $stmt_update->close();
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une inscription</title>
    <style>
        form {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            color: green;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center;">Modifier une inscription</h1>
    <?php if (!empty($message)): ?>
        <p class="message"><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="filiere">Filière :</label>
        <input type="text" id="filiere" name="filiere" value="<?php echo htmlspecialchars($inscription['filiere']); ?>" required>

        <label for="matricule">Matricule :</label>
        <input type="text" id="matricule" name="matricule" value="<?php echo htmlspecialchars($inscription['matricule']); ?>" required>

        <label for="prefix">Préfixe :</label>
        <input type="text" id="prefix" name="prefix" value="<?php echo htmlspecialchars($inscription['prefix']); ?>" required>

        <label for="first_name">Prénom :</label>
        <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($inscription['first_name']); ?>" required>

        <label for="middle_name">Deuxième prénom :</label>
        <input type="text" id="middle_name" name="middle_name" value="<?php echo htmlspecialchars($inscription['middle_name']); ?>">

        <label for="last_name">Nom :</label>
        <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($inscription['last_name']); ?>" required>

        <label for="date_of_birth">Date de naissance :</label>
        <input type="date" id="date_of_birth" name="date_of_birth" value="<?php echo htmlspecialchars($inscription['date_of_birth']); ?>" required>

        <label for="place_of_birth">Lieu de naissance :</label>
        <input type="text" id="place_of_birth" name="place_of_birth" value="<?php echo htmlspecialchars($inscription['place_of_birth']); ?>" required>

        <label for="gender">Genre :</label>
        <select id="gender" name="gender">
            <option value="Male" <?php echo $inscription['gender'] === 'Male' ? 'selected' : ''; ?>>Homme</option>
            <option value="Female" <?php echo $inscription['gender'] === 'Female' ? 'selected' : ''; ?>>Femme</option>
        </select>

        <label for="address">Adresse :</label>
        <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($inscription['address']); ?>" required>

        <label for="phone">Téléphone :</label>
        <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($inscription['phone']); ?>" required>

        <label for="email">Email :</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($inscription['email']); ?>" required>

        <label for="country">Pays :</label>
        <input type="text" id="country" name="country" value="<?php echo htmlspecialchars($inscription['country']); ?>" required>

        <label for="parent_name">Nom du parent :</label>
        <input type="text" id="parent_name" name="parent_name" value="<?php echo htmlspecialchars($inscription['parent_name']); ?>" required>

        <label for="parent_phone">Téléphone du parent :</label>
        <input type="text" id="parent_phone" name="parent_phone" value="<?php echo htmlspecialchars($inscription['parent_phone']); ?>" required>

        <label for="current_level">Niveau actuel :</label>
        <input type="text" id="current_level" name="current_level" value="<?php echo htmlspecialchars($inscription['current_level']); ?>" required>

        <label for="desired_level">Niveau souhaité :</label>
        <input type="text" id="desired_level" name="desired_level" value="<?php echo htmlspecialchars($inscription['desired_level']); ?>" required>

        <label for="institution">Institution :</label>
        <input type="text" id="institution" name="institution" value="<?php echo htmlspecialchars($inscription['institution']); ?>" required>

        <button type="submit">Mettre à jour</button>
    </form>
</body>
</html>
