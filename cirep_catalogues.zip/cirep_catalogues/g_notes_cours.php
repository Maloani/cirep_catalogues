<?php
// Start session
session_start();

// Database connection
$servername = "localhost";
$username = "geoheininvest"; 
$password = "KUW3.84Hx4wV"; 
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the teacher is logged in
if (!isset($_SESSION['id_enseignant'])) {
    echo "<div class='error-message'>Vous devez être connecté pour voir vos cours.</div>";
    exit;
}

$id_enseignant = $_SESSION['id_enseignant'];

// Query to fetch all assigned courses
$sql = "
    SELECT 
        attribution_cours.id_attribution,
        cours.code AS code_cours,
        cours.intitule_cours AS designation_cours,
        cours.credit,
        cours.type_pro,
        filieres_departements.filieres_departements_designation AS designation_filiere
    FROM 
        attribution_cours
    INNER JOIN 
        cours ON attribution_cours.cours_id = cours.cours_id
    INNER JOIN 
        filieres_departements ON cours.id_filieres_departements = filieres_departements.id_filieres_departements
    WHERE 
        attribution_cours.id_enseignant = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_enseignant);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vos Cours Attribués</title>
    <style>
        /* Style général */
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table th, table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        table th { background-color: #4CAF50; color: white; }
        .back-button { margin-bottom: 20px; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
        .back-button:hover { background-color: #45a049; }
    </style>
</head>
<body>
    <!-- Button to go back to dashboard -->
    <a href="dashboardEns.php" class="back-button">Retour au tableau de bord</a>

    <h2>Bonjour cher enseignant, envoyez les notes de vos cours attribués :</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Code Cours</th>
                    <th>Désignation Cours</th>
                    <th>Crédit</th>
                    <th>Type Pro</th>
                    <th>Désignation Filière</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['code_cours']); ?></td>
                        <td><?php echo htmlspecialchars($row['designation_cours']); ?></td>
                        <td><?php echo htmlspecialchars($row['credit']); ?></td>
                        <td><?php echo htmlspecialchars($row['type_pro']); ?></td>
                        <td><?php echo htmlspecialchars($row['designation_filiere']); ?></td>
                        <td>
                            <a href="upload_file.php?id_attribution=<?php echo $row['id_attribution']; ?>" class="back-button">Envoyer fichier</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucun cours attribué pour le moment.</p>
    <?php endif; ?>

    <?php 
    $stmt->close();
    $conn->close();
    ?>
</body>
</html>
