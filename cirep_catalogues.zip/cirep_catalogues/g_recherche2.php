<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Initialiser les messages
$error = "";
$success = "";

// Récupérer l'ID de l'utilisateur connecté
$user_id = $_SESSION['user_id'];

// Récupérer les informations de l'utilisateur connecté
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql_user);

if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows > 0) {
    $logged_user = $user_result->fetch_assoc();
} else {
    $logged_user = null;
}

$stmt->close();

// Traiter la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer et nettoyer les données du formulaire
    $auteur = trim($_POST['auteur']);
    $contact = trim($_POST['contact']);
    $sujet = trim($_POST['sujet']);
    $annee_obtention = trim($_POST['annee_obtention']);
    $institution = trim($_POST['institution']);
    $options = trim($_POST['options']);
    $originalite_sujet = trim($_POST['originalite_sujet']);
    $innovation_technologique = trim($_POST['innovation_technologique']);
    $impact_entreprise = trim($_POST['impact_entreprise']);
    $type_recherche = trim($_POST['type_recherche']);

    // Gérer le téléchargement du fichier
    $logo_institution = $_FILES['logo_institution']['name'];
    $target_dir = "uploads/recherche/";
    $target_file = $target_dir . basename($logo_institution);
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Vérifier si le fichier est une image valide
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($file_type, $allowed_types)) {
        $error = "Seuls les fichiers JPG, JPEG, PNG et GIF sont acceptés pour le logo.";
    } elseif ($_FILES['logo_institution']['error'] !== UPLOAD_ERR_OK) {
        $error = "Erreur lors du téléchargement du logo.";
    } elseif (!move_uploaded_file($_FILES["logo_institution"]["tmp_name"], $target_file)) {
        $error = "Impossible de déplacer le fichier téléchargé.";
    } else {
        // Vérifier les doublons
        $checkQuery = "SELECT * FROM recherches WHERE sujet = ? AND annee_obtention = ? AND institution = ?";
        $stmt_check = $conn->prepare($checkQuery);

        if ($stmt_check === false) {
            die("Erreur de préparation de la requête : " . $conn->error);
        }

        $stmt_check->bind_param("sss", $sujet, $annee_obtention, $institution);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            $existing_research = $result_check->fetch_assoc();
            $error = "Cette recherche a été déjà menée par " . htmlspecialchars($existing_research['auteur']) .
                     " de l'année " . htmlspecialchars($existing_research['annee_obtention']) .
                     " à l'institution " . htmlspecialchars($existing_research['institution']) . ".";
        } else {
            // Insérer les données dans la base
            $insertQuery = "INSERT INTO recherches 
                (auteur, sujet, contact,annee_obtention, institution, logo_institution, options, originalite_sujet, innovation_technologique, impact_entreprise, type_recherche) 
                VALUES (?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt_insert = $conn->prepare($insertQuery);

            if ($stmt_insert === false) {
                die("Erreur de préparation de la requête d'insertion : " . $conn->error);
            }

            $stmt_insert->bind_param(
                "sssssssssss",
                $auteur,
                $contact,
                $sujet,
                $annee_obtention,
                $institution,
                $logo_institution,
                $options,
                $originalite_sujet,
                $innovation_technologique,
                $impact_entreprise,
                $type_recherche
            );

            if ($stmt_insert->execute()) {
                $success = "La recherche a été enregistrée avec succès.";
            } else {
                $error = "Erreur lors de l'enregistrement : " . $stmt_insert->error;
            }

            $stmt_insert->close();
        }

        $stmt_check->close();
    }
}

$conn->close();
?>




<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Programmes - CIREP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            background-color: #5DADE2;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #3498DB;
            color: white;
            padding: 15px 20px;
        }

        header img {
            width: 60px;
            height: auto;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            gap: 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            padding: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            padding: 20px;
        }

        .sidebar {
            width: 200px;
            background: #f4f4f4;
            border: 1px solid #ddd;
            padding: 15px;
        }

        .sidebar h3 {
            margin-bottom: 15px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            text-decoration: none;
            color: #333;
        }

        .register-container {
            flex: 1;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        label {
            width: 30%;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="email"], input[type="password"], select {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            background-color: #3498DB;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #5DADE2;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
<style>
    .error {
        color: red;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #ffe6e6;
        padding: 10px;
        border: 1px solid red;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .error-icon {
        color: red;
        font-size: 18px;
    }

    .success {
        color: green;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #e6ffe6;
        padding: 10px;
        border: 1px solid green;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .success-icon {
        color: green;
        font-size: 18px;
    }
</style>

   <header>
        
        <h1 style='color:white'>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <div class="navbar">
        <a href="dashboardDG.php">Accueil</a>
       
        <a href="logout.php">Déconnexion</a>
    </div>

    <div class="main-content">
       <div class="sidebar">
    <h3>Liens rapides</h3>
   <ul>
         <li><a href="g_programmesDG.php">Facultés </a></li>
   
        <li><a href="g_filiereDG.php">Filières ou départements </a></li>
        <li><a href="g_coursDG.php">Les cours </a></li>
        <li><a href="g_enseignantDG.php">Les Enseignants </a></li>
         <li><a href="g_attributionDG.php">Attribution des cours aux enseignants </a></li>
         <li><a href="g_recherche2.php">Gérer les recherches </a></li>
       
    </ul>
</div>
<style>
    .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.update-link {
    display: inline-block;
    text-decoration: none;
    font-size: 16px;
    color: white;
    background-color: #3498DB; /* Bleu */
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.update-link:hover {
    background-color: #2C81BA; /* Couleur légèrement plus foncée au survol */
    transform: scale(1.05); /* Agrandir légèrement au survol */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
}
</style>


        <div class="register-container">
	
            <h3 style='color:red'>Enregistrez les sujets de recherche ménée par vos étudiants ou enseignants</h3>
            <?php if (!empty($error)): ?>
				<p class="error">
					<span class="error-icon">&#10060;</span> <!-- Error Icon -->
					<?php echo $error; ?>
				</p>
			<?php endif; ?>

			<?php if (!empty($success)): ?>
				<p class="success">
					<span class="success-icon">&#10004;</span> <!-- Success Icon -->
					<?php echo $success; ?>
				</p>
			<?php endif; ?>

		<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">
    <div class="form-group">
        <label for="auteur">Nom de l'auteur :</label>
        <input type="text" id="auteur" name="auteur" required>
    </div>
     <div class="form-group">
        <label for="contact">Contact ou mail :</label>
        <input type="text" id="contact" name="contact" required>
    </div>

    <div class="form-group">
        <label for="sujet">Sujet de la recherche :</label>
        <textarea id="sujet" name="sujet" rows="4" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
    </div>

    <div class="form-group">
        <label for="annee_obtention">Année d'obtention :</label>
        <input type="text" id="annee_obtention" name="annee_obtention" required>
    </div>

    <div class="form-group">
        <label for="institution">Nom de l'institution :</label>
        <input type="text" id="institution" name="institution" required>
    </div>

    <div class="form-group">
        <label for="logo_institution">Logo de l'institution :</label>
        <input type="file" id="logo_institution" name="logo_institution" accept="image/*" required>
    </div>

    <div class="form-group">
        <label for="options">Options :</label>
        <input type="text" id="options" name="options" required>
    </div>

    <div class="form-group">
        <label for="originalite_sujet">Originalité du sujet :</label>
        <textarea id="originalite_sujet" name="originalite_sujet" rows="4" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
    </div>

    <div class="form-group">
        <label for="innovation_technologique">Innovation technologique :</label>
        <textarea id="innovation_technologique" name="innovation_technologique" rows="4" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
    </div>

    <div class="form-group">
        <label for="impact_entreprise">Impact sur l'entreprise :</label>
        <textarea id="impact_entreprise" name="impact_entreprise" rows="4" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
    </div>
	<div class="form-group">
    <label for="type_recherche">Type de recherche :</label>
    <select id="type_recherche" name="type_recherche" required 
            style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
        <option value="" disabled selected>-- Sélectionnez un type --</option>
        <option value="Mémoire de master">Mémoire de master</option>
        <option value="Thèse">Thèse</option>
        <option value="Article">Article</option>
        <option value="Memoire de Licence">Memoire de Licence</option>
    </select>
</div>

    <button type="submit">Enregistrer</button>
</form>

           
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. Tous droits réservés.</p>
    </footer>
	

</body>
</html>
