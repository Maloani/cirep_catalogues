<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the logged-in user's information
$sql_user = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$logged_user = $user_result->fetch_assoc();

// Initialize variables
$error = "";
$success = "";

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération des données du formulaire
    $designation = $conn->real_escape_string(trim($_POST['designation_institution']));
    $sigle = $conn->real_escape_string(trim($_POST['sigle']));
    $pays = $conn->real_escape_string(trim($_POST['pays']));

    // Vérification du fichier logo
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $logoName = basename($_FILES['logo']['name']);
        $uploadDir = 'uploads_institution/';
        $uploadFile = $uploadDir . uniqid() . "_" . $logoName; // Ajouter un identifiant unique pour éviter les conflits

        // Vérification des doublons (nom et sigle)
        $checkQuery = "SELECT * FROM institutions WHERE designation_institution = ? OR sigle = ?";
        $stmt_check = $conn->prepare($checkQuery);
        $stmt_check->bind_param("ss", $designation, $sigle);
        $stmt_check->execute();
        $result = $stmt_check->get_result();

        if ($result->num_rows > 0) {
            $error = "Une institution avec ce nom ou ce sigle existe déjà.";
        } else {
            // Vérification de l'extension du fichier
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
            $fileExtension = strtolower(pathinfo($logoName, PATHINFO_EXTENSION));

            if (!in_array($fileExtension, $allowedExtensions)) {
                $error = "Le fichier doit être une image (jpg, jpeg, png, gif).";
            } else {
                // Déplacement du fichier dans le dossier "uploads"
                if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadFile)) {
                    // Insertion dans la base de données
                    $sql = "INSERT INTO institutions (designation_institution, sigle, logo, pays) 
                            VALUES (?, ?, ?, ?)";
                    $stmt_insert = $conn->prepare($sql);
                    $stmt_insert->bind_param("ssss", $designation, $sigle, $uploadFile, $pays);

                    if ($stmt_insert->execute()) {
                        $success = "Institution enregistrée avec succès.";
                    } else {
                        $error = "Erreur lors de l'enregistrement : " . $stmt_insert->error;
                    }
                } else {
                    $error = "Erreur lors du téléchargement du fichier.";
                }
            }
        }
    } else {
        if (isset($_FILES['logo']['error']) && $_FILES['logo']['error'] !== UPLOAD_ERR_OK) {
            $error = "Erreur lors de la sélection du fichier : " . $_FILES['logo']['error'];
        } else {
            $error = "Veuillez sélectionner un fichier.";
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Inscription - CIREP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            background-color: #5DADE2;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #3498DB;
            color: white;
            padding: 15px 20px;
        }

        header img {
            width: 60px;
            height: auto;
        }

        .navbar {
            background-color: #3498DB;
            color: white;
            padding: 10px 20px;
            display: flex;
            gap: 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #4CAF50;
            padding: 5px;
        }

        .main-content {
            display: flex;
            flex: 1;
            padding: 20px;
        }

        .sidebar {
            width: 200px;
            background: #f4f4f4;
            border: 1px solid #ddd;
            padding: 15px;
        }

        .sidebar h3 {
            margin-bottom: 15px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            text-decoration: none;
            color: #333;
        }

        .register-container {
            flex: 1;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        label {
            width: 30%;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="email"], input[type="password"], select {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            background-color: #3498DB;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #5DADE2;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
<style>
    .error {
        color: red;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #ffe6e6;
        padding: 10px;
        border: 1px solid red;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .error-icon {
        color: red;
        font-size: 18px;
    }

    .success {
        color: green;
        font-size: 14px;
        margin-bottom: 15px;
        background-color: #e6ffe6;
        padding: 10px;
        border: 1px solid green;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .success-icon {
        color: green;
        font-size: 18px;
    }
</style>

   <header>
        
        <h1 style='color:white'>Bienvenue, <?php echo htmlspecialchars($logged_user['prenom'] . ' ' . $logged_user['nom'] . ' (' . $logged_user['role'] . ')'); ?></h1>

    </header>

    <div class="navbar">
        <a href="dashboard.php">Accueil</a>
       
        <a href="logout.php">Déconnexion</a>
    </div>

    <div class="main-content">
       <div class="sidebar">
    <h3>Liens rapides</h3>
   <ul>
        <li><a href="register.php">Ajouter un utilisateur</a></li>
        <li><a href="g_institution.php">Ajouter une institution</a></li>
        <li><a href="g_programmes.php">Programmes organisés </a></li>
        <li><a href="g_recherche.php">Recherches </a></li>
        <li><a href="g_filiere.php">Filières ou départements </a></li>
        <li><a href="s_inscription.php">Situation des inscriptions </a></li>
		 <li><a href="g_cours.php">Gestion des cours </a></li>
        <li><a href="g_Resultats.php">Gestion des résultats </a></li>
        <li><a href="#">Voir les rapports</a></li>
    </ul>
</div>
<style>
    .sidebar {
        background-color: #3498DB;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 300px;
    }

    .sidebar h3 {
        font-size: 18px;
        color: white;
        margin-bottom: 15px;
        text-transform: uppercase;
        border-bottom: 2px solid #4CAF50;
        padding-bottom: 5px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        text-decoration: none;
        font-size: 16px;
        color: white;
        display: block;
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
        background-color: #3498DB;
        color: white;
        transform: translateX(5px);
    }
	.update-link {
    display: inline-block;
    text-decoration: none;
    font-size: 16px;
    color: white;
    background-color: #3498DB; /* Bleu */
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.update-link:hover {
    background-color: #2C81BA; /* Couleur légèrement plus foncée au survol */
    transform: scale(1.05); /* Agrandir légèrement au survol */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
}
</style>


        <div class="register-container">
		<a href="mise_en_forme_institution.php" class="update-link">Mise à jour des institutions</a>


            <h1 style='color:#3498DB'>Enregistrez une institution dans le système CIREP catalogue</h1>
            <?php if (!empty($error)): ?>
				<p class="error">
					<span class="error-icon">&#10060;</span> <!-- Error Icon -->
					<?php echo $error; ?>
				</p>
			<?php endif; ?>

			<?php if (!empty($success)): ?>
				<p class="success">
					<span class="success-icon">&#10004;</span> <!-- Success Icon -->
					<?php echo $success; ?>
				</p>
			<?php endif; ?>

<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">

            <div class="form-group">
                <label for="designation_institution">Nom de l'institution :</label>
                <input type="text" id="designation_institution" name="designation_institution" required>
            </div>
            <div class="form-group">
                <label for="sigle">Sigle :</label>
                <input type="text" id="sigle" name="sigle" required>
            </div>
			<div class="form-group">
                <label for="logo">Logo :</label>
                <input type="file" id="logo" name="logo" required>
            </div>
            <div class="form-group">
                <label for="pays">Pays :</label>
                <select id="pays" name="pays" required>
            <?php
            // Liste de tous les pays du monde
            $countries = [
                "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", 
                "Armenia", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados",
                "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana",
                "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", 
                "Canada", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo (Congo-Brazzaville)","Congo Democratic Republic (DRC)", 
                "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czechia (Czech Republic)", "Denmark", "Djibouti", 
                "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", 
                "Estonia", "Eswatini (fmr. Swaziland)", "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", 
                "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", 
                "Haiti", "Holy See", "Honduras", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", 
                "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", 
                "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", 
                "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", 
                "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", 
                "Morocco", "Mozambique", "Myanmar (Burma)", "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", 
                "Nicaragua", "Niger", "Nigeria", "North Korea", "North Macedonia", "Norway", "Oman", "Pakistan", 
                "Palau", "Palestine State", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", 
                "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", 
                "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", 
                "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", 
                "Somalia", "South Africa", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", 
                "Sweden", "Switzerland", "Syria", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", 
                "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", 
                "United Arab Emirates", "United Kingdom", "United States of America", "Uruguay", "Uzbekistan", 
                "Vanuatu", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
            ];
            foreach ($countries as $country) {
                echo "<option value=\"$country\">$country</option>";
            }
            ?>
        </select><br><br>

            </div>
            
            <button type="submit">Enregistrer</button>
        </form>
           
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> CIREP Dashboard. Tous droits réservés.</p>
    </footer>
	

</body>
</html>
