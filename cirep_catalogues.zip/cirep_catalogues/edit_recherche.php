<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Initialiser les variables
$message = "";
$recherche_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Récupérer les données de la recherche
if ($recherche_id > 0) {
    $sql = "SELECT * FROM recherches WHERE recherche_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $recherche_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $recherche = $result->fetch_assoc();
    } else {
        $message = "Aucune recherche trouvée avec cet ID.";
    }
    $stmt->close();
} else {
    header("Location: index.php"); // Rediriger si l'ID est invalide
    exit;
}

// Traiter la soumission du formulaire de modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $auteur = trim($_POST['auteur']);
    $contact = trim($_POST['contact']);
    $sujet = trim($_POST['sujet']);
    $type_recherche = trim($_POST['type_recherche']);
    $annee_obtention = trim($_POST['annee_obtention']);
    $institution = trim($_POST['institution']);
    $impact_entreprise = trim($_POST['impact_entreprise']);

    $update_query = "UPDATE recherches 
                     SET auteur = ?, contact = ?,sujet = ?, type_recherche = ?, annee_obtention = ?, institution = ?, impact_entreprise = ?
                     WHERE recherche_id = ?";
    $stmt_update = $conn->prepare($update_query);

    if ($stmt_update) {
        $stmt_update->bind_param("sssssssi", $auteur, $contact,$sujet, $type_recherche, $annee_obtention, $institution, $impact_entreprise, $recherche_id);
        if ($stmt_update->execute()) {
            $message = "Recherche mise à jour avec succès.";
        } else {
            $message = "Erreur lors de la mise à jour : " . $stmt_update->error;
        }
        $stmt_update->close();
    } else {
        $message = "Erreur de préparation de la requête : " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une recherche</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }

        h1 {
            text-align: center;
            color: #3498DB;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        input, select, textarea, button, a {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #3498DB;
            color: white;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        button:hover {
            background-color: #2980B9;
        }

        .btn-cancel {
            text-decoration: none;
            text-align: center;
            background-color: #e74c3c;
            color: white;
            margin-top: 10px;
            display: inline-block;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .btn-cancel:hover {
            background-color: #c0392b;
        }

        .message {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .message.success {
            background-color: #e6ffe6;
            border-color: #27ae60;
            color: #27ae60;
        }

        .message.error {
            background-color: #ffe6e6;
            border-color: #e74c3c;
            color: #e74c3c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Modifier une recherche</h1>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo strpos($message, 'succès') !== false ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="auteur">Auteur</label>
                <input type="text" id="auteur" name="auteur" value="<?php echo htmlspecialchars($recherche['auteur']); ?>" required>
            </div>
            <div class="form-group">
                <label for="contact">Contact</label>
                <input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars($recherche['contact']); ?>" required>
            </div>

            <div class="form-group">
                <label for="sujet">Sujet</label>
                <textarea id="sujet" name="sujet" rows="4" required><?php echo htmlspecialchars($recherche['sujet']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="type_recherche">Type de recherche</label>
                <select id="type_recherche" name="type_recherche" required>
                    <option value="Mémoire de master" <?php echo $recherche['type_recherche'] === 'Mémoire de master' ? 'selected' : ''; ?>>Mémoire de master</option>
                    <option value="Thèse" <?php echo $recherche['type_recherche'] === 'Thèse' ? 'selected' : ''; ?>>Thèse</option>
                    <option value="Article" <?php echo $recherche['type_recherche'] === 'Article' ? 'selected' : ''; ?>>Article</option>
                </select>
            </div>

            <div class="form-group">
                <label for="annee_obtention">Année d'obtention</label>
                <input type="text" id="annee_obtention" name="annee_obtention" value="<?php echo htmlspecialchars($recherche['annee_obtention']); ?>" required>
            </div>

            <div class="form-group">
                <label for="institution">Institution</label>
                <input type="text" id="institution" name="institution" value="<?php echo htmlspecialchars($recherche['institution']); ?>" required>
            </div>

            <div class="form-group">
                <label for="impact_entreprise">Impact sur l'entreprise</label>
                <textarea id="impact_entreprise" name="impact_entreprise" rows="4" required><?php echo htmlspecialchars($recherche['impact_entreprise']); ?></textarea>
            </div>

            <button type="submit">Mettre à jour</button>
            <a href="mise_en_forme_recherche.php" class="btn-cancel">Annuler ou Retourner</a>
        </form>
    </div>
</body>
</html>