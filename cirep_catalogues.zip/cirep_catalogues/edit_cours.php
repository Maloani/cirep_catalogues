<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérifier si l'ID du cours est passé en paramètre
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Aucun cours spécifié.");
}

$cours_id = intval($_GET['id']);

// Récupérer les données du cours
$sql = "SELECT * FROM cours WHERE cours_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Erreur de préparation de la requête : " . $conn->error);
}
$stmt->bind_param("i", $cours_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Cours introuvable.");
}

$cours = $result->fetch_assoc();
$stmt->close();

// Récupérer les filières pour la liste déroulante
$sql_filieres = "SELECT id_filieres_departements, filieres_departements_designation FROM filieres_departements";
$result_filieres = $conn->query($sql_filieres);

// Initialiser les variables pour les messages
$message = "";

// Vérifier si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['code']);
    $intitule_cours = trim($_POST['intitule_cours']);
    $credit = intval($_POST['credit']);
    $id_filieres_departements = intval($_POST['id_filieres_departements']);

    // Vérifier les champs obligatoires
    if (empty($code) || empty($intitule_cours) || empty($credit) || empty($id_filieres_departements)) {
        $message = "Tous les champs sont obligatoires.";
    } else {
        // Mettre à jour les données dans la base
        $update_query = "UPDATE cours SET code = ?, intitule_cours = ?, credit = ?, id_filieres_departements = ? WHERE cours_id = ?";
        $stmt_update = $conn->prepare($update_query);
        if ($stmt_update === false) {
            die("Erreur de préparation de la requête de mise à jour : " . $conn->error);
        }

        $stmt_update->bind_param("ssiii", $code, $intitule_cours, $credit, $id_filieres_departements, $cours_id);

        if ($stmt_update->execute()) {
            // Redirection vers la liste des cours avec un message de succès
            header("Location: mise_en_forme_cours.php?message=updated");
            exit;
        } else {
            $message = "Erreur lors de la mise à jour : " . $stmt_update->error;
        }

        $stmt_update->close();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un cours</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #3498DB;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #3498DB;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2980B9;
        }

        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
        }

        .error {
            background-color: #ffe6e6;
            color: red;
            border: 1px solid red;
        }

        .success {
            background-color: #e6ffe6;
            color: green;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h1>Modifier un cours</h1>
    <?php if (!empty($message)): ?>
        <div class="message error"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label for="code">Code du cours :</label>
            <input type="text" id="code" name="code" value="<?php echo htmlspecialchars($cours['code']); ?>" required>
        </div>
        <div class="form-group">
            <label for="intitule_cours">Intitulé du cours :</label>
            <input type="text" id="intitule_cours" name="intitule_cours" value="<?php echo htmlspecialchars($cours['intitule_cours']); ?>" required>
        </div>
        <div class="form-group">
            <label for="credit">Nombre de crédits :</label>
            <input type="number" id="credit" name="credit" value="<?php echo htmlspecialchars($cours['credit']); ?>" min="1" required>
        </div>
        <div class="form-group">
            <label for="id_filieres_departements">Filière / Département :</label>
            <select id="id_filieres_departements" name="id_filieres_departements" required>
                <option value="" disabled>-- Sélectionnez une filière --</option>
                <?php while ($filiere = $result_filieres->fetch_assoc()): ?>
                    <option value="<?php echo $filiere['id_filieres_departements']; ?>" 
                        <?php echo $cours['id_filieres_departements'] == $filiere['id_filieres_departements'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($filiere['filieres_departements_designation']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit">Mettre à jour</button>
    </form>
</div>
</body>
</html>
<?php
$conn->close();
?>
