<?php
// Inclure le fichier de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

// Vérifier si l'ID de l'utilisateur est passé dans l'URL
if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']); // S'assurer que l'ID est un entier

    // Préparer la requête pour supprimer l'utilisateur
    $sql = "DELETE FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            // Redirection après suppression réussie
            header("Location: dashboard.php?message=Utilisateur supprimé avec succès");
            exit();
        } else {
            echo "Erreur lors de la suppression de l'utilisateur.";
        }
        $stmt->close();
    } else {
        echo "Erreur dans la préparation de la requête.";
    }
} else {
    echo "Aucun ID d'utilisateur spécifié.";
}

$conn->close();
?>
