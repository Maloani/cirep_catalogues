<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "cirep_catalogue_db";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the ID is provided in the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $actuality_id = intval($_GET['id']);

    // Retrieve the actualite to delete (optional: for validation or logging)
    $stmt_check = $conn->prepare("SELECT * FROM actualites WHERE actuality_id = ?");
    $stmt_check->bind_param("i", $actuality_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        // Proceed with deletion
        $stmt_delete = $conn->prepare("DELETE FROM actualites WHERE actuality_id = ?");
        $stmt_delete->bind_param("i", $actuality_id);

        if ($stmt_delete->execute()) {
            // Redirect back to the list with success message
            header("Location: mises_actualite.php.php?message=Actualité supprimée avec succès");
            exit;
        } else {
            // Handle deletion error
            header("Location: mises_actualite.php.php?error=Erreur lors de la suppression de l'actualité");
            exit;
        }
    } else {
        // If the actualite doesn't exist
        header("Location: mises_actualite.php.php?error=Actualité introuvable");
        exit;
    }
} else {
    // If no ID is provided
    header("Location: mises_actualite.php.php?error=ID invalide");
    exit;
}

// Close the database connection
$conn->close();
?>
