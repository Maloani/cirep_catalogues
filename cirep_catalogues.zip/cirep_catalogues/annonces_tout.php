<?php
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Erreur de connexion à la base de données : " . $conn->connect_error);
}

// Requête pour récupérer toutes les annonces
$sql = "SELECT * FROM annonces ORDER BY date_publication DESC";
$result = $conn->query($sql);

// Générer le contenu HTML des annonces
if ($result->num_rows > 0) {
    echo "<h2 style='color:navy'>Annonces</h2>";
    while ($annonce = $result->fetch_assoc()) {
        echo "<div class='annonce'>";
        echo "<h3 style='color:blue' >" . htmlspecialchars($annonce['titre']) . "</h3>";
        echo "<p>" . htmlspecialchars($annonce['contenu']) . "</p>";
        echo "<small>Publié le : " . htmlspecialchars($annonce['date_publication']) . "</small>";
        echo "</div><hr>";
    }
} else {
    echo "<p>Aucune annonce disponible.</p>";
}

$conn->close();
?>
