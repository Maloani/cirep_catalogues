<form method="POST">
    <div class="form-group">
        <label for="prefix">Civilité :</label>
        <select id="prefix" name="prefix" required>
            <option value="" disabled selected>-- Sélectionnez --</option>
            <option value="Mr.">Mr.</option>
            <option value="Mme">Mme</option>
            <option value="Mlle">Mlle</option>
        </select>
    </div>

    <div class="form-group">
        <label for="first_name">Prénom :</label>
        <input type="text" id="first_name" name="first_name" required>
    </div>

    <div class="form-group">
        <label for="middle_name">Deuxième prénom :</label>
        <input type="text" id="middle_name" name="middle_name">
    </div>

    <div class="form-group">
        <label for="last_name">Nom :</label>
        <input type="text" id="last_name" name="last_name" required>
    </div>

    <div class="form-group">
        <label for="date_of_birth">Date de naissance :</label>
        <input type="date" id="date_of_birth" name="date_of_birth" required>
    </div>

    <div class="form-group">
        <label for="place_of_birth">Lieu de naissance :</label>
        <input type="text" id="place_of_birth" name="place_of_birth" required>
    </div>

    <div class="form-group">
        <label for="gender">Genre :</label>
        <select id="gender" name="gender" required>
            <option value="" disabled selected>-- Sélectionnez --</option>
            <option value="Masculin">Masculin</option>
            <option value="Féminin">Féminin</option>
        </select>
    </div>

    <div class="form-group">
        <label for="address">Adresse :</label>
        <input type="text" id="address" name="address" required>
    </div>

    <div class="form-group">
        <label for="phone">Téléphone :</label>
        <input type="text" id="phone" name="phone" required>
    </div>

    <div class="form-group">
        <label for="email">Email :</label>
        <input type="email" id="email" name="email" required>
    </div>

    <div class="form-group">
        <label for="country">Pays :</label>
        <input type="text" id="country" name="country" required>
    </div>

    <div class="form-group">
        <label for="parent_name">Nom complet du parent/tuteur :</label>
        <input type="text" id="parent_name" name="parent_name" required>
    </div>

    <div class="form-group">
        <label for="parent_phone">Téléphone du parent/tuteur :</label>
        <input type="text" id="parent_phone" name="parent_phone" required>
    </div>

    <div class="form-group">
        <label for="current_level">Votre niveau d'étude actuel :</label>
        <select id="current_level" name="current_level" required>
            <option value="" disabled selected>-- Sélectionnez --</option>
            <option value="Licence">Licence</option>
            <option value="Master">Master</option>
            <option value="Doctorat">Doctorat</option>
        </select>
    </div>

    <div class="form-group">
        <label for="desired_level">Type de formation pour inscription :</label>
        <select id="desired_level" name="desired_level" required>
            <option value="" disabled selected>-- Sélectionnez --</option>
            <option value="Licence">Licence</option>
            <option value="Master">Master</option>
            <option value="Doctorat">Doctorat</option>
        </select>
    </div>

    <div class="form-group">
        <label for="institution">Voulez - vous obtenir le diplôme dans quelle institution ? :</label>
        <select id="institution" name="institution" required>
            <option value="" disabled selected>-- Sélectionnez une institution --</option>
            <?php
            if (!empty($row['institutions'])) {
                $institutions = explode(';', $row['institutions']);
                foreach ($institutions as $institution) {
                    $parts = explode('|', $institution);
                    if (count($parts) === 3) {
                        list($sigle, $logo, $country) = $parts;
                        echo '<option value="' . htmlspecialchars($sigle) . '">' 
                            . htmlspecialchars($sigle) . ' (' . htmlspecialchars($country) . ')</option>';
                    } else {
                        echo '<option disabled style="color: red;">Données d\'institution invalides</option>';
                    }
                }
            } else {
                echo '<option disabled style="color: red;">Aucune institution trouvée</option>';
            }
            ?>
        </select>
    </div>

    <button type="submit">Soumettre l'inscription</button>
</form>
