<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Connexion à la base de données
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Initialisation des variables
$search_query = "";
$search_term = "%%"; // Par défaut, aucun filtre

// Si une recherche est soumise
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_query = trim($_GET['search']);
    $search_term = "%" . $search_query . "%";
}

// Pagination
$results_per_page = 5;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $results_per_page;

// Récupérer les déclarations de paiement avec recherche et pagination
$sql_paginated = "
    SELECT d.*, i.matricule, i.first_name, i.last_name, i.filiere
    FROM declarations_paiements d
    JOIN inscriptions i ON d.inscription_id = i.inscription_id
    WHERE i.matricule LIKE ? OR i.first_name LIKE ? OR i.last_name LIKE ?
    ORDER BY d.date_paiement DESC
    LIMIT ? OFFSET ?";
$stmt_paginated = $conn->prepare($sql_paginated);
$stmt_paginated->bind_param("sssii", $search_term, $search_term, $search_term, $results_per_page, $offset);
$stmt_paginated->execute();
$result_paginated = $stmt_paginated->get_result();

// Calculer le nombre total de résultats pour la recherche
$sql_count = "
    SELECT COUNT(*) AS total
    FROM declarations_paiements d
    JOIN inscriptions i ON d.inscription_id = i.inscription_id
    WHERE i.matricule LIKE ? OR i.first_name LIKE ? OR i.last_name LIKE ?";
$stmt_count = $conn->prepare($sql_count);
$stmt_count->bind_param("sss", $search_term, $search_term, $search_term);
$stmt_count->execute();
$result_count = $stmt_count->get_result();
$total_results = $result_count->fetch_assoc()['total'];
$total_pages = ceil($total_results / $results_per_page);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Déclarations de Paiement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3498DB;
            color: white;
            text-align: center;
            padding: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px auto;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #3498DB;
            color: white;
        }

        .pagination {
            text-align: center;
            margin: 20px 0;
        }

        .pagination a {
            padding: 8px 15px;
            margin: 5px;
            background: #3498DB;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .pagination a.active {
            background: #2980B9;
            font-weight: bold;
        }

        .pagination a:hover {
            background: #21618C;
        }

        .btn {
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            display: inline-block;
        }

        .btn-validate {
            background-color: #4CAF50;
        }

        .btn-validate:hover {
            background-color: #45A049;
        }

        .search-container {
            text-align: center;
            margin: 20px 0;
        }

        .search-container input {
            padding: 8px;
            width: 300px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .search-container button {
            padding: 8px 15px;
            background-color: #3498DB;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #2980B9;
        }

        .photo img {
            max-width: 50px;
            cursor: pointer;
        }

        .photo img:hover {
            transform: scale(1.5);
            transition: transform 0.2s ease-in-out;
        }
        /* Style de la modale */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.8);
    justify-content: center;
    align-items: center;
}

.modal-content {
    margin: auto;
    display: block;
    max-width: 90%;
    max-height: 90%;
}

.close {
    position: absolute;
    top: 20px;
    right: 35px;
    color: white;
    font-size: 30px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: #bbb;
    text-decoration: none;
    cursor: pointer;
}


    </style>
    <script>
    function enlargeImage(img) {
        var modal = document.getElementById("modal");
        var modalImg = document.getElementById("modal-img");
        
        modal.style.display = "flex";
        modalImg.src = img.src;
    }

    function closeModal() {
        var modal = document.getElementById("modal");
        modal.style.display = "none";
    }
</script>
</head>
<body>
<header>
    <h1>Déclarations de Paiement</h1>
    <a href="s_inscription2.php" class="back-button"><i class="fas fa-arrow-left"></i> Retour</a>
</header>

<div class="search-container">
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Rechercher par matricule ou nom"
               value="<?php echo htmlspecialchars($search_query); ?>">
        <button type="submit">
            <i class="fas fa-search"></i> Rechercher
        </button>
    </form>
</div>

<table>
    <thead>
        <tr>
            <th>Matricule</th>
            <th>Nom complet</th>
            <th>Filière</th>
            <th>Classe</th>
            <th>Motif</th>
            <th>Montant</th>
            <th>Mode de paiement</th>
            <th>Photo</th>
            <th>Bordereau</th>
            <th>Date de paiement</th>
            <th>Actions</th>
        </tr>
    </thead>
   <!-- Modale pour afficher les images -->
<div id="modal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <img class="modal-content" id="modal-img">
</div>

<!-- Votre tableau -->
<tbody>
    <?php if ($result_paginated->num_rows > 0): ?>
        <?php while ($row = $result_paginated->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['matricule']); ?></td>
                <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                <td><?php echo htmlspecialchars($row['filiere']); ?></td>
                <td><?php echo htmlspecialchars($row['classe']); ?></td>
                <td><?php echo htmlspecialchars($row['motif']); ?></td>
                <td><?php echo htmlspecialchars(number_format($row['somme'], 2)) . ' XOF'; ?></td>
                <td><?php echo htmlspecialchars($row['mode_paiement']); ?></td>
                <td class="photo">
                    <img src="<?php echo htmlspecialchars($row['photo_etudiant']); ?>" 
                         alt="Photo étudiant"
                         onclick="enlargeImage(this)">
                </td>
                <td class="photo">
                    <img src="<?php echo htmlspecialchars($row['photo_bordereau']); ?>" 
                         alt="Photo bordereau"
                         onclick="enlargeImage(this)">
                </td>
                <td><?php echo htmlspecialchars(date("d/m/Y", strtotime($row['date_paiement']))); ?></td>
                <td>
                    <a href="generate_student_recu.php?id=<?php echo $row['declaration_id']; ?>" class="btn btn-validate">
                        Valider & Générer Reçu
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="11" style="text-align: center;">Aucune déclaration trouvée.</td>
        </tr>
    <?php endif; ?>
</tbody>

</table>

<div class="pagination">
    <?php if ($page > 1): ?>
        <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search_query); ?>">Précédent</a>
    <?php endif; ?>

    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search_query); ?>"
           class="<?php echo $i == $page ? 'active' : ''; ?>">
            <?php echo $i; ?>
        </a>
    <?php endfor; ?>

    <?php if ($page < $total_pages): ?>
        <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search_query); ?>">Suivant</a>
    <?php endif; ?>
</div>

</body>
</html>

<?php
$conn->close();
?>
