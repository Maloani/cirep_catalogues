<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "cirep_catalogue_db";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$error = "";
$success = "";

// Fetch the actualite to update
if (isset($_GET['id'])) {
    $actuality_id = intval($_GET['id']); // Ensure the ID is an integer

    // Get the actualite details
    $stmt = $conn->prepare("SELECT * FROM actualites WHERE actuality_id = ?");
    $stmt->bind_param("i", $actuality_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $actualite = $result->fetch_assoc();
    } else {
        die("Actualité introuvable.");
    }
} else {
    die("Aucun ID d'actualité spécifié.");
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = trim($_POST['titre']);
    $contenu = trim($_POST['contenu']);
    $status = trim($_POST['status']);
    $image = $actualite['image']; // Keep the existing image if no new one is uploaded

    // Validate inputs
    if (empty($titre) || empty($contenu) || empty($status)) {
        $error = "Tous les champs sont requis.";
    } else {
        // Handle new image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = "uploads/"; // Directory to store uploaded files
            $image = $upload_dir . basename($_FILES['image']['name']);
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $image)) {
                $error = "Erreur lors du téléchargement de l'image.";
            }
        }

        if (empty($error)) {
            // Update the actualite in the database
            $stmt = $conn->prepare("UPDATE actualites SET titre = ?, contenu = ?, status = ?, image = ? WHERE actuality_id = ?");
            $stmt->bind_param("ssssi", $titre, $contenu, $status, $image, $actuality_id);

            if ($stmt->execute()) {
                $success = "Actualité mise à jour avec succès.";
            } else {
                $error = "Erreur lors de la mise à jour de l'actualité.";
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une actualité</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #3498DB;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"], textarea, select, input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .buttons button, .buttons a {
            width: 48%;
            text-align: center;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .btn-save {
            background-color: #4CAF50;
            color: white;
        }

        .btn-save:hover {
            background-color: #45A049;
        }

        .btn-cancel {
            background-color: #F44336;
            color: white;
        }

        .btn-cancel:hover {
            background-color: #D32F2F;
        }

        .message {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
        }

        .error {
            color: red;
            background-color: #ffe6e6;
            border: 1px solid red;
        }

        .success {
            color: green;
            background-color: #e6ffe6;
            border: 1px solid green;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Modifier une actualité</h1>

        <?php if (!empty($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="message success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="titre">Titre :</label>
                <input type="text" name="titre" id="titre" value="<?php echo htmlspecialchars($actualite['titre']); ?>" required>
            </div>

            <div class="form-group">
                <label for="contenu">Contenu :</label>
                <textarea name="contenu" id="contenu" rows="5" required><?php echo htmlspecialchars($actualite['contenu']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="status">Statut :</label>
                <select name="status" id="status" required>
                    <option value="APPEL OUVERT" <?php echo $actualite['status'] === 'APPEL OUVERT' ? 'selected' : ''; ?>>APPEL OUVERT</option>
                    <option value="APPEL CLOS" <?php echo $actualite['status'] === 'APPEL CLOS' ? 'selected' : ''; ?>>APPEL CLOS</option>
                    <option value="INFO" <?php echo $actualite['status'] === 'INFOS' ? 'selected' : ''; ?>>INFO</option>
                </select>
            </div>

            <div class="form-group">
                <label for="image">Image (facultative) :</label>
                <input type="file" name="image" id="image" accept="image/*">
                <?php if (!empty($actualite['image'])): ?>
                    <p>Image actuelle : <a href="<?php echo $actualite['image']; ?>" target="_blank">Voir</a></p>
                <?php endif; ?>
            </div>

            <div class="buttons">
                <button type="submit" class="btn-save">Enregistrer</button>
                <a href="add_actualites.php" class="btn-cancel">Annuler ou Retourner</a>
            </div>
        </form>
    </div>
</body>
</html>
