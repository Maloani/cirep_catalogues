<?php
// Démarrer la session
session_start();

// Détails de connexion à la base de données
$servername = "localhost";
$username = "geoheininvest"; // Remplacez par votre utilisateur MySQL
$password = "KUW3.84Hx4wV"; // Remplacez par votre mot de passe MySQL
$database = "geoheininvest_heineken";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Initialiser les variables
$error_message = "";
$success_message = "";
$inscription = null;

// Traiter la soumission du formulaire pour vérifier le matricule
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {
    $matricule = trim($_POST['matricule']);

    if (!empty($matricule)) {
        // Requête SQL pour récupérer les informations d'inscription
        $sql = "SELECT * FROM inscriptions WHERE matricule = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            die("Erreur de préparation de la requête : " . $conn->error);
        }

        $stmt->bind_param("s", $matricule);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $inscription = $result->fetch_assoc();
        } else {
            $error_message = "Aucune inscription trouvée pour le matricule fourni.";
        }

        $stmt->close();
    } else {
        $error_message = "Veuillez entrer un matricule valide.";
    }
}

// Traiter la validation de la connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['validate'])) {
    if (!empty($_POST['matricule_hidden'])) {
        $matricule = $_POST['matricule_hidden'];

        // Vérifier le statut de l'inscription
        $sql = "SELECT statut FROM inscriptions WHERE matricule = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            die("Erreur de préparation de la requête : " . $conn->error);
        }

        $stmt->bind_param("s", $matricule);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $inscription_status = $result->fetch_assoc();

            if ($inscription_status['statut'] === 'Confirmed') {
                $_SESSION['matricule'] = $matricule;
                header("Location: dashboard_student.php");
                exit;
            } else {
                $error_message = "Votre inscription n'est pas confirmée. Veuillez contacter l'administration.";
            }
        } else {
            $error_message = "Aucune inscription trouvée pour le matricule fourni.";
        }

        $stmt->close();
    } else {
        $error_message = "Erreur : Matricule manquant.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification des inscriptions</title>
    <style>
        /* Animation de fond multicolore */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #ff9a9e, #fad0c4, #fbc2eb, #a1c4fd, #c2e9fb);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            margin: 0;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Conteneur principal */
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }

        /* Icône */
        .icon img {
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
        }

        /* Titre */
        h1 {
            color: #333;
            font-size: 1.8em;
            margin-bottom: 15px;
        }

        /* Champs de formulaire */
        form input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            margin-bottom: 15px;
            box-sizing: border-box;
            transition: border 0.3s ease;
        }

        form input:focus {
            border-color: #0077b6;
            outline: none;
        }

        button {
            background-color: #0077b6;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        button:hover {
            background-color: #005f8c;
        }

        .error-message, .success-message {
            font-size: 14px;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .error-message {
            color: red;
            background-color: #ffe6e6;
            border: 1px solid red;
        }

        .success-message {
            color: green;
            background-color: #e6ffe6;
            border: 1px solid green;
        }

        .result {
            margin-top: 20px;
            padding: 15px;
            background-color: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: left;
        }

        .result p {
            margin: 8px 0;
        }

    </style>
    <style>
    .icon {
        text-align: center; /* Centrer l'icône */
        margin-bottom: 20px; /* Espacement en bas */
    }

    .icon img {
        width: 120px; /* Largeur de l'icône */
        height: 120px; /* Hauteur de l'icône */
        object-fit: contain; /* Maintient les proportions de l'image */
    }
    .back-button {
    text-align: center; /* Centre le bouton */
    margin-top: 15px; /* Espace entre le contenu précédent */
}

.back-button button {
    padding: 10px 20px;
    border: none;
    border-radius: 25px; /* Rend le bouton rond */
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    color: white; /* Texte en blanc */
    background: linear-gradient(135deg, #0077b6, #00c6ff, #7ed6df); /* Dégradé multicolore */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* Effet d'ombre */
    transition: transform 0.2s ease, background 0.3s ease;
}

.back-button button:hover {
    background: linear-gradient(135deg, #005f8c, #009ad6, #6dbbbf); /* Changement léger au survol */
    transform: scale(1.05); /* Effet d'agrandissement au survol */
}


</style>

</head>
<body>
    <!-- Conteneur principal -->
    <div class="container">
        <!-- Icône utilisateur -->
         <div class="back-button">
    <a href="index.php">
        <button type="button">Retour à l'accueil</button>
    </a>
</div>
        <h1>Vérification des inscriptions</h1>
        
        <div class="icon">
            <img src="icone_student.png" alt="User Icon">
        </div>

        
        <?php if (!empty($error_message)): ?>
            <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <p class="success-message"><?php echo htmlspecialchars($success_message); ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <?php if (!$inscription): ?>
                <!-- Entrée pour le matricule -->
                <input type="text" name="matricule" placeholder="Entrez le matricule" required>
                <button type="submit" name="verify">Vérifier</button>
            <?php else: ?>
                <!-- Affichage des résultats -->
                <div class="result">
                    <h3>Informations de l'inscription :</h3>
                    <p><strong>Matricule :</strong> <?php echo htmlspecialchars($inscription['matricule']); ?></p>
                    <p><strong>Nom complet :</strong> <?php echo htmlspecialchars($inscription['first_name'] . ' ' . $inscription['last_name']); ?></p>
                    <p><strong>Filière :</strong> <?php echo htmlspecialchars($inscription['filiere']); ?></p>
                    <p><strong>Institution :</strong> <?php echo htmlspecialchars($inscription['institution']); ?></p>
                    <p><strong>Statut :</strong> <?php echo htmlspecialchars($inscription['statut']); ?></p>
                    <p><strong>Email :</strong> <?php echo htmlspecialchars($inscription['email']); ?></p>
                    <p><strong>Téléphone :</strong> <?php echo htmlspecialchars($inscription['phone']); ?></p>
                    <p><strong>Date de naissance :</strong> <?php echo htmlspecialchars($inscription['date_of_birth']); ?></p>
                </div>
                <input type="hidden" name="matricule_hidden" value="<?php echo htmlspecialchars($inscription['matricule']); ?>">
                <button type="submit" name="validate">Valider la connexion</button>
            <?php endif; ?>
          

        </form>
    </div>
</body>
</html>

