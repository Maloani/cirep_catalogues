<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the user has the "DG" role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'DG') {
    header("Location: dashboardDG.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "geoheininvest";
$password = "KUW3.84Hx4wV";
$database = "geoheininvest_heineken";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set UTF-8 charset
$conn->set_charset("utf8mb4");

// Handle deletion
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $attribution_id = intval($_GET['id']);
    $delete_query = "DELETE FROM attribution_cours WHERE id_attribution = ?";
    $stmt_delete = $conn->prepare($delete_query);
    $stmt_delete->bind_param("i", $attribution_id);
    $stmt_delete->execute();
    $stmt_delete->close();
    header("Location: mise_en_forme_attributionDG.php");
    exit;
}

// Pagination setup
$limit = 10; // Number of results per page
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

// Filters
$search_teacher = isset($_GET['search_teacher']) ? htmlspecialchars(trim($_GET['search_teacher']), ENT_QUOTES, 'UTF-8') : '';
$search_year = isset($_GET['search_year']) ? htmlspecialchars(trim($_GET['search_year']), ENT_QUOTES, 'UTF-8') : '';
$search_course = isset($_GET['search_course']) ? htmlspecialchars(trim($_GET['search_course']), ENT_QUOTES, 'UTF-8') : '';

// SQL query with filters
$sql = "SELECT attribution_cours.id_attribution, attribution_cours.annee_academique, 
               enseignant.nomcomplet, cours.intitule_cours, cours.type_pro
        FROM attribution_cours
        INNER JOIN enseignant ON attribution_cours.id_enseignant = enseignant.id_enseignant
        INNER JOIN cours ON attribution_cours.cours_id = cours.cours_id
        WHERE 1=1";

if (!empty($search_teacher)) {
    $sql .= " AND enseignant.nomcomplet LIKE '%$search_teacher%'";
}
if (!empty($search_year)) {
    $sql .= " AND attribution_cours.annee_academique LIKE '%$search_year%'";
}
if (!empty($search_course)) {
    $sql .= " AND cours.intitule_cours LIKE '%$search_course%'";
}

$sql .= " LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// Count total results
$sql_count = "SELECT COUNT(*) AS total FROM attribution_cours
              INNER JOIN enseignant ON attribution_cours.id_enseignant = enseignant.id_enseignant
              INNER JOIN cours ON attribution_cours.cours_id = cours.cours_id
              WHERE 1=1";

if (!empty($search_teacher)) {
    $sql_count .= " AND enseignant.nomcomplet LIKE '%$search_teacher%'";
}
if (!empty($search_year)) {
    $sql_count .= " AND attribution_cours.annee_academique LIKE '%$search_year%'";
}
if (!empty($search_course)) {
    $sql_count .= " AND cours.intitule_cours LIKE '%$search_course%'";
}

$total_results = $conn->query($sql_count)->fetch_assoc()['total'];
$total_pages = ceil($total_results / $limit);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mise en forme - Attribution des cours</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        .navbar { background-color: #3498DB; color: white; padding: 10px; }
        .navbar a { color: white; text-decoration: none; margin: 0 10px; }
        .navbar a:hover { text-decoration: underline; }
        .container { margin: 20px auto; padding: 20px; max-width: 800px; background: white; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table th, table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        table th { background-color: #3498DB; color: white; }
        button, .btn { padding: 8px 15px; border-radius: 5px; color: white; text-decoration: none; }
        .btn-edit { background-color: #28a745; }
        .btn-delete { background-color: #dc3545; }
        .btn:hover { opacity: 0.8; }
        .pagination a { padding: 10px 20px; background-color: #3498DB; color: white; text-decoration: none; border-radius: 5px; }
        .pagination a:hover { background-color: #5DADE2; }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="dashboardDG.php">Accueil</a>
        <a href="logout.php">Déconnexion</a>
    </div>
    <div class="container">
        <h1>Rechercher par</h1>
        <form method="GET" action="">
            <input type="text" name="search_teacher" placeholder="Nom de l'enseignant" value="<?php echo $search_teacher; ?>">
            <input type="text" name="search_year" placeholder="Année académique" value="<?php echo $search_year; ?>">
            <input type="text" name="search_course" placeholder="Cours" value="<?php echo $search_course; ?>">
            <button type="submit">Rechercher</button>
        </form>
        <table>
            <thead>
                <tr>
                    <th>Nom de l'enseignant</th>
                    <th>Année académique</th>
                    <th>Cours</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['nomcomplet']); ?></td>
                            <td><?php echo htmlspecialchars($row['annee_academique']); ?></td>
                            <td><?php echo htmlspecialchars($row['intitule_cours']); ?></td>
                            <td><?php echo htmlspecialchars($row['type_pro']); ?></td>
                            <td>
                                <a href="modifier_attribution.php?id=<?php echo $row['id_attribution']; ?>" class="btn btn-edit">Modifier</a>
                                <a href="?action=delete&id=<?php echo $row['id_attribution']; ?>" class="btn btn-delete" onclick="return confirm('Supprimer cette attribution ?');">Supprimer</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center;">Aucune attribution trouvée.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&search_teacher=<?php echo $search_teacher; ?>&search_year=<?php echo $search_year; ?>&search_course=<?php echo $search_course; ?>">Précédent</a>
            <?php endif; ?>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&search_teacher=<?php echo $search_teacher; ?>&search_year=<?php echo $search_year; ?>&search_course=<?php echo $search_course; ?>">Suivant</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
